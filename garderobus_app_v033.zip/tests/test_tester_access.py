from app import db
from app.config import settings


def test_tester_access_flag(tmp_path):
    old = settings.database_path
    try:
        settings.database_path = str(tmp_path / 'tester.sqlite3')
        db.upsert_user(999, 'Tester', 'tester')
        assert db.is_tester(999) is False
        db.activate_tester(999)
        assert db.is_tester(999) is True
        assert db.access_mode(999) == 'tester'
    finally:
        settings.database_path = old
