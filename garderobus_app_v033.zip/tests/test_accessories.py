from app.models import OutfitRequest
from app.services.stylist import generate_outfit


def item(i, category, roles, color='black'):
    return {
        'id': i, 'title': f'item-{i}', 'category': category, 'subtype': category,
        'layer_roles': roles, 'cannot_layer_over': [], 'confirmed': True,
        'status': 'clean', 'wear_count': 0, 'print': 'plain', 'color_family': color,
        'temperature': 'neutral', 'style_tags': ['casual'], 'occasion_tags': ['everyday'],
        'fabric_family': 'unknown', 'fit': 'regular'
    }


def test_accessory_does_not_replace_core_roles():
    wardrobe = [
        item(1, 'top', ['top']), item(2, 'bottom', ['bottom']), item(3, 'shoes', ['shoes']),
        item(4, 'accessory', ['accessory']),
    ]
    result = generate_outfit(wardrobe, None, OutfitRequest())
    ids = set(result.garment_ids)
    assert {1, 2, 3}.issubset(ids)
    assert ids.issubset({1, 2, 3, 4})
