# Railway — версия 0.4 без AI

Сервис запускается тем же Dockerfile. Нужны Variables:

- TELEGRAM_BOT_TOKEN
- PUBLIC_BASE_URL
- ADMIN_TELEGRAM_ID
- ADMIN_PASSWORD

Удалите OPENAI_API_KEY: приложение его не читает.

После деплоя:
- `/health` должно показать `"ai_inside": false`
- `/admin` — кабинет стилиста
- `/app` — клиентская Капсула

Чтобы узнать ADMIN_TELEGRAM_ID, отправьте боту `/myid` и скопируйте только число в Railway.

## Tester access

Add a Railway Variable named `TESTER_ACCESS_CODE` and put the private tester code there. Do not commit the real code to GitHub. After changing the variable, redeploy the same `garderobus_app_v033.zip` build.
