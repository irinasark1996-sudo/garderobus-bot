from pathlib import Path
import os

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Telegram / hosting
    telegram_bot_token: str = ""
    telegram_webhook_secret: str = ""
    telegram_polling_timeout: int = 25
    public_base_url: str = ""
    mini_app_url: str = ""
    railway_public_domain: str = ""
    auto_configure_webhook: bool = True

    # Human stylist / owner. No AI provider is used by the application.
    admin_telegram_id: int = 0
    admin_password: str = ""

    # Commercial flow. Price is deliberately configuration, not hard-coded business logic.
    product_price_rub: int = 1490
    product_title: str = "Персональный Гардеробус"
    beta_free_access: bool = False
    # Tester access is intentionally supplied only through a deployment secret.
    # Never commit the real tester code to a public repository.
    tester_access_code: str = ""

    # Experimental local computer-vision test. No paid AI API is used.
    vision_test_enabled: bool = True
    vision_test_admin_only: bool = False
    vision_points_per_side: int = 12
    vision_max_items: int = 12

    # Optional external checkout for the standalone website.
    # Do not expose these secrets to the Mini App or repository.
    yookassa_shop_id: str = ""
    yookassa_secret_key: str = ""
    yookassa_return_url: str = ""

    database_path: str = "./storage/kapsula.sqlite3"
    storage_dir: str = "./storage"
    dev_allow_insecure_id: bool = False

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def db_path(self) -> Path:
        return Path(self.database_path)

    @property
    def storage_path(self) -> Path:
        return Path(self.storage_dir)

    @staticmethod
    def _normalize_base_url(value: str) -> str:
        value = (value or "").strip().rstrip("/")
        if value.endswith("/app"):
            value = value[:-4].rstrip("/")
        return value

    @property
    def resolved_public_base_url(self) -> str:
        explicit = self._normalize_base_url(self.public_base_url)
        if explicit:
            return explicit
        domain = (self.railway_public_domain or os.getenv("RAILWAY_PUBLIC_DOMAIN", "")).strip()
        if domain:
            return f"https://{domain.strip('/')}"
        return "http://localhost:8000"

    @property
    def resolved_mini_app_url(self) -> str:
        explicit = self.mini_app_url.strip()
        if explicit:
            return explicit
        return self.resolved_public_base_url.rstrip("/") + "/app"

    @property
    def mini_app_is_public(self) -> bool:
        return self.resolved_mini_app_url.startswith("https://")

    @property
    def explicit_webhook_secret(self) -> str:
        return self.telegram_webhook_secret.strip()

    @property
    def yookassa_configured(self) -> bool:
        return bool(self.yookassa_shop_id.strip() and self.yookassa_secret_key.strip())

    @property
    def resolved_yookassa_return_url(self) -> str:
        return (self.yookassa_return_url or (self.resolved_public_base_url.rstrip("/") + "/pay/return")).strip()


settings = Settings()
