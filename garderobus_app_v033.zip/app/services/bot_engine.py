from pathlib import Path
import asyncio
import shutil
from typing import Any

from .. import db
from ..config import settings
from .garment_processing import save_original
from .laundry import BUCKET_LABELS, group_laundry
from .telegram import TelegramAPI, main_menu_keyboard, web_app_button
from .vision_test import run_serialized
from .garment_profile import build_mechanical_profile

PROFILE_STEPS = [
    ("profile_face_front", "face_front", "1/5. Фото лица анфас. Без фильтра, камера примерно на уровне глаз, нейтральный дневной свет."),
    ("profile_face_34", "face_34", "2/5. Фото лица в ракурсе ¾. Волосы желательно убрать так, чтобы были видны контуры лица."),
    ("profile_face_profile", "face_profile", "3/5. Фото лица строго в профиль. Камера на уровне лица, без сильной перспективы."),
    ("profile_body_front", "body_front", "4/5. Фото в полный рост спереди. Стоять прямо, камера примерно на уровне середины корпуса. Одежда не должна сильно скрывать линии фигуры."),
    ("profile_body_side", "body_side", "5/5. Фото в полный рост сбоку. Та же одежда и по возможности то же расстояние до камеры."),
]
STATUS_LABELS = {"clean":"чистая","worn":"надета","laundry":"в стирке","washing":"стирается","drying":"сушится","repair":"в ремонте","seasonal":"убрана на сезон","loaned":"одолжена"}


def _has_ready_profile(user_id: int) -> bool:
    p = db.get_profile(user_id) or {}
    return p.get("status") == "ready" or p.get("schema") == "garderobus.appearance.v1"


def _is_paid(user_id: int) -> bool:
    # Paid, admin and explicitly activated tester accounts all use the same product flow.
    return (
        settings.beta_free_access
        or (bool(settings.admin_telegram_id) and user_id == settings.admin_telegram_id)
        or db.is_paid(user_id)
        or db.is_tester(user_id)
    )


def _menu(user_id: int):
    user = db.get_user(user_id) or {}
    return main_menu_keyboard(_has_ready_profile(user_id), _is_paid(user_id), str(user.get("client_code") or ""))


async def _admin_text(tg: TelegramAPI, text: str):
    if settings.admin_telegram_id:
        try:
            await tg.send_message(settings.admin_telegram_id, text)
        except Exception as e:
            print(f"Admin notify failed: {type(e).__name__}: {e}", flush=True)


async def _admin_forward(tg: TelegramAPI, chat_id: int, message_id: int):
    if settings.admin_telegram_id:
        try:
            await tg.forward_message(settings.admin_telegram_id, chat_id, message_id)
        except Exception as e:
            print(f"Admin forward failed: {type(e).__name__}: {e}", flush=True)


def _profile_text(p: dict) -> str:
    if p.get("schema") == "garderobus.appearance.v1":
        color = p.get("color") or {}
        body = p.get("body") or {}
        lines = p.get("clothing_lines") or {}
        return (
            "Твой персональный профиль:\n\n"
            f"Температура: {color.get('temperature','—')}\n"
            f"Глубина: {color.get('depth','—')}\n"
            f"Контраст: {color.get('contrast','—')}\n"
            f"Вертикаль: {body.get('vertical_line','—')}\n"
            f"Линии: {lines.get('preferred_line','—')}\n"
            f"Посадка: {lines.get('preferred_fit','—')}"
        )
    return (
        "Твой профиль после личного типирования:\n\n"
        f"{p.get('summary') or '—'}\n\n"
        f"Цвет: {p.get('color_direction') or '—'}\n"
        f"Контраст: {p.get('contrast') or '—'}\n"
        f"Линии: {p.get('line_direction') or '—'}\n"
        f"Стилевые направления: {', '.join(p.get('style_directions') or []) or '—'}\n"
        f"Подходящие цвета: {', '.join(p.get('flattering_colors') or []) or '—'}"
    )


def _help() -> str:
    return (
        "Как работает Гардеробус:\n\n"
        "1. Сначала можно бесплатно посмотреть демо-Капсулу.\n"
        "2. После оформления персонального Гардеробуса открывается консультация.\n"
        "3. Ты отвечаешь на вопросы и присылаешь 5 фотографий внешности.\n"
        "4. Затем присылаешь фотографии всего гардероба — ограничение по 10 фото убрано.\n"
        "5. Стилист подготавливает профиль и цифровые карточки вещей.\n"
        "6. После публикации Капсула работает механически: без AI-вызовов внутри приложения."
    )


async def _begin_consultation(user_id: int, chat_id: int, tg: TelegramAPI):
    if not _is_paid(user_id):
        user = db.get_user(user_id) or {}
        code = user.get("client_code") or "—"
        await tg.send_message(
            chat_id,
            f"Персональная консультация открывается после оформления Гардеробуса.\n\nТвой номер: {code}\nBeta-цена: {settings.product_price_rub} ₽.\n\nПока можно открыть демо и посмотреть, как работает готовая Капсула.",
            _menu(user_id),
        )
        return
    db.clear_profile_photos(user_id)
    db.save_consultation(user_id, {}, status="draft")
    db.set_state(user_id, "consult_goal", {"answers": {}})
    await tg.send_message(
        chat_id,
        "Небольшая анкета нужна не для того, чтобы переодеть тебя в чужой стиль. "
        "Она помогает стилисту сохранить твой характер и реальные привычки.\n\n"
        "1/6. Что ты хочешь получить от Гардеробуса: быстрее собираться, чаще носить уже купленное, сделать стиль выразительнее, добавить женственности/спорта/гламура, разобраться с цветом или что-то другое?"
    )


async def _handle_consult_text(user_id: int, chat_id: int, text: str, state: str, tg: TelegramAPI):
    ctx = db.get_context(user_id)
    answers = ctx.get("answers") or {}
    if state == "consult_goal":
        answers["goal"] = text
        db.set_state(user_id, "consult_style_identity", {"answers": answers})
        await tg.send_message(chat_id, "2/6. Какие направления тебя притягивают? Можно писать своими словами: спортивное, максимально удобное, casual, классика, романтика, гламур, минимализм, бохо, edgy, винтаж, яркое, спокойное — любые сочетания.")
    elif state == "consult_style_identity":
        answers["style_identity"] = text
        db.set_state(user_id, "consult_lifestyle", {"answers": answers})
        await tg.send_message(chat_id, "3/6. Как выглядит твоя обычная неделя: работа, дети, прогулки, машина/общественный транспорт, мероприятия, дресс-код, климат? Для каких ситуаций одежда нужна чаще всего?")
    elif state == "consult_lifestyle":
        answers["lifestyle"] = text
        db.set_state(user_id, "consult_constraints", {"answers": answers})
        await tg.send_message(chat_id, "4/6. Что ты точно не хочешь носить или терпеть ради красоты? Каблуки, облегающее, оверсайз, короткое, открытый живот, колючие ткани, сложный уход — перечисли любые ограничения.")
    elif state == "consult_constraints":
        answers["constraints"] = text
        db.set_state(user_id, "consult_favorites", {"answers": answers})
        await tg.send_message(chat_id, "5/6. Назови до трёх любимых вещей из своего шкафа и, если можешь, напиши почему именно в них тебе хорошо.")
    elif state == "consult_favorites":
        answers["favorite_items"] = text
        db.set_state(user_id, "consult_shopping", {"answers": answers})
        await tg.send_message(chat_id, "6/6. Как ты относишься к покупкам? Хочешь в первую очередь использовать существующий шкаф или иногда получать ненавязчивые подсказки, какая одна вещь сильнее всего расширит сочетания? Можно указать комфортный бюджет.")
    else:
        answers["shopping_attitude"] = text
        # Backward-compatible aggregate for older profile/admin views.
        answers["preferences"] = " | ".join(x for x in [answers.get("style_identity",""), answers.get("constraints","")] if x)
        db.save_consultation(user_id, answers, status="draft")
        db.set_state(user_id, PROFILE_STEPS[0][0], {"answers": answers, "profile_index": 0})
        await tg.send_message(chat_id, "Анкета сохранена. Теперь 5 фотографий для типирования. Я буду просить их по одной, чтобы ничего не перепуталось.")
        await tg.send_message(chat_id, PROFILE_STEPS[0][2])


async def _save_profile_photo(user_id: int, chat_id: int, message: dict, idx: int, tg: TelegramAPI):
    photos = message.get("photo") or []
    if not photos:
        return
    data, remote = await tg.download_file(photos[-1]["file_id"])
    p = save_original(data, Path(remote).suffix or ".jpg", folder="media")
    db.add_profile_photo(user_id, str(p), PROFILE_STEPS[idx][1])
    await _admin_forward(tg, chat_id, int(message.get("message_id", 0)))
    if idx < len(PROFILE_STEPS) - 1:
        ni = idx + 1
        ctx = db.get_context(user_id)
        ctx["profile_index"] = ni
        db.set_state(user_id, PROFILE_STEPS[ni][0], ctx)
        await tg.send_message(chat_id, PROFILE_STEPS[ni][2])
        return
    answers = (db.get_consultation(user_id) or {}).get("answers") or db.get_context(user_id).get("answers") or {}
    db.save_consultation(user_id, answers, status="submitted")
    db.set_state(user_id, "awaiting_typing", {})
    u = db.get_user(user_id) or {}
    uname = ("@" + u.get("username")) if u.get("username") else "без username"
    code = u.get("client_code") or str(user_id)
    await _admin_text(
        tg,
        f"Новая консультация {code}\n{u.get('first_name','')} · {uname}\nЦель: {answers.get('goal','—')}\nОбраз жизни: {answers.get('lifestyle','—')}\nПредпочтения: {answers.get('preferences','—')}\n\nАдминка: {settings.resolved_public_base_url}/admin/user/{user_id}",
    )
    await tg.send_message(chat_id, "Все 5 фотографий получены. Материалы отправлены на типирование. Когда профиль будет загружен, бот сам откроет следующий этап — фотографии гардероба.", _menu(user_id))


WARDROBE_INSTRUCTION = (
    "Теперь можно загрузить столько фотографий гардероба, сколько нужно.\n\n"
    "На одном кадре может быть несколько вещей. Главное, чтобы каждая была видна целиком, "
    "вещи не перекрывали друг друга и между ними оставался небольшой промежуток. Лучше использовать "
    "ровный свет и однотонный контрастный фон.\n\n"
    "Когда закончишь эту порцию фотографий, нажми «Обработать загруженные фото». После обработки "
    "ты сможешь проверить каждое исходное фото отдельно и исправить только те вещи, где распознавание ошиблось."
)


def _done_keyboard():
    return {"inline_keyboard": [[{"text": "Обработать загруженные фото", "callback_data": "batch:done"}]]}


def _review_overview_keyboard(batch_id: int, photos: list[dict[str, Any]]):
    rows: list[list[dict[str, str]]] = []
    for idx, photo in enumerate(photos, 1):
        status = str(photo.get("status") or "queued")
        count = int(photo.get("vision_count") or 0)
        if status == "approved":
            suffix = "✓"
        elif status in {"reshoot", "vision_error"}:
            suffix = "↻ переснять"
        elif status == "review":
            suffix = f"{count} вещей"
        elif status == "processing":
            suffix = "обрабатывается"
        else:
            suffix = status
        rows.append([{"text": f"Фото {idx} · {suffix}", "callback_data": f"rv:p:{photo['id']}"}])
    counts = db.candidate_counts(batch_id, int(photos[0]["telegram_user_id"])) if photos else {}
    approved = int(counts.get("approved", 0))
    if approved:
        rows.append([{"text": f"Добавить {approved} подтверждённых вещей", "callback_data": f"rv:commit:{batch_id}"}])
    return {"inline_keyboard": rows}


def _photo_review_keyboard(photo_id: int):
    return {
        "inline_keyboard": [
            [{"text": "✅ Всё верно", "callback_data": f"rv:ok:{photo_id}"}],
            [{"text": "✏️ Ошибка в одной вещи", "callback_data": f"rv:items:{photo_id}"}],
            [{"text": "📸 Переснять всё фото", "callback_data": f"rv:reshoot:{photo_id}"}],
            [{"text": "← К фотографиям", "callback_data": f"rv:back:{photo_id}"}],
        ]
    }


def _item_picker_keyboard(photo_id: int, candidates: list[dict[str, Any]]):
    rows: list[list[dict[str, str]]] = []
    row: list[dict[str, str]] = []
    for candidate in candidates:
        status = str(candidate.get("status") or "pending")
        if status in {"rejected", "reshoot"}:
            continue
        mark = "✓" if status == "approved" else ""
        row.append({"text": f"Вещь {candidate['item_index']} {mark}".strip(), "callback_data": f"rv:i:{candidate['id']}"})
        if len(row) == 3:
            rows.append(row); row = []
    if row:
        rows.append(row)
    rows.append([{"text": "← К фото", "callback_data": f"rv:p:{photo_id}"}])
    return {"inline_keyboard": rows}


def _item_review_keyboard(candidate_id: int, photo_id: int):
    return {
        "inline_keyboard": [
            [{"text": "✅ Вещь верная", "callback_data": f"rv:iok:{candidate_id}"}],
            [{"text": "📸 Вырезано плохо — пересниму", "callback_data": f"rv:irs:{candidate_id}"}],
            [{"text": "🚫 Это не вещь", "callback_data": f"rv:irej:{candidate_id}"}],
            [{"text": "← К вещам этого фото", "callback_data": f"rv:items:{photo_id}"}],
        ]
    }


def _after_commit_keyboard():
    return {
        "inline_keyboard": [
            [{"text": "➕ Загрузить ещё вещи", "callback_data": "wardrobe:more"}],
            [{"text": "🏁 Гардероб собран", "callback_data": "wardrobe:finish"}],
        ]
    }


async def _start_batch(user_id: int, chat_id: int, tg: TelegramAPI):
    if not _is_paid(user_id):
        await tg.send_message(chat_id, "Загрузка личного гардероба открывается после оформления персонального Гардеробуса.", _menu(user_id))
        return
    if not _has_ready_profile(user_id):
        await tg.send_message(chat_id, "Сначала нужно закончить консультацию и типирование.", _menu(user_id))
        return
    active = db.get_active_batch(user_id)
    batch_id = int(active["id"]) if active else db.create_batch(user_id)
    db.set_onboarding_state(user_id, "wardrobe_building")
    db.set_state(user_id, "batch_collect", {"batch_id": batch_id})
    await tg.send_message(chat_id, WARDROBE_INSTRUCTION, _done_keyboard())


async def _save_batch_photo(user_id: int, chat_id: int, message: dict, tg: TelegramAPI):
    ctx = db.get_context(user_id)
    batch_id = int(ctx.get("batch_id") or 0)
    if not batch_id:
        await _start_batch(user_id, chat_id, tg)
        return
    photos = message.get("photo") or []
    if not photos:
        return
    data, remote = await tg.download_file(photos[-1]["file_id"])
    path = save_original(data, Path(remote).suffix or ".jpg", folder="media")
    db.add_batch_photo(batch_id, user_id, str(path), int(message.get("message_id", 0)))
    await _admin_forward(tg, chat_id, int(message.get("message_id", 0)))
    count = len(db.list_batch_photos(batch_id))
    await tg.send_message(chat_id, f"Сохранено фото: {count}. Можно прислать ещё или начать обработку.", _done_keyboard())


async def _process_batch_photo(user_id: int, chat_id: int, batch_id: int, photo: dict[str, Any], photo_no: int, tg: TelegramAPI):
    photo_id = int(photo["id"])
    db.update_batch_photo_result(photo_id, "processing")
    try:
        path = Path(str(photo.get("path") or ""))
        if not path.exists():
            raise FileNotFoundError(f"source photo {photo_id} is missing")
        result = await run_serialized(path.read_bytes())
        count = int(result.get("count", 0))
        if count <= 0:
            db.update_batch_photo_result(photo_id, "vision_error", 0, result.get("preview", ""), result.get("sheet", ""))
            await tg.send_message(chat_id, f"Фото {photo_no}: не получилось уверенно отделить вещи. Его лучше переснять.")
            return
        candidate_dir = settings.storage_path / "candidates"
        candidate_dir.mkdir(parents=True, exist_ok=True)
        for idx, item_path in enumerate(result.get("items") or [], 1):
            src = Path(str(item_path))
            target = candidate_dir / f"candidate_{user_id}_{batch_id}_{photo_id}_{idx}_{src.name}"
            shutil.copy2(src, target)
            payload = build_mechanical_profile(target, batch_id, photo_id, idx)
            db.add_candidate(user_id, batch_id, photo_id, idx, str(target), payload)
        db.update_batch_photo_result(photo_id, "review", count, str(result.get("preview") or ""), str(result.get("sheet") or ""))
        await tg.send_photo(
            chat_id,
            result["sheet"],
            f"Фото {photo_no} · найдено {count} вещей. Нажми кнопку, если хочешь проверить именно этот кадр.",
            {"inline_keyboard": [[{"text": f"Проверить фото {photo_no}", "callback_data": f"rv:p:{photo_id}"}]]},
        )
    except Exception as exc:
        import traceback
        print(f"Batch vision failed for photo {photo_id}: {type(exc).__name__}: {exc}", flush=True)
        traceback.print_exc()
        db.update_batch_photo_result(photo_id, "vision_error")
        await tg.send_message(chat_id, f"Фото {photo_no}: обработка не удалась. Этот кадр можно отметить на пересъёмку.")


async def _process_batch_job(user_id: int, chat_id: int, batch_id: int, tg: TelegramAPI):
    photos = db.list_batch_photos(batch_id)
    for idx, photo in enumerate(photos, 1):
        await _process_batch_photo(user_id, chat_id, batch_id, photo, idx, tg)
    db.set_batch_status(batch_id, "review")
    db.set_state(user_id, "batch_review", {"batch_id": batch_id})
    photos = db.list_batch_photos(batch_id)
    await tg.send_message(
        chat_id,
        "Обработка закончена. Проверь результаты по исходным фотографиям. Если кадр хороший — можно подтвердить все вещи одним нажатием; если ошибка только в одной вещи — открой её отдельно.",
        _review_overview_keyboard(batch_id, photos),
    )


async def _finish_batch(user_id: int, chat_id: int, tg: TelegramAPI):
    ctx = db.get_context(user_id)
    batch_id = int(ctx.get("batch_id") or 0)
    if not batch_id:
        active = db.get_active_batch(user_id)
        batch_id = int(active["id"]) if active else 0
    if not batch_id:
        await tg.send_message(chat_id, "Сейчас нет активной загрузки гардероба.")
        return
    photos = db.list_batch_photos(batch_id)
    if not photos:
        await tg.send_message(chat_id, "Пока не получено ни одной фотографии.", _done_keyboard())
        return
    db.set_batch_status(batch_id, "processing")
    db.set_state(user_id, "batch_processing", {"batch_id": batch_id})
    await tg.send_message(chat_id, f"Получено {len(photos)} фото. Обрабатываю их по очереди. Для каждого исходного кадра вернётся отдельный результат.")
    asyncio.create_task(_process_batch_job(user_id, chat_id, batch_id, tg))


async def _show_batch_overview(user_id: int, chat_id: int, batch_id: int, tg: TelegramAPI):
    batch = db.get_batch(batch_id)
    if not batch or int(batch.get("telegram_user_id") or 0) != user_id:
        await tg.send_message(chat_id, "Этот пакет фотографий не найден.")
        return
    photos = batch.get("photos") or []
    counts = db.candidate_counts(batch_id, user_id)
    approved = int(counts.get("approved", 0))
    pending = int(counts.get("pending", 0))
    reshoot = int(counts.get("reshoot", 0))
    rejected = int(counts.get("rejected", 0))
    await tg.send_message(
        chat_id,
        f"Проверка пакета #{batch_id}:\n✓ подтверждено вещей: {approved}\n• ждут решения: {pending}\n↻ на пересъёмку: {reshoot}\n• ложных объектов удалено: {rejected}",
        _review_overview_keyboard(batch_id, photos),
    )


async def _show_photo_review(user_id: int, chat_id: int, photo_id: int, tg: TelegramAPI):
    photo = db.get_batch_photo(photo_id, user_id)
    if not photo:
        await tg.send_message(chat_id, "Фотография не найдена.")
        return
    batch = db.get_batch(int(photo["batch_id"]))
    photos = (batch or {}).get("photos") or []
    photo_no = next((i for i, p in enumerate(photos, 1) if int(p["id"]) == photo_id), 0)
    status = str(photo.get("status") or "")
    if status in {"reshoot", "vision_error"}:
        await tg.send_message(chat_id, f"Фото {photo_no}: этот кадр нужно переснять.", {"inline_keyboard": [[{"text": "← К фотографиям", "callback_data": f"rv:back:{photo_id}"}]]})
        return
    sheet = str(photo.get("sheet_path") or "")
    if sheet and Path(sheet).exists():
        await tg.send_photo(chat_id, sheet, f"Фото {photo_no} · {int(photo.get('vision_count') or 0)} вещей", _photo_review_keyboard(photo_id))
    else:
        await tg.send_message(chat_id, f"Фото {photo_no} · {int(photo.get('vision_count') or 0)} вещей", _photo_review_keyboard(photo_id))


async def _approve_photo(user_id: int, chat_id: int, photo_id: int, tg: TelegramAPI):
    photo = db.get_batch_photo(photo_id, user_id)
    if not photo:
        return
    db.set_photo_candidates_status(photo_id, user_id, ("pending",), "approved")
    db.set_batch_photo_status(photo_id, "approved")
    await tg.send_message(chat_id, "Все вещи на этом фото подтверждены.")
    await _show_batch_overview(user_id, chat_id, int(photo["batch_id"]), tg)


async def _show_item_picker(user_id: int, chat_id: int, photo_id: int, tg: TelegramAPI):
    photo = db.get_batch_photo(photo_id, user_id)
    if not photo:
        return
    candidates = db.list_candidates_for_photo(photo_id, user_id)
    active = [c for c in candidates if c.get("status") not in {"rejected", "reshoot"}]
    if not active:
        await tg.send_message(chat_id, "На этом фото не осталось вещей для проверки.", {"inline_keyboard": [[{"text": "← К фотографиям", "callback_data": f"rv:back:{photo_id}"}]]})
        return
    await tg.send_message(chat_id, "Выбери вещь, в которой есть ошибка, или открой её для отдельного подтверждения.", _item_picker_keyboard(photo_id, active))


async def _show_item(user_id: int, chat_id: int, candidate_id: int, tg: TelegramAPI):
    c = db.get_candidate(candidate_id, user_id)
    if not c:
        await tg.send_message(chat_id, "Эта временная карточка уже удалена.")
        return
    path = str(c.get("image_path") or "")
    if not path or not Path(path).exists():
        await tg.send_message(chat_id, "Изображение этой вещи уже удалено из временного хранилища.")
        return
    await tg.send_photo(chat_id, path, f"Вещь {c['item_index']} · статус: {c['status']}", _item_review_keyboard(candidate_id, int(c["photo_id"])))


def _refresh_photo_status(user_id: int, photo_id: int) -> None:
    candidates = db.list_candidates_for_photo(photo_id, user_id)
    live = [c for c in candidates if c.get("status") not in {"rejected", "reshoot"}]
    if live and all(c.get("status") in {"approved", "committed"} for c in live):
        db.set_batch_photo_status(photo_id, "approved")
    elif any(c.get("status") == "pending" for c in live):
        db.set_batch_photo_status(photo_id, "review")


async def _set_item_status(user_id: int, chat_id: int, candidate_id: int, status: str, tg: TelegramAPI):
    c = db.get_candidate(candidate_id, user_id)
    if not c:
        return
    delete_image = status in {"rejected", "reshoot"}
    db.set_candidate_status(candidate_id, user_id, status, delete_image=delete_image)
    _refresh_photo_status(user_id, int(c["photo_id"]))
    text = {
        "approved": "Вещь подтверждена.",
        "reshoot": "Плохая карточка удалена из временного хранилища. Эту вещь можно переснять.",
        "rejected": "Объект удалён: он не будет добавлен в гардероб и стилист его не увидит.",
    }.get(status, "Готово.")
    await tg.send_message(chat_id, text)
    await _show_item_picker(user_id, chat_id, int(c["photo_id"]), tg)


async def _reshoot_photo(user_id: int, chat_id: int, photo_id: int, tg: TelegramAPI):
    photo = db.get_batch_photo(photo_id, user_id)
    if not photo:
        return
    db.discard_photo_candidates(photo_id, user_id, "reshoot")
    db.clear_batch_photo_assets(photo_id, delete_original=True)
    db.set_batch_photo_status(photo_id, "reshoot")
    await tg.send_message(chat_id, "Этот исходный кадр и все его временные карточки удалены. Он не попадёт в гардероб и не будет виден стилисту. Переснять его можно в следующей загрузке.")
    await _show_batch_overview(user_id, chat_id, int(photo["batch_id"]), tg)


async def _commit_batch(user_id: int, chat_id: int, batch_id: int, tg: TelegramAPI):
    batch = db.get_batch(batch_id)
    if not batch or int(batch.get("telegram_user_id") or 0) != user_id:
        return
    committed = db.commit_approved_candidates(batch_id, user_id)
    if committed <= 0:
        await tg.send_message(chat_id, "Пока нет подтверждённых вещей для добавления.")
        return
    for photo in (batch.get("photos") or []):
        db.clear_batch_photo_assets(int(photo["id"]), delete_original=True)
    db.set_batch_status(batch_id, "completed")
    db.set_state(user_id, "wardrobe_between_batches", {})
    db.set_onboarding_state(user_id, "wardrobe_building")
    total = db.count_confirmed_garments(user_id)
    counts = db.candidate_counts(batch_id, user_id)
    reshoot = int(counts.get("reshoot", 0))
    extra = f"\nНа пересъёмку осталось: {reshoot}." if reshoot else ""
    await tg.send_message(
        chat_id,
        f"Добавлено в личный гардероб: {committed}.\nВсего в Гардеробусе: {total}.{extra}\n\nМожно загрузить следующую часть гардероба или закончить первичный сбор.",
        _after_commit_keyboard(),
    )


async def _finish_wardrobe_setup(user_id: int, chat_id: int, tg: TelegramAPI):
    total = db.count_confirmed_garments(user_id)
    db.set_onboarding_state(user_id, "ready")
    db.set_state(user_id, "idle", {})
    button = web_app_button("Открыть мой Гардеробус")
    keyboard = {"inline_keyboard": [[button]]} if button else _menu(user_id)
    await tg.send_message(chat_id, f"Гардероб собран — {total} вещей. Теперь можно работать с личным Гардеробусом. Новые вещи при этом всегда можно будет добавить позже.", keyboard)


def _vision_allowed(user_id: int) -> bool:
    if not settings.vision_test_enabled:
        return False
    if settings.vision_test_admin_only:
        return bool(settings.admin_telegram_id) and user_id == settings.admin_telegram_id
    return True


async def _vision_job(chat_id: int, data: bytes, tg: TelegramAPI):
    try:
        result = await run_serialized(data)
        count = int(result.get("count", 0))
        if count == 0:
            await tg.send_message(chat_id, "На этом фото не получилось уверенно отделить вещи друг от друга. Попробуй разложить их чуть дальше и отправить кадр ещё раз.")
            return
        await tg.send_photo(chat_id, result["preview"], f"Я нашёл на фото {count} отдельных вещей. Проверь, правильно ли я разделил их.")
        await tg.send_photo(chat_id, result["sheet"], f"Готово {count} карточек. ZIP пользователю больше не отправляется: отдельные файлы остаются внутренними до подтверждения.")
    except Exception as exc:
        import traceback
        print(f"Vision processing failed: {type(exc).__name__}: {exc}", flush=True)
        traceback.print_exc()
        await tg.send_message(chat_id, "Не получилось обработать этот кадр. Попробуй отправить фотографию ещё раз.")


async def _begin_vision_test(user_id: int, chat_id: int, tg: TelegramAPI):
    if not _vision_allowed(user_id):
        await tg.send_message(chat_id, "Тестовый Vision-модуль сейчас выключен.")
        return
    db.set_state(user_id, "vision_test_wait_photo", {})
    await tg.send_message(
        chat_id,
        "Пришли одну фотографию с несколькими разложенными вещами. Лучше 5–12 предметов в кадре.\n\nРазложи их так, чтобы вещи были видны целиком и по возможности не перекрывали друг друга. После загрузки я попробую разделить их на отдельные карточки для гардероба.",
    )


async def show_wardrobe(user_id: int, chat_id: int, tg: TelegramAPI):
    items = [g for g in db.list_garments(user_id) if g.get("confirmed")]
    if not items:
        await tg.send_message(chat_id, "Персональный гардероб пока обрабатывается или ещё не загружен.", _menu(user_id))
        return
    await tg.send_message(chat_id, f"В твоём цифровом гардеробе {len(items)} вещей. Открой Капсулу для просмотра и стилиста.", _menu(user_id))


async def show_laundry(user_id: int, chat_id: int, tg: TelegramAPI):
    buckets = group_laundry(db.list_garments(user_id))
    lines = ["Корзины для стирки:"]
    for k, label in BUCKET_LABELS.items():
        lines.append(f"• {label}: {len(buckets.get(k, []))}")
    await tg.send_message(chat_id, "\n".join(lines), _menu(user_id))


async def handle_update(update: dict[str, Any]):
    tg = TelegramAPI()
    cb = update.get("callback_query")
    if cb:
        user = cb.get("from") or {}
        uid = int(user.get("id", 0))
        chat = int((cb.get("message") or {}).get("chat", {}).get("id", uid))
        db.upsert_user(uid, user.get("first_name", ""), user.get("username", ""))
        data = cb.get("data", "")
        await tg.answer_callback(cb.get("id", ""))
        if data == "consult:start":
            await _begin_consultation(uid, chat, tg)
        elif data == "batch:start":
            await _start_batch(uid, chat, tg)
        elif data == "batch:done":
            await _finish_batch(uid, chat, tg)
        elif data == "wardrobe:more":
            await _start_batch(uid, chat, tg)
        elif data == "wardrobe:finish":
            await _finish_wardrobe_setup(uid, chat, tg)
        elif data.startswith("rv:p:"):
            await _show_photo_review(uid, chat, int(data.rsplit(":", 1)[1]), tg)
        elif data.startswith("rv:ok:"):
            await _approve_photo(uid, chat, int(data.rsplit(":", 1)[1]), tg)
        elif data.startswith("rv:items:"):
            await _show_item_picker(uid, chat, int(data.rsplit(":", 1)[1]), tg)
        elif data.startswith("rv:reshoot:"):
            await _reshoot_photo(uid, chat, int(data.rsplit(":", 1)[1]), tg)
        elif data.startswith("rv:back:"):
            photo = db.get_batch_photo(int(data.rsplit(":", 1)[1]), uid)
            if photo:
                await _show_batch_overview(uid, chat, int(photo["batch_id"]), tg)
        elif data.startswith("rv:i:"):
            await _show_item(uid, chat, int(data.rsplit(":", 1)[1]), tg)
        elif data.startswith("rv:iok:"):
            await _set_item_status(uid, chat, int(data.rsplit(":", 1)[1]), "approved", tg)
        elif data.startswith("rv:irs:"):
            await _set_item_status(uid, chat, int(data.rsplit(":", 1)[1]), "reshoot", tg)
        elif data.startswith("rv:irej:"):
            await _set_item_status(uid, chat, int(data.rsplit(":", 1)[1]), "rejected", tg)
        elif data.startswith("rv:commit:"):
            await _commit_batch(uid, chat, int(data.rsplit(":", 1)[1]), tg)
        elif data == "menu:profile":
            p = db.get_profile(uid)
            await tg.send_message(chat, _profile_text(p) if p else "Профиль ещё готовится.", _menu(uid))
        elif data == "menu:status":
            c = db.get_consultation(uid)
            b = db.get_active_batch(uid)
            u = db.get_user(uid) or {}
            await tg.send_message(
                chat,
                f"Номер: {u.get('client_code') or '—'}\nДоступ: {'тестировщик' if db.is_tester(uid) and not db.is_paid(uid) else ('активен' if _is_paid(uid) else 'не оформлен')}\nКонсультация: {(c or {}).get('status','не начата')}\nТипирование: {'готово' if _has_ready_profile(uid) else 'ожидается'}\nАктивная загрузка гардероба: {b['id'] if b else 'нет'}",
                _menu(uid),
            )
        elif data == "menu:wardrobe":
            await show_wardrobe(uid, chat, tg)
        elif data == "menu:laundry":
            await show_laundry(uid, chat, tg)
        return

    msg = update.get("message")
    if not msg:
        return
    user = msg.get("from") or {}
    uid = int(user.get("id", 0))
    chat = int((msg.get("chat") or {}).get("id", uid))
    db.upsert_user(uid, user.get("first_name", ""), user.get("username", ""))
    text = (msg.get("text") or "").strip()
    state = db.get_state(uid)
    if text == "/start":
        u = db.get_user(uid) or {}
        code = u.get("client_code") or "—"
        if _is_paid(uid):
            text0 = f"Гардеробус · {code}\n\nПерсональный доступ активен. Продолжи с текущего этапа или открой Капсулу."
        else:
            text0 = f"Гардеробус · {code}\n\nСначала можно бесплатно посмотреть демо готовой Капсулы. Персональная beta-версия сейчас стоит {settings.product_price_rub} ₽."
        await tg.send_message(chat, text0, _menu(uid))
        return
    if text == "/myid":
        u = db.get_user(uid) or {}
        await tg.send_message(chat, f"Твой номер Гардеробуса: {u.get('client_code') or '—'}")
        return
    if text == "/consultation":
        await _begin_consultation(uid, chat, tg)
        return
    if text in {"/wardrobe", "/add"}:
        await _start_batch(uid, chat, tg)
        return
    if text == "/done":
        await _finish_batch(uid, chat, tg)
        return
    if text == "/profile":
        p = db.get_profile(uid)
        await tg.send_message(chat, _profile_text(p) if p else "Профиль ещё не готов.", _menu(uid))
        return
    if text == "/laundry":
        await show_laundry(uid, chat, tg)
        return
    if text == "/visiontest":
        await _begin_vision_test(uid, chat, tg)
        return
    if text == "/help":
        await tg.send_message(chat, _help(), _menu(uid))
        return
    if state == "vision_test_wait_photo" and msg.get("photo"):
        photos = msg.get("photo") or []
        data, _remote = await tg.download_file(photos[-1]["file_id"])
        db.set_state(uid, "idle", {})
        await tg.send_message(chat, "Фото принято. Обрабатываю вещи — это может занять немного времени.")
        asyncio.create_task(_vision_job(chat, data, tg))
        return
    if state in {"consult_goal", "consult_style_identity", "consult_lifestyle", "consult_constraints", "consult_favorites", "consult_shopping"} and text:
        await _handle_consult_text(uid, chat, text, state, tg)
        return
    if state.startswith("profile_") and msg.get("photo"):
        idx = next((i for i, x in enumerate(PROFILE_STEPS) if x[0] == state), 0)
        await _save_profile_photo(uid, chat, msg, idx, tg)
        return
    if state == "batch_collect" and msg.get("photo"):
        await _save_batch_photo(uid, chat, msg, tg)
        return
    await tg.send_message(chat, "Выбери действие в меню.", _menu(uid))
