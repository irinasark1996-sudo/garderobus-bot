from __future__ import annotations

import asyncio
import hashlib
import io
import math
import os
import shutil
import tempfile
import threading
import zipfile
from pathlib import Path
from typing import Any

import httpx
import numpy as np
from PIL import Image, ImageDraw

from ..config import settings

_MODEL = None
_MASK_GENERATOR = None
_MODEL_LOCK = threading.Lock()
_JOB_LOCK = asyncio.Lock()

CHECKPOINT_URL = "https://huggingface.co/dhkim2810/MobileSAM/resolve/main/mobile_sam.pt?download=true"
CHECKPOINT_SHA256 = "6dbb90523a35330fedd7f1d3dfc66f995213d81b29a5ca8108dbcdd4e37d6c2f"


def _model_path() -> Path:
    p = settings.storage_path / "models" / "mobile_sam.pt"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _download_checkpoint(path: Path) -> None:
    if path.exists() and _sha256(path) == CHECKPOINT_SHA256:
        return
    tmp = path.with_suffix(".part")
    tmp.unlink(missing_ok=True)
    with httpx.Client(timeout=180, follow_redirects=True) as client:
        with client.stream("GET", CHECKPOINT_URL) as r:
            r.raise_for_status()
            with tmp.open("wb") as f:
                for chunk in r.iter_bytes(1024 * 1024):
                    f.write(chunk)
    got = _sha256(tmp)
    if got != CHECKPOINT_SHA256:
        tmp.unlink(missing_ok=True)
        raise RuntimeError(f"MobileSAM checkpoint checksum mismatch: {got[:12]}")
    tmp.replace(path)


def _load_generator():
    """Load MobileSAM through the public Predictor API.

    mobilesam-lite 0.1.2 exposes SamPredictor and sam_model_registry, but does
    not expose SamAutomaticMaskGenerator as part of its documented API.  We
    therefore keep one predictor and build a small automatic prompt grid
    ourselves.  This also lets us keep memory use bounded on the small server.
    """
    global _MODEL, _MASK_GENERATOR
    if _MASK_GENERATOR is not None:
        return _MASK_GENERATOR
    with _MODEL_LOCK:
        if _MASK_GENERATOR is not None:
            return _MASK_GENERATOR
        _download_checkpoint(_model_path())
        import torch
        from mobile_sam import SamPredictor, sam_model_registry

        try:
            torch.set_num_threads(max(1, min(2, os.cpu_count() or 1)))
            torch.set_num_interop_threads(1)
        except Exception:
            pass

        model = sam_model_registry["vit_t"](checkpoint=str(_model_path()))
        model.to(device="cpu")
        model.eval()
        predictor = SamPredictor(model)
        _MODEL = model
        _MASK_GENERATOR = predictor
        return predictor


def _bbox_from_mask(seg: np.ndarray) -> list[int] | None:
    ys, xs = np.where(seg)
    if not len(xs):
        return None
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    return [x0, y0, x1 - x0, y1 - y0]


def _generate_prompt_masks(predictor, arr: np.ndarray) -> tuple[list[dict[str, Any]], int]:
    """Generate object proposals with a bounded foreground point grid.

    We retain only plausible mid-sized masks immediately, rather than keeping
    every full-resolution proposal in RAM.
    """
    h, w = arr.shape[:2]
    total = float(h * w)
    side = max(5, min(14, int(settings.vision_points_per_side)))
    xs = np.linspace(w * 0.05, w * 0.95, side, dtype=np.float32)
    ys = np.linspace(h * 0.05, h * 0.95, side, dtype=np.float32)
    predictor.set_image(arr)

    proposals: list[dict[str, Any]] = []
    raw_count = 0
    max_pool = max(30, int(settings.vision_max_items) * 5)

    for y in ys:
        for x in xs:
            masks, scores, _ = predictor.predict(
                point_coords=np.asarray([[x, y]], dtype=np.float32),
                point_labels=np.asarray([1], dtype=np.int32),
                multimask_output=True,
            )
            for seg, score in zip(masks, scores):
                raw_count += 1
                seg = np.asarray(seg, dtype=bool)
                area = int(seg.sum())
                area_frac = area / total
                if not (0.010 <= area_frac <= 0.38):
                    continue
                bbox = _bbox_from_mask(seg)
                if not bbox:
                    continue
                bx, by, bw, bh = bbox
                box_area = max(1, bw * bh)
                fill = area / box_area
                if fill < 0.16 or box_area / total > 0.48:
                    continue
                touch = sum([
                    bx <= 2,
                    by <= 2,
                    bx + bw >= w - 2,
                    by + bh >= h - 2,
                ])
                if touch >= 3:
                    continue
                # A compact quality proxy: SAM confidence plus a small bonus
                # for coherent object-sized masks.
                predicted = float(score)
                stability = float(min(1.0, 0.72 + min(0.25, fill * 0.25)))
                proposals.append({
                    "segmentation": seg,
                    "area": area,
                    "bbox": bbox,
                    "predicted_iou": predicted,
                    "stability_score": stability,
                })

                if len(proposals) > max_pool * 2:
                    proposals.sort(
                        key=lambda m: float(m.get("predicted_iou", 0.0)),
                        reverse=True,
                    )
                    proposals = proposals[:max_pool]

    proposals.sort(key=lambda m: float(m.get("predicted_iou", 0.0)), reverse=True)
    return proposals[:max_pool], raw_count

def _resize_input(image: Image.Image, max_side: int = 1024) -> Image.Image:
    image = image.convert("RGB")
    w, h = image.size
    if max(w, h) <= max_side:
        return image
    scale = max_side / max(w, h)
    return image.resize((max(1, round(w * scale)), max(1, round(h * scale))), Image.Resampling.LANCZOS)


def _mask_overlap(a: np.ndarray, b: np.ndarray) -> tuple[float, float]:
    inter = np.logical_and(a, b).sum()
    if inter == 0:
        return 0.0, 0.0
    aa = max(1, int(a.sum()))
    bb = max(1, int(b.sum()))
    return inter / min(aa, bb), inter / max(aa, bb)


def _candidate_masks(masks: list[dict[str, Any]], shape: tuple[int, int]) -> list[dict[str, Any]]:
    h, w = shape
    total = float(h * w)
    cand: list[dict[str, Any]] = []
    for m in masks:
        seg = np.asarray(m.get("segmentation"), dtype=bool)
        if seg.shape != (h, w):
            continue
        area = float(m.get("area") or seg.sum())
        area_frac = area / total
        x, y, bw, bh = [float(v) for v in (m.get("bbox") or [0, 0, 0, 0])]
        box_area = max(1.0, bw * bh)
        box_frac = box_area / total
        fill = area / box_area
        if not (0.012 <= area_frac <= 0.34):
            continue
        if box_frac > 0.44 or fill < 0.20:
            continue
        # Huge edge-hugging regions are usually sheet/floor/background masks.
        touch = sum([
            x <= 2,
            y <= 2,
            x + bw >= w - 2,
            y + bh >= h - 2,
        ])
        if touch >= 3:
            continue
        quality = float(m.get("predicted_iou", 0.0)) * 0.55 + float(m.get("stability_score", 0.0)) * 0.45
        # Whole garments tend to have a useful middle-sized mask and reasonable fill.
        quality += min(0.08, area_frac * 0.35) + min(0.06, fill * 0.06)
        item = dict(m)
        item["segmentation"] = seg
        item["_score"] = quality
        item["_area_frac"] = area_frac
        cand.append(item)

    # Prefer large, stable whole-object masks, then suppress nested/duplicate masks.
    cand.sort(key=lambda m: (m["_score"], m["_area_frac"]), reverse=True)
    kept: list[dict[str, Any]] = []
    for m in cand:
        duplicate = False
        for k in kept:
            small_overlap, large_overlap = _mask_overlap(m["segmentation"], k["segmentation"])
            if small_overlap > 0.80 or large_overlap > 0.70:
                duplicate = True
                break
        if not duplicate:
            kept.append(m)
        if len(kept) >= int(settings.vision_max_items):
            break

    # Human-readable order: rows top-to-bottom, then left-to-right.
    kept.sort(key=lambda m: (float((m.get("bbox") or [0, 0])[1]), float((m.get("bbox") or [0, 0])[0])))
    return kept


def _feather_alpha(mask: np.ndarray) -> np.ndarray:
    import cv2
    m = (mask.astype(np.uint8) * 255)
    # Remove tiny noise without eating thin sleeves/straps.
    kernel = np.ones((3, 3), np.uint8)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, kernel, iterations=1)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, kernel, iterations=1)
    blur = cv2.GaussianBlur(m, (0, 0), 0.65)
    return np.where(m > 0, np.maximum(m, blur), blur).astype(np.uint8)


def _transparent_card(rgb: np.ndarray, mask: np.ndarray, canvas: int = 1000) -> Image.Image | None:
    alpha = _feather_alpha(mask)
    ys, xs = np.where(alpha > 12)
    if not len(xs):
        return None
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    pad = max(4, int(max(x1 - x0, y1 - y0) * 0.035))
    x0, y0 = max(0, x0 - pad), max(0, y0 - pad)
    x1, y1 = min(rgb.shape[1], x1 + pad), min(rgb.shape[0], y1 + pad)
    cut = Image.fromarray(rgb[y0:y1, x0:x1], "RGB")
    a = Image.fromarray(alpha[y0:y1, x0:x1], "L")
    target = int(canvas * 0.82)
    scale = min(target / max(1, cut.width), target / max(1, cut.height))
    nw, nh = max(1, round(cut.width * scale)), max(1, round(cut.height * scale))
    cut = cut.resize((nw, nh), Image.Resampling.LANCZOS)
    a = a.resize((nw, nh), Image.Resampling.LANCZOS)
    rgba = cut.convert("RGBA")
    rgba.putalpha(a)
    out = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0))
    out.alpha_composite(rgba, ((canvas - nw) // 2, (canvas - nh) // 2))
    return out


def _paper_preview(card: Image.Image, size: int = 620) -> Image.Image:
    bg = Image.new("RGB", (size, size), (247, 242, 233))
    fg = card.copy()
    fg.thumbnail((int(size * 0.84), int(size * 0.84)), Image.Resampling.LANCZOS)
    bg.paste(fg, ((size - fg.width) // 2, (size - fg.height) // 2), fg)
    return bg


def _contact_sheet(cards: list[tuple[str, Image.Image]]) -> Image.Image:
    cols = 3
    cell = 640
    rows = max(1, math.ceil(len(cards) / cols))
    sheet = Image.new("RGB", (cols * cell, rows * cell), (238, 231, 220))
    for idx, (gid, card) in enumerate(cards):
        r, c = divmod(idx, cols)
        tile = _paper_preview(card, cell - 20)
        d = ImageDraw.Draw(tile)
        d.rounded_rectangle((12, 12, 92, 46), radius=13, fill=(255, 252, 247))
        d.text((25, 21), gid, fill=(60, 53, 47))
        sheet.paste(tile, (c * cell + 10, r * cell + 10))
    return sheet


def _overlay(image: Image.Image, selected: list[dict[str, Any]]) -> Image.Image:
    src = np.array(image.convert("RGB"), dtype=np.float32)
    overlay = src.copy()
    palette = np.array([
        [207, 91, 78], [84, 137, 160], [126, 145, 91], [174, 120, 165],
        [204, 150, 71], [85, 158, 142], [128, 105, 179], [192, 102, 137],
    ], dtype=np.float32)
    for i, m in enumerate(selected):
        mask = m["segmentation"]
        color = palette[i % len(palette)]
        overlay[mask] = overlay[mask] * 0.58 + color * 0.42
    out = Image.fromarray(np.clip(overlay, 0, 255).astype(np.uint8))
    d = ImageDraw.Draw(out)
    for i, m in enumerate(selected, 1):
        x, y, bw, bh = [int(v) for v in m.get("bbox", [0, 0, 0, 0])]
        d.rounded_rectangle((x, y, x + bw, y + bh), radius=10, outline=(255, 255, 255), width=3)
        d.rounded_rectangle((x + 4, y + 4, x + 84, y + 37), radius=10, fill=(35, 32, 29))
        d.text((x + 15, y + 12), f"G{i:04d}", fill=(255, 255, 255))
    return out


def process_photo_bytes(data: bytes) -> dict[str, Any]:
    image = _resize_input(Image.open(io.BytesIO(data)))
    arr = np.array(image)
    predictor = _load_generator()
    masks, raw_mask_count = _generate_prompt_masks(predictor, arr)
    selected = _candidate_masks(masks, (arr.shape[0], arr.shape[1]))

    work = Path(tempfile.mkdtemp(prefix="garderobus_vision_"))
    cards: list[tuple[str, Image.Image]] = []
    try:
        for i, m in enumerate(selected, 1):
            gid = f"G{i:04d}"
            card = _transparent_card(arr, m["segmentation"])
            if card is None:
                continue
            card.save(work / f"{gid}.png", optimize=True)
            cards.append((gid, card))

        preview_path = work / "detected.jpg"
        _overlay(image, selected).save(preview_path, quality=90, optimize=True)
        sheet_path = work / "contact_sheet.jpg"
        _contact_sheet(cards).save(sheet_path, quality=92, optimize=True)
        src_path = work / "source.jpg"
        image.save(src_path, quality=92)

        zip_path = work / "garderobus_vision_result.zip"
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(src_path, "source.jpg")
            z.write(preview_path, "detected.jpg")
            z.write(sheet_path, "contact_sheet.jpg")
            for gid, _ in cards:
                z.write(work / f"{gid}.png", f"items/{gid}.png")

        # Telegram send methods need files to remain after this function returns.
        final_dir = settings.storage_path / "vision_tests" / next(tempfile._get_candidate_names())
        final_dir.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(work), final_dir)
        return {
            "count": len(cards),
            "raw_masks": raw_mask_count,
            "preview": str(final_dir / "detected.jpg"),
            "sheet": str(final_dir / "contact_sheet.jpg"),
            "zip": str(final_dir / "garderobus_vision_result.zip"),
            "dir": str(final_dir),
        }
    except Exception:
        shutil.rmtree(work, ignore_errors=True)
        raise


async def run_serialized(data: bytes) -> dict[str, Any]:
    async with _JOB_LOCK:
        return await asyncio.to_thread(process_photo_bytes, data)
