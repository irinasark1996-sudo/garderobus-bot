from __future__ import annotations

import colorsys
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image


def _family_from_hsv(h: float, s: float, v: float) -> str:
    if v < 0.16:
        return "black"
    if s < 0.10 and v > 0.88:
        return "white"
    if s < 0.12:
        return "grey"
    if s < 0.24 and 0.48 <= v <= 0.92:
        # Warm muted light neutrals are more useful to the stylist as beige/taupe.
        if h < 0.14 or h > 0.94:
            return "beige"
        return "neutral"
    deg = h * 360.0
    if deg < 12 or deg >= 345:
        return "red"
    if deg < 28:
        return "orange"
    if deg < 50:
        return "brown" if v < 0.62 else "yellow"
    if deg < 75:
        return "yellow"
    if deg < 165:
        return "green" if s > 0.28 else "olive"
    if deg < 205:
        return "blue"
    if deg < 255:
        return "blue"
    if deg < 290:
        return "purple"
    if deg < 345:
        return "pink"
    return "neutral"


def _temperature(family: str, h: float, s: float) -> str:
    if s < 0.12 or family in {"black", "white", "grey", "neutral"}:
        return "neutral"
    if family in {"red", "orange", "yellow", "brown", "beige", "olive"}:
        return "warm"
    if family in {"blue", "purple"}:
        return "cool"
    if family == "green":
        return "warm" if 0.19 <= h <= 0.30 else "cool"
    if family == "pink":
        return "warm" if h > 0.94 or h < 0.02 else "cool"
    return "unknown"


def _value(v: float) -> str:
    if v >= 0.72:
        return "light"
    if v <= 0.38:
        return "dark"
    return "medium"


def _chroma(s: float) -> str:
    if s < 0.24:
        return "muted"
    if s >= 0.58:
        return "bright"
    return "medium"


def build_mechanical_profile(image_path: str | Path, batch_id: int, photo_id: int, item_index: int) -> dict[str, Any]:
    """Build only facts that can be measured from the cutout itself.

    Semantic clothing type, material, fit and style are intentionally left unknown
    until a dedicated classifier or a human/user supplies them. This prevents the
    mechanical stylist from receiving invented attributes.
    """
    path = Path(image_path)
    with Image.open(path) as im:
        rgba = np.asarray(im.convert("RGBA"))
    alpha = rgba[..., 3]
    mask = alpha > 24
    pixels = rgba[..., :3][mask]
    h_px, w_px = alpha.shape
    if len(pixels) == 0:
        rgb = np.array([128, 128, 128], dtype=float)
        opaque = 0.0
    else:
        # Median resists highlights, shadows and tiny background remnants.
        rgb = np.median(pixels, axis=0)
        opaque = float(mask.mean())
    r, g, b = [float(x) / 255.0 for x in rgb]
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    family = _family_from_hsv(h, s, v)
    hex_color = "#%02X%02X%02X" % tuple(int(round(x)) for x in rgb)

    ys, xs = np.where(mask)
    if len(xs):
        bw = int(xs.max() - xs.min() + 1)
        bh = int(ys.max() - ys.min() + 1)
        aspect = round(bw / max(1, bh), 3)
        fill = round(len(xs) / max(1, bw * bh), 4)
    else:
        bw = bh = 0
        aspect = 0.0
        fill = 0.0

    return {
        "title": f"Вещь {item_index}",
        "category": "unknown",
        "subtype": "",
        "color_family": family,
        "color_name": hex_color,
        "temperature": _temperature(family, h, s),
        "value": _value(v),
        "chroma": _chroma(s),
        "print": "unknown",
        "print_colors": [hex_color],
        "silhouette": "",
        "length": "",
        "fit": "",
        "fabric_family": "unknown",
        "texture": [],
        "warmth": "unknown",
        "layer_roles": [],
        "can_layer_over": [],
        "cannot_layer_over": [],
        "style_tags": [],
        "occasion_tags": ["everyday"],
        "seasons": ["all"],
        "laundry_group": "unknown",
        "notes": "",
        "source_batch_id": int(batch_id),
        "source_photo_id": int(photo_id),
        "source_item_index": int(item_index),
        "profile_status": "mechanical_base",
        "needs_semantic_typing": True,
        "vision_profile": {
            "dominant_hex": hex_color,
            "dominant_rgb": [int(round(x)) for x in rgb],
            "hsv": [round(h, 4), round(s, 4), round(v, 4)],
            "canvas_width": int(w_px),
            "canvas_height": int(h_px),
            "content_width": int(bw),
            "content_height": int(bh),
            "content_aspect_ratio": aspect,
            "content_fill_ratio": fill,
            "opaque_canvas_ratio": round(opaque, 4),
        },
    }
