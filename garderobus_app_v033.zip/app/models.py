from typing import Literal
from pydantic import BaseModel, Field


LaundryGroup = Literal["white", "light", "dark", "color", "delicate", "handwash", "dry_clean", "unknown"]
GarmentStatus = Literal["clean", "worn", "laundry", "washing", "drying", "repair", "seasonal", "loaned"]


class GarmentManual(BaseModel):
    title: str = "Вещь"
    category: str
    subtype: str = ""
    color_family: str = "neutral"
    color_name: str = ""
    temperature: Literal["warm", "cool", "neutral", "unknown"] = "unknown"
    value: Literal["light", "medium", "dark", "unknown"] = "unknown"
    chroma: Literal["muted", "medium", "bright", "unknown"] = "unknown"
    print: str = "solid"
    print_colors: list[str] = []
    silhouette: str = ""
    length: str = ""
    fit: str = ""
    fabric_family: str = "unknown"
    texture: list[str] = []
    warmth: Literal["very_light", "light", "medium", "warm", "very_warm", "unknown"] = "unknown"
    layer_roles: list[str] = []
    can_layer_over: list[str] = []
    cannot_layer_over: list[str] = []
    style_tags: list[str] = []
    occasion_tags: list[str] = ["everyday"]
    seasons: list[str] = ["all"]
    laundry_group: LaundryGroup = "unknown"
    notes: str = ""


class AppearanceProfile(BaseModel):
    # Filled manually by the stylist after consultation.
    summary: str = ""
    color_direction: str = ""
    contrast: str = ""
    line_direction: str = ""
    style_directions: list[str] = []
    flattering_colors: list[str] = []
    avoid_colors: list[str] = []
    hairstyles: list[str] = []
    makeup_sets: list[str] = []
    personal_rules: list[str] = []
    status: Literal["draft", "ready"] = "draft"


class TesterCodeRequest(BaseModel):
    code: str = Field(min_length=4, max_length=64)


class PreferenceProfile(BaseModel):
    goal: str = ""
    style_identity: str = ""
    lifestyle: str = ""
    constraints: str = ""
    favorite_items: str = ""
    shopping_attitude: str = ""


class OutfitRequest(BaseModel):
    occasion: str = "everyday"
    mood: str = "random"
    novelty: float = Field(default=0.55, ge=0, le=1)


class OutfitResult(BaseModel):
    garment_ids: list[int]
    explanation: list[str]
    hairstyle: str = ""
    makeup: str = ""


class CropRequest(BaseModel):
    photo_id: int
    x: float = Field(ge=0, le=1)
    y: float = Field(ge=0, le=1)
    w: float = Field(gt=0, le=1)
    h: float = Field(gt=0, le=1)
    garment: GarmentManual
    simple_background_cleanup: bool = False


class ReplaceOutfitRequest(BaseModel):
    garment_ids: list[int]
    replace_id: int
    occasion: str = "everyday"
    mood: str = "random"
    novelty: float = Field(default=0.65, ge=0, le=1)
