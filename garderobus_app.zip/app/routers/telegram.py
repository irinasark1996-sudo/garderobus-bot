from fastapi import APIRouter, Request

from ..config import settings
from ..services.bot_engine import handle_update

router = APIRouter()


@router.post("/telegram/webhook")
async def telegram_webhook(request: Request):
    secret = settings.resolved_webhook_secret
    if secret:
        received = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
        if received != secret:
            return {"ok": False}
    update = await request.json()
    await handle_update(update)
    return {"ok": True}
