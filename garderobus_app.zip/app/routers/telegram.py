from fastapi import APIRouter, HTTPException, Request

from ..config import settings
from ..services.bot_engine import handle_update
from ..services.telegram import TelegramAPI

router = APIRouter()


async def _process_webhook(request: Request):
    secret = settings.resolved_webhook_secret
    received = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
    if secret and received != secret:
        print("Telegram webhook rejected: bad secret header", flush=True)
        raise HTTPException(status_code=403, detail="Bad webhook secret")

    update = await request.json()
    print(
        f"Telegram update received: update_id={update.get('update_id')} "
        f"message={bool(update.get('message'))} callback={bool(update.get('callback_query'))}",
        flush=True,
    )
    try:
        await handle_update(update)
    except Exception as exc:
        print(f"Telegram update handler failed: {type(exc).__name__}: {exc}", flush=True)
        raise
    return {"ok": True}


@router.post("/telegram/webhook")
async def telegram_webhook(request: Request):
    return await _process_webhook(request)


# Temporary compatibility alias for beta diagnostics.
@router.post("/webhook")
async def telegram_webhook_alias(request: Request):
    return await _process_webhook(request)


@router.get("/telegram/status")
async def telegram_status():
    """Safe beta diagnostic: never returns the bot token or webhook secret."""
    if not settings.telegram_bot_token:
        return {"ok": False, "telegram_configured": False}
    tg = TelegramAPI()
    me = await tg.get_me()
    info = await tg.get_webhook_info()
    return {
        "ok": True,
        "telegram_configured": True,
        "bot": {
            "id": me.get("id"),
            "username": me.get("username"),
            "first_name": me.get("first_name"),
        },
        "webhook": {
            "url": info.get("url", ""),
            "has_custom_certificate": info.get("has_custom_certificate", False),
            "pending_update_count": info.get("pending_update_count", 0),
            "last_error_date": info.get("last_error_date"),
            "last_error_message": info.get("last_error_message"),
            "max_connections": info.get("max_connections"),
            "allowed_updates": info.get("allowed_updates"),
        },
        "expected_webhook": settings.resolved_public_base_url.rstrip("/") + "/telegram/webhook",
        "public_base_url": settings.resolved_public_base_url,
        "mini_app_url": settings.resolved_mini_app_url,
    }
