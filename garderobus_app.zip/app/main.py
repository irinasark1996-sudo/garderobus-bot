from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from . import db
from .config import settings
from .routers.api import router as api_router
from .routers.telegram import router as telegram_router


async def _configure_telegram() -> None:
    if not settings.auto_configure_webhook:
        return
    if not settings.telegram_bot_token:
        return
    base = settings.resolved_public_base_url
    if not base.startswith("https://"):
        return
    try:
        from .services.telegram import TelegramAPI
        tg = TelegramAPI()
        await tg.call(
            "setWebhook",
            {
                "url": base.rstrip("/") + "/telegram/webhook",
                "allowed_updates": ["message", "callback_query"],
                "drop_pending_updates": False,
                "secret_token": settings.resolved_webhook_secret,
            },
        )
        await tg.set_my_commands()
        print(f"Telegram webhook ready at {base}/telegram/webhook")
    except Exception as exc:
        # The web service should still become healthy so deployment logs can be inspected.
        print(f"Telegram webhook setup failed: {type(exc).__name__}: {exc}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings.storage_path.mkdir(parents=True, exist_ok=True)
    (settings.storage_path / "media").mkdir(parents=True, exist_ok=True)
    (settings.storage_path / "garments").mkdir(parents=True, exist_ok=True)
    (settings.storage_path / "profiles").mkdir(parents=True, exist_ok=True)
    db.ensure_db()
    await _configure_telegram()
    yield


app = FastAPI(title="Garderobus / Kapsula AI", version="0.3.0", lifespan=lifespan)
app.include_router(api_router)
app.include_router(telegram_router)
app.mount("/media", StaticFiles(directory=str(settings.storage_path / "media")), name="media")
app.mount("/static", StaticFiles(directory="miniapp"), name="static")


@app.get("/health")
def health():
    return {
        "ok": True,
        "openai_configured": bool(settings.openai_api_key),
        "telegram_configured": bool(settings.telegram_bot_token),
        "public_url": settings.resolved_public_base_url,
        "mini_app_url": settings.resolved_mini_app_url,
        "webhook_auto": settings.auto_configure_webhook,
    }


@app.get("/app")
def mini_app():
    return FileResponse("miniapp/index.html")


@app.get("/")
def root():
    return RedirectResponse("/app")
