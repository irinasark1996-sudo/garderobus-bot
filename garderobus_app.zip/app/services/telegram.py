from pathlib import Path
from typing import Any

import httpx

from ..config import settings


class TelegramAPI:
    def __init__(self) -> None:
        if not settings.telegram_bot_token:
            raise RuntimeError("TELEGRAM_BOT_TOKEN is not configured")
        self.base = f"https://api.telegram.org/bot{settings.telegram_bot_token}"
        self.file_base = f"https://api.telegram.org/file/bot{settings.telegram_bot_token}"

    async def call(self, method: str, payload: dict[str, Any] | None = None) -> Any:
        async with httpx.AsyncClient(timeout=40) as client:
            response = await client.post(f"{self.base}/{method}", json=payload or {})
            response.raise_for_status()
            data = response.json()
            if not data.get("ok"):
                raise RuntimeError(data)
            return data["result"]

    async def call_multipart(
        self,
        method: str,
        data: dict[str, Any],
        files: dict[str, tuple[str, bytes, str]],
    ) -> Any:
        async with httpx.AsyncClient(timeout=60) as client:
            response = await client.post(f"{self.base}/{method}", data=data, files=files)
            response.raise_for_status()
            payload = response.json()
            if not payload.get("ok"):
                raise RuntimeError(payload)
            return payload["result"]

    async def send_message(
        self,
        chat_id: int,
        text: str,
        reply_markup: dict | None = None,
        parse_mode: str | None = None,
    ) -> None:
        payload: dict[str, Any] = {"chat_id": chat_id, "text": text}
        if reply_markup:
            payload["reply_markup"] = reply_markup
        if parse_mode:
            payload["parse_mode"] = parse_mode
        await self.call("sendMessage", payload)

    async def send_photo(
        self,
        chat_id: int,
        path: str | Path,
        caption: str = "",
        reply_markup: dict | None = None,
    ) -> None:
        p = Path(path)
        data: dict[str, Any] = {"chat_id": str(chat_id), "caption": caption}
        if reply_markup:
            import json
            data["reply_markup"] = json.dumps(reply_markup, ensure_ascii=False)
        await self.call_multipart(
            "sendPhoto",
            data,
            {"photo": (p.name, p.read_bytes(), "image/png" if p.suffix.lower() == ".png" else "image/jpeg")},
        )

    async def send_chat_action(self, chat_id: int, action: str = "typing") -> None:
        await self.call("sendChatAction", {"chat_id": chat_id, "action": action})

    async def answer_callback(self, callback_query_id: str, text: str = "") -> None:
        payload = {"callback_query_id": callback_query_id}
        if text:
            payload["text"] = text
        await self.call("answerCallbackQuery", payload)

    async def download_file(self, file_id: str) -> tuple[bytes, str]:
        file_obj = await self.call("getFile", {"file_id": file_id})
        file_path = file_obj["file_path"]
        async with httpx.AsyncClient(timeout=45) as client:
            response = await client.get(f"{self.file_base}/{file_path}")
            response.raise_for_status()
            return response.content, file_path

    async def get_updates(self, offset: int | None = None, timeout: int = 25) -> list[dict]:
        payload: dict[str, Any] = {
            "timeout": timeout,
            "allowed_updates": ["message", "callback_query"],
        }
        if offset is not None:
            payload["offset"] = offset
        return await self.call("getUpdates", payload)

    async def delete_webhook(self, drop_pending_updates: bool = False) -> None:
        await self.call("deleteWebhook", {"drop_pending_updates": drop_pending_updates})

    async def get_me(self) -> dict:
        return await self.call("getMe")

    async def get_webhook_info(self) -> dict:
        return await self.call("getWebhookInfo")

    async def set_my_commands(self) -> None:
        commands = [
            {"command": "start", "description": "Начать или открыть главное меню"},
            {"command": "profile", "description": "Профиль внешности"},
            {"command": "add", "description": "Добавить вещь"},
            {"command": "wardrobe", "description": "Мой гардероб"},
            {"command": "laundry", "description": "Корзины для стирки"},
            {"command": "done", "description": "Закончить загрузку вещей"},
            {"command": "help", "description": "Как пользоваться ботом"},
        ]
        await self.call("setMyCommands", {"commands": commands})


def web_app_button(text: str = "Открыть Капсулу") -> dict | None:
    if not settings.mini_app_is_public:
        return None
    return {"text": text, "web_app": {"url": settings.resolved_mini_app_url}}


def main_menu_keyboard(has_profile: bool = False) -> dict:
    rows: list[list[dict]] = [
        [
            {"text": "✨ Профиль внешности", "callback_data": "menu:profile"},
            {"text": "👗 Добавить вещь", "callback_data": "menu:add"},
        ],
        [
            {"text": "🗂 Гардероб", "callback_data": "menu:wardrobe"},
            {"text": "🧺 Стирка", "callback_data": "menu:laundry"},
        ],
    ]
    app_btn = web_app_button()
    if app_btn:
        rows.append([app_btn])
    if not has_profile:
        rows.insert(0, [{"text": "Начать типирование", "callback_data": "profile:start"}])
    return {"inline_keyboard": rows}


def onboarding_keyboard() -> dict:
    rows = [
        [{"text": "✨ Начать с внешности", "callback_data": "profile:start"}],
        [{"text": "👗 Сначала загрузить гардероб", "callback_data": "wardrobe:start"}],
        [{"text": "Что умеет Капсула?", "callback_data": "about"}],
    ]
    app_btn = web_app_button()
    if app_btn:
        rows.append([app_btn])
    return {"inline_keyboard": rows}


def profile_review_keyboard() -> dict:
    return {
        "inline_keyboard": [
            [{"text": "✅ Всё похоже", "callback_data": "profile:confirm"}],
            [{"text": "🔄 Переснять профиль", "callback_data": "profile:redo"}],
            [{"text": "👗 Перейти к гардеробу", "callback_data": "wardrobe:start"}],
        ]
    }


def garment_review_keyboard(garment_id: int) -> dict:
    rows = [
        [{"text": "✅ Добавить в гардероб", "callback_data": f"garment:confirm:{garment_id}"}],
        [
            {"text": "✏️ Исправить", "callback_data": f"garment:edit:{garment_id}"},
            {"text": "🗑 Не добавлять", "callback_data": f"garment:delete:{garment_id}"},
        ],
    ]
    app_btn = web_app_button("Открыть гардероб")
    if app_btn:
        rows.append([app_btn])
    return {"inline_keyboard": rows}


def wardrobe_item_keyboard(garment_id: int, status: str) -> dict:
    rows: list[list[dict]] = []
    if status == "laundry":
        rows.append([{"text": "✅ Уже чистая", "callback_data": f"status:clean:{garment_id}"}])
    else:
        rows.append([{"text": "🧺 В стирку", "callback_data": f"status:laundry:{garment_id}"}])
    return {"inline_keyboard": rows}
