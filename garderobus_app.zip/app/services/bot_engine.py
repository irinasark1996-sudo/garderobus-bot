import asyncio
from pathlib import Path
from typing import Any

from .. import db
from ..config import settings
from .garment_processing import public_media_copy, remove_background, save_original
from .laundry import BUCKET_LABELS, group_laundry
from .openai_vision import AIUnavailable, analyze_appearance, analyze_garment, revise_garment
from .telegram import (
    TelegramAPI,
    garment_review_keyboard,
    main_menu_keyboard,
    onboarding_keyboard,
    profile_review_keyboard,
    wardrobe_item_keyboard,
)

PROFILE_STEPS = [
    ("profile_face_front", "face_front", "1/3. Пришли фото лица прямо спереди. Без фильтра, лучше при дневном нейтральном свете."),
    ("profile_face_34", "face_34", "2/3. Теперь фото лица в ракурсе примерно ¾."),
    (
        "profile_full_body",
        "full_body",
        "3/3. Теперь фото в полный рост. Лучше стоя прямо, камера примерно на уровне середины корпуса, в одежде, которая не слишком скрывает линии фигуры.",
    ),
]

LAUNDRY_LABELS = BUCKET_LABELS
STATUS_LABELS = {
    "clean": "чистая",
    "worn": "надета",
    "laundry": "в стирке",
    "washing": "стирается",
    "drying": "сушится",
    "repair": "в ремонте",
    "seasonal": "убрана на сезон",
    "loaned": "одолжена",
}


def _profile_summary(profile: dict[str, Any]) -> str:
    colors = ", ".join(profile.get("flattering_color_families") or []) or "пока без уверенного вывода"
    face_notes = "; ".join(profile.get("face_shape_notes") or []) or "нет устойчивых наблюдений"
    body_notes = "; ".join(profile.get("body_line_notes") or []) or "нет устойчивых наблюдений"
    hypotheses = "; ".join(profile.get("styling_hypotheses") or []) or "будут уточняться по твоим реакциям"
    caveats = "; ".join(profile.get("caveats") or [])
    confidence = round(float(profile.get("confidence") or 0) * 100)
    text = (
        "Черновой профиль внешности готов. Это не жёсткий типаж — приложение будет уточнять его по твоим выборам.\n\n"
        f"Температура: {profile.get('temperature', '—')}\n"
        f"Глубина: {profile.get('depth', '—')}\n"
        f"Контраст: {profile.get('contrast', '—')}\n"
        f"Насыщенность: {profile.get('chroma', '—')}\n"
        f"Линии: {profile.get('line_softness', '—')}\n"
        f"Масштаб черт: {profile.get('feature_scale', '—')}\n\n"
        f"Лицо: {face_notes}\n"
        f"Линии фигуры: {body_notes}\n"
        f"Предположительно удачные цветовые семьи: {colors}\n"
        f"Стилевые гипотезы: {hypotheses}\n\n"
        f"Уверенность анализа: {confidence}%"
    )
    if caveats:
        text += f"\nЧто может искажать оценку: {caveats}"
    return text


def _garment_summary(analysis: dict[str, Any]) -> str:
    colors = ", ".join(c.get("name", "") for c in (analysis.get("colors") or [])[:3] if c.get("name")) or "не определены"
    roles = ", ".join(analysis.get("layer_roles") or []) or "не определены"
    fabrics = ", ".join(analysis.get("fabric_guess") or []) or "не определено"
    questions = analysis.get("uncertainty_questions") or []
    confidence = round(float(analysis.get("confidence") or 0) * 100)
    text = (
        f"{analysis.get('title', 'Вещь')}\n"
        f"Категория: {analysis.get('category', '—')} / {analysis.get('subtype', '—')}\n"
        f"Цвета: {colors}\n"
        f"Принт: {analysis.get('print', '—')}\n"
        f"Силуэт: {analysis.get('silhouette', '—')}\n"
        f"Посадка: {analysis.get('fit', '—')}\n"
        f"Прозрачность: {analysis.get('transparency', '—')}\n"
        f"Предполагаемая ткань: {fabrics}\n"
        f"Роль в слоях: {roles}\n"
        f"Предварительная корзина: {LAUNDRY_LABELS.get(analysis.get('laundry_group', 'unknown'), 'Нужно уточнить')}\n"
        f"Уверенность: {confidence}%"
    )
    if questions:
        text += "\n\nНужно уточнить:\n• " + "\n• ".join(questions[:3])
    return text


def _help_text() -> str:
    return (
        "Как работает Капсула:\n\n"
        "1. Типирование: пришли 3 фотографии по подсказкам бота.\n"
        "2. Гардероб: отправляй по одной вещи на фото. Я отделю вещь от фона и создам карточку.\n"
        "3. Если AI ошибся — нажми «Исправить» и напиши обычным текстом, что именно неверно.\n"
        "4. /wardrobe показывает последние вещи и позволяет отправить их в стирку.\n"
        "5. /laundry показывает бельевые корзины.\n"
        "6. /done завершает режим массовой загрузки, но добавлять вещи можно позже через /add."
    )


async def _ask_profile_step(tg: TelegramAPI, chat_id: int, index: int) -> None:
    state, _, text = PROFILE_STEPS[index]
    await tg.send_message(chat_id, text)


async def start_profile(user_id: int, chat_id: int, tg: TelegramAPI) -> None:
    db.clear_profile_photos(user_id)
    db.set_state(user_id, PROFILE_STEPS[0][0], {"profile_index": 0})
    await tg.send_message(
        chat_id,
        "Сделаем базовый визуальный профиль. Он нужен не для того, чтобы приклеить к тебе один «тип», а чтобы стартово понимать цвет, контраст, масштаб и линии. Анализ потом будет корректироваться по твоим выборам.",
    )
    await _ask_profile_step(tg, chat_id, 0)


async def _save_profile_photo(user_id: int, chat_id: int, file_id: str, step_index: int) -> None:
    tg = TelegramAPI()
    await tg.send_chat_action(chat_id, "typing")
    data, remote_path = await tg.download_file(file_id)
    suffix = Path(remote_path).suffix or ".jpg"
    folder = settings.storage_path / "profiles"
    folder.mkdir(parents=True, exist_ok=True)
    _, kind, _ = PROFILE_STEPS[step_index]
    path = folder / f"{user_id}_{kind}{suffix}"
    path.write_bytes(data)
    db.add_profile_photo(user_id, str(path), kind=kind)

    if step_index < len(PROFILE_STEPS) - 1:
        next_index = step_index + 1
        db.set_state(user_id, PROFILE_STEPS[next_index][0], {"profile_index": next_index})
        await _ask_profile_step(tg, chat_id, next_index)
        return

    db.set_state(user_id, "profile_analyzing", {})
    await tg.send_message(chat_id, "Фотографий достаточно. Анализирую внешность — это может занять немного времени…")
    try:
        profile = await asyncio.to_thread(analyze_appearance, db.profile_photo_paths(user_id))
    except AIUnavailable as exc:
        db.set_state(user_id, "profile_full_body", {"profile_index": 2})
        await tg.send_message(chat_id, f"AI-анализ пока не запускается: {exc}")
        return
    except Exception as exc:
        db.set_state(user_id, "profile_full_body", {"profile_index": 2})
        await tg.send_message(chat_id, f"Не удалось закончить анализ. Можно повторить последний кадр. Техническая ошибка: {type(exc).__name__}")
        return

    db.save_profile(user_id, profile.model_dump())
    db.set_state(user_id, "profile_review", {})
    await tg.send_message(chat_id, _profile_summary(profile.model_dump()), profile_review_keyboard())


async def _process_garment_photo(user_id: int, chat_id: int, file_id: str) -> None:
    tg = TelegramAPI()
    await tg.send_message(chat_id, "Получила вещь. Отделяю её от фона и создаю карточку…")
    await tg.send_chat_action(chat_id, "upload_photo")
    try:
        data, remote_path = await tg.download_file(file_id)
        original = save_original(data, Path(remote_path).suffix or ".jpg")
        cutout = await asyncio.to_thread(remove_background, original)
        public_media_copy(cutout)
        analysis = await asyncio.to_thread(analyze_garment, cutout)
    except AIUnavailable as exc:
        await tg.send_message(chat_id, f"AI-анализ пока не запускается: {exc}")
        return
    except Exception as exc:
        await tg.send_message(chat_id, f"Не удалось обработать эту фотографию. Попробуй другой кадр. Техническая ошибка: {type(exc).__name__}")
        return

    garment_id = db.add_garment(user_id, str(cutout), str(original), analysis.model_dump())
    await tg.send_photo(
        chat_id,
        cutout,
        caption=_garment_summary(analysis.model_dump()),
        reply_markup=garment_review_keyboard(garment_id),
    )


async def _revise_garment_from_text(user_id: int, chat_id: int, correction: str) -> None:
    tg = TelegramAPI()
    context = db.get_context(user_id)
    garment_id = int(context.get("garment_id", 0) or 0)
    record = db.get_garment_record(user_id, garment_id)
    if not record:
        db.set_state(user_id, "wardrobe_upload", {})
        await tg.send_message(chat_id, "Не нашла карточку, которую нужно было исправить. Отправь вещь ещё раз.")
        return
    await tg.send_message(chat_id, "Поняла. Пересобираю карточку с учётом твоего уточнения…")
    try:
        revised = await asyncio.to_thread(
            revise_garment,
            record["image_path"],
            record["payload"],
            correction,
        )
    except AIUnavailable as exc:
        await tg.send_message(chat_id, f"AI-анализ пока не запускается: {exc}")
        return
    except Exception as exc:
        await tg.send_message(chat_id, f"Не удалось применить уточнение. Ошибка: {type(exc).__name__}")
        return
    db.update_garment_payload(user_id, garment_id, revised.model_dump())
    db.set_state(user_id, "wardrobe_upload", {})
    await tg.send_photo(
        chat_id,
        record["image_path"],
        caption="Обновлённая карточка:\n\n" + _garment_summary(revised.model_dump()),
        reply_markup=garment_review_keyboard(garment_id),
    )


async def show_wardrobe(user_id: int, chat_id: int, tg: TelegramAPI) -> None:
    items = [g for g in db.list_garments(user_id) if g.get("confirmed")]
    if not items:
        await tg.send_message(chat_id, "Гардероб пока пуст. Нажми «Добавить вещь» или отправь фотографию вещи.", main_menu_keyboard(bool(db.get_profile(user_id))))
        return
    await tg.send_message(chat_id, f"В гардеробе {len(items)} подтверждённых вещей. Показываю последние {min(6, len(items))}.")
    for g in items[:6]:
        record = db.get_garment_record(user_id, int(g["id"]))
        if not record:
            continue
        caption = (
            f"{g.get('title', 'Вещь')}\n"
            f"Статус: {STATUS_LABELS.get(g.get('status', 'clean'), g.get('status', 'clean'))}\n"
            f"Корзина: {LAUNDRY_LABELS.get(g.get('laundry_group', 'unknown'), 'Нужно уточнить')}"
        )
        await tg.send_photo(
            chat_id,
            record["image_path"],
            caption=caption,
            reply_markup=wardrobe_item_keyboard(int(g["id"]), g.get("status", "clean")),
        )


async def show_laundry(user_id: int, chat_id: int, tg: TelegramAPI) -> None:
    items = db.list_garments(user_id)
    buckets = group_laundry(items)
    lines = ["Корзины для стирки:"]
    total = 0
    for key, label in LAUNDRY_LABELS.items():
        count = len(buckets.get(key, []))
        total += count
        lines.append(f"• {label}: {count}")
    if total == 0:
        lines.append("\nСейчас в стирке ничего нет.")
    else:
        lines.append(f"\nВсего вещей в корзинах: {total}")
    await tg.send_message(chat_id, "\n".join(lines), main_menu_keyboard(bool(db.get_profile(user_id))))


async def show_profile(user_id: int, chat_id: int, tg: TelegramAPI) -> None:
    profile = db.get_profile(user_id)
    if not profile:
        await tg.send_message(chat_id, "Профиль внешности ещё не создан.", {"inline_keyboard": [[{"text": "Начать типирование", "callback_data": "profile:start"}]]})
        return
    keyboard = {
        "inline_keyboard": [
            [{"text": "🔄 Переснять профиль", "callback_data": "profile:redo"}],
            [{"text": "← В меню", "callback_data": "menu:main"}],
        ]
    }
    await tg.send_message(chat_id, _profile_summary(profile), keyboard)


async def handle_update(update: dict[str, Any]) -> None:
    tg = TelegramAPI()

    callback = update.get("callback_query")
    if callback:
        user = callback.get("from", {})
        user_id = int(user.get("id", 0))
        chat_id = int(callback.get("message", {}).get("chat", {}).get("id", user_id))
        db.upsert_user(user_id, user.get("first_name", ""), user.get("username", ""))
        data = callback.get("data", "")
        await tg.answer_callback(callback.get("id", ""))

        if data in {"profile:start", "profile:redo"}:
            await start_profile(user_id, chat_id, tg)
        elif data == "profile:confirm":
            db.set_state(user_id, "wardrobe_upload", {})
            await tg.send_message(chat_id, "Профиль сохранён. Теперь можно загружать вещи — по одной фотографии на предмет.", main_menu_keyboard(True))
        elif data in {"wardrobe:start", "menu:add"}:
            db.set_state(user_id, "wardrobe_upload", {})
            await tg.send_message(chat_id, "Отправь фотографию одной вещи. Лучше целиком, без сильных теней и без других предметов поверх неё. Для окончания массовой загрузки — /done.")
        elif data == "about":
            await tg.send_message(chat_id, _help_text(), onboarding_keyboard())
        elif data in {"menu:main"}:
            await tg.send_message(chat_id, "Главное меню", main_menu_keyboard(bool(db.get_profile(user_id))))
        elif data == "menu:profile":
            await show_profile(user_id, chat_id, tg)
        elif data == "menu:wardrobe":
            await show_wardrobe(user_id, chat_id, tg)
        elif data == "menu:laundry":
            await show_laundry(user_id, chat_id, tg)
        elif data.startswith("garment:confirm:"):
            garment_id = int(data.rsplit(":", 1)[1])
            if db.get_garment(user_id, garment_id):
                db.confirm_garment(user_id, garment_id)
                db.set_state(user_id, "wardrobe_upload", {})
                await tg.send_message(chat_id, "Вещь добавлена. Можешь сразу отправить следующую фотографию.", main_menu_keyboard(bool(db.get_profile(user_id))))
        elif data.startswith("garment:edit:"):
            garment_id = int(data.rsplit(":", 1)[1])
            if db.get_garment(user_id, garment_id):
                db.set_state(user_id, "garment_edit_text", {"garment_id": garment_id})
                await tg.send_message(
                    chat_id,
                    "Напиши обычным сообщением, что я определила неверно. Например: «это не жакет, а тонкий кардиган; его нельзя надевать поверх свитера» или «рубашка прозрачная и может быть и верхом, и вторым слоем».",
                )
        elif data.startswith("garment:delete:"):
            garment_id = int(data.rsplit(":", 1)[1])
            db.delete_garment(user_id, garment_id)
            db.set_state(user_id, "wardrobe_upload", {})
            await tg.send_message(chat_id, "Не добавляю эту вещь. Можно прислать другой кадр.")
        elif data.startswith("status:laundry:"):
            garment_id = int(data.rsplit(":", 1)[1])
            db.set_garment_status(user_id, garment_id, "laundry")
            await tg.send_message(chat_id, "Вещь отправлена в бельевую корзину и временно исключена из стилиста.")
        elif data.startswith("status:clean:"):
            garment_id = int(data.rsplit(":", 1)[1])
            db.set_garment_status(user_id, garment_id, "clean")
            await tg.send_message(chat_id, "Вещь снова чистая и доступна стилисту.")
        return

    message = update.get("message")
    if not message:
        return
    user = message.get("from", {})
    user_id = int(user.get("id", 0))
    chat_id = int(message.get("chat", {}).get("id", user_id))
    db.upsert_user(user_id, user.get("first_name", ""), user.get("username", ""))
    text = (message.get("text") or "").strip()
    state = db.get_state(user_id)

    if text in {"/start", "/menu"}:
        has_profile = bool(db.get_profile(user_id))
        if state == "new" and not has_profile and not db.list_garments(user_id):
            await tg.send_message(
                chat_id,
                "Капсула — личный AI-гардероб. Бот помогает создать профиль внешности и загрузить вещи, а ежедневный стилист затем работает с уже собранным гардеробом.",
                onboarding_keyboard(),
            )
        else:
            await tg.send_message(chat_id, "Главное меню", main_menu_keyboard(has_profile))
        return
    if text == "/help":
        await tg.send_message(chat_id, _help_text(), main_menu_keyboard(bool(db.get_profile(user_id))))
        return
    if text == "/profile":
        await show_profile(user_id, chat_id, tg)
        return
    if text == "/add":
        db.set_state(user_id, "wardrobe_upload", {})
        await tg.send_message(chat_id, "Отправь фотографию одной вещи. Когда закончишь — /done.")
        return
    if text == "/wardrobe":
        await show_wardrobe(user_id, chat_id, tg)
        return
    if text == "/laundry":
        await show_laundry(user_id, chat_id, tg)
        return
    if text == "/done":
        db.set_state(user_id, "ready", {})
        await tg.send_message(chat_id, "Массовая загрузка остановлена. Новые вещи всегда можно добавить через /add.", main_menu_keyboard(bool(db.get_profile(user_id))))
        return

    if state == "garment_edit_text" and text:
        asyncio.create_task(_revise_garment_from_text(user_id, chat_id, text))
        return

    photos = message.get("photo") or []
    if photos:
        best = photos[-1]
        if state in {s[0] for s in PROFILE_STEPS}:
            index = next(i for i, item in enumerate(PROFILE_STEPS) if item[0] == state)
            asyncio.create_task(_save_profile_photo(user_id, chat_id, best["file_id"], index))
            return
        if state == "profile_analyzing":
            await tg.send_message(chat_id, "Я ещё анализирую предыдущие фотографии. Подожди немного.")
            return
        if state == "garment_edit_text":
            await tg.send_message(chat_id, "Сейчас я жду текстовое исправление к предыдущей карточке. Напиши, что именно неверно.")
            return
        if state == "new":
            db.set_state(user_id, "wardrobe_upload", {})
        asyncio.create_task(_process_garment_photo(user_id, chat_id, best["file_id"]))
        return

    if text:
        if state in {"wardrobe_upload", "ready", "new"}:
            await tg.send_message(chat_id, "Отправь фотографию вещи или выбери действие в меню.", main_menu_keyboard(bool(db.get_profile(user_id))))
        else:
            await tg.send_message(chat_id, "Сейчас я жду фотографию по текущему шагу. Если хочешь начать заново — /start.")
