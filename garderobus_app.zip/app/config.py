from pathlib import Path
import os
import secrets

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    openai_api_key: str = ""
    openai_model: str = "gpt-5-mini"

    telegram_bot_token: str = ""
    telegram_webhook_secret: str = ""
    telegram_polling_timeout: int = 25

    # Leave these empty in Railway. They will be derived from RAILWAY_PUBLIC_DOMAIN.
    public_base_url: str = ""
    mini_app_url: str = ""
    railway_public_domain: str = ""
    auto_configure_webhook: bool = True

    database_path: str = "./storage/kapsula.sqlite3"
    storage_dir: str = "./storage"
    dev_allow_insecure_id: bool = False

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def db_path(self) -> Path:
        return Path(self.database_path)

    @property
    def storage_path(self) -> Path:
        return Path(self.storage_dir)

    @property
    def resolved_public_base_url(self) -> str:
        explicit = self.public_base_url.strip().rstrip("/")
        if explicit:
            return explicit
        domain = (self.railway_public_domain or os.getenv("RAILWAY_PUBLIC_DOMAIN", "")).strip()
        if domain:
            return f"https://{domain.strip('/')}"
        return "http://localhost:8000"

    @property
    def resolved_mini_app_url(self) -> str:
        explicit = self.mini_app_url.strip()
        if explicit:
            return explicit
        return self.resolved_public_base_url.rstrip("/") + "/app"

    @property
    def mini_app_is_public(self) -> bool:
        return self.resolved_mini_app_url.startswith("https://")

    @property
    def resolved_webhook_secret(self) -> str:
        """Return a stable secret. If none is supplied, persist one in the storage volume."""
        if self.telegram_webhook_secret.strip():
            return self.telegram_webhook_secret.strip()
        path = self.storage_path / ".telegram_webhook_secret"
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            if path.exists():
                value = path.read_text(encoding="utf-8").strip()
                if value:
                    return value
            value = secrets.token_urlsafe(32)
            path.write_text(value, encoding="utf-8")
            return value
        except Exception:
            # Last-resort fallback. For Railway we attach a volume, so normally this branch is not used.
            return secrets.token_urlsafe(32)


settings = Settings()
