import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.config import settings
from app.services.telegram import TelegramAPI


async def configure_webhook() -> bool:
    base = settings.resolved_public_base_url
    if not base.startswith("https://"):
        return False
    if not settings.telegram_bot_token:
        return False
    tg = TelegramAPI()
    payload = {
        "url": base.rstrip("/") + "/telegram/webhook",
        "allowed_updates": ["message", "callback_query"],
        "drop_pending_updates": False,
        "secret_token": settings.resolved_webhook_secret,
    }
    await tg.call("setWebhook", payload)
    await tg.set_my_commands()
    return True


async def main():
    ok = await configure_webhook()
    if not ok:
        raise SystemExit("A public HTTPS URL and TELEGRAM_BOT_TOKEN are required")
    print("Telegram webhook configured")


if __name__ == "__main__":
    asyncio.run(main())
