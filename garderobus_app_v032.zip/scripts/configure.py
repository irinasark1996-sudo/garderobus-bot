from getpass import getpass
from pathlib import Path

ENV=Path('.env')

def parse():
    out={}
    if ENV.exists():
        for line in ENV.read_text(encoding='utf-8').splitlines():
            if '=' in line and not line.lstrip().startswith('#'):
                k,v=line.split('=',1);out[k.strip()]=v.strip()
    return out

def secret(label,existing=False):
    p=f"{label}"+(" (Enter — оставить текущее)" if existing else "")+": "
    return getpass(p).strip()

def main():
    cur=parse()
    tg=secret('Telegram bot token',bool(cur.get('TELEGRAM_BOT_TOKEN'))) or cur.get('TELEGRAM_BOT_TOKEN','')
    if not tg: raise SystemExit('TELEGRAM_BOT_TOKEN is required')
    admin_id=input('ADMIN_TELEGRAM_ID (число, можно получить /myid): ').strip() or cur.get('ADMIN_TELEGRAM_ID','0')
    admin_pw=secret('ADMIN_PASSWORD',bool(cur.get('ADMIN_PASSWORD'))) or cur.get('ADMIN_PASSWORD','')
    public=input('PUBLIC_BASE_URL (для локального теста можно пусто): ').strip() or cur.get('PUBLIC_BASE_URL','')
    values={'TELEGRAM_BOT_TOKEN':tg,'ADMIN_TELEGRAM_ID':admin_id,'ADMIN_PASSWORD':admin_pw,'PUBLIC_BASE_URL':public,'DATABASE_PATH':cur.get('DATABASE_PATH','./storage/kapsula.sqlite3'),'STORAGE_DIR':cur.get('STORAGE_DIR','./storage')}
    ENV.write_text('\n'.join(f'{k}={v}' for k,v in values.items())+'\n',encoding='utf-8')
    print('.env сохранён. В нём нет OpenAI API key.')
if __name__=='__main__': main()
