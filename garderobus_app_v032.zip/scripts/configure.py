"""Interactive local secret setup. Secrets are written to .env and never printed back."""
from getpass import getpass
from pathlib import Path
import secrets

ROOT = Path(__file__).resolve().parents[1]
ENV = ROOT / ".env"


def ask_secret(prompt: str, existing: bool) -> str:
    suffix = " (Enter — оставить прежний)" if existing else ""
    value = getpass(prompt + suffix + ": ").strip()
    return value


def load_existing() -> dict[str, str]:
    result: dict[str, str] = {}
    if not ENV.exists():
        return result
    for line in ENV.read_text("utf-8").splitlines():
        if not line or line.lstrip().startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        result[key.strip()] = value.strip()
    return result


def main() -> None:
    current = load_existing()
    print("Kapsula AI — безопасная настройка локальных секретов")
    print("API-ключи вводятся в терминал и не должны отправляться в чат или попадать в Git.\n")

    tg = ask_secret("Вставь токен Telegram-бота из BotFather", bool(current.get("TELEGRAM_BOT_TOKEN")))
    oa = ask_secret("Вставь OpenAI API key", bool(current.get("OPENAI_API_KEY")))

    telegram_token = tg or current.get("TELEGRAM_BOT_TOKEN", "")
    openai_key = oa or current.get("OPENAI_API_KEY", "")
    if not telegram_token:
        raise SystemExit("Telegram token is required")
    if not openai_key:
        raise SystemExit("OpenAI API key is required for AI analysis")

    webhook_secret = current.get("TELEGRAM_WEBHOOK_SECRET") or secrets.token_urlsafe(32).replace(".", "-")
    values = {
        "OPENAI_API_KEY": openai_key,
        "OPENAI_MODEL": current.get("OPENAI_MODEL", "gpt-5-mini"),
        "TELEGRAM_BOT_TOKEN": telegram_token,
        "TELEGRAM_WEBHOOK_SECRET": webhook_secret,
        "TELEGRAM_POLLING_TIMEOUT": current.get("TELEGRAM_POLLING_TIMEOUT", "25"),
        "PUBLIC_BASE_URL": current.get("PUBLIC_BASE_URL", "http://localhost:8000"),
        "MINI_APP_URL": current.get("MINI_APP_URL", "http://localhost:8000/app"),
        "DATABASE_PATH": current.get("DATABASE_PATH", "./storage/kapsula.sqlite3"),
        "STORAGE_DIR": current.get("STORAGE_DIR", "./storage"),
        "DEV_ALLOW_INSECURE_ID": current.get("DEV_ALLOW_INSECURE_ID", "false"),
    }
    body = "# Generated locally by scripts/configure.py. Never commit this file.\n" + "\n".join(
        f"{key}={value}" for key, value in values.items()
    ) + "\n"
    ENV.write_text(body, "utf-8")
    try:
        ENV.chmod(0o600)
    except OSError:
        pass
    print(f"\nГотово. Секреты сохранены в {ENV.name}. Их значения не выводились на экран.")
    print("Для первого запуска: python scripts/run_polling.py")


if __name__ == "__main__":
    main()
