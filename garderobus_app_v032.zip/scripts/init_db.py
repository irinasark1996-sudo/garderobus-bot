from app.db import ensure_db

ensure_db()
print("Database ready")
