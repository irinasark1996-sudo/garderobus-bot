import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app import db
from app.config import settings
from app.services.bot_engine import handle_update
from app.services.telegram import TelegramAPI


async def main() -> None:
    if not settings.telegram_bot_token:
        raise SystemExit("TELEGRAM_BOT_TOKEN is not configured. Run: python scripts/configure.py")

    db.ensure_db()
    tg = TelegramAPI()
    me = await tg.get_me()
    await tg.delete_webhook(drop_pending_updates=False)
    await tg.set_my_commands()
    username = me.get("username") or "bot"
    print(f"Kapsula bot started in polling mode: @{username}")
    print("Press Ctrl+C to stop.")

    offset = None
    while True:
        try:
            updates = await tg.get_updates(offset=offset, timeout=settings.telegram_polling_timeout)
            for update in updates:
                offset = int(update["update_id"]) + 1
                try:
                    await handle_update(update)
                except Exception as exc:
                    print(f"Update {update.get('update_id')} failed: {type(exc).__name__}: {exc}")
        except asyncio.CancelledError:
            raise
        except KeyboardInterrupt:
            return
        except Exception as exc:
            print(f"Polling error: {type(exc).__name__}: {exc}")
            await asyncio.sleep(2)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
