import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl

from fastapi import Header, HTTPException

from .config import settings


def validate_telegram_init_data(init_data: str, max_age_seconds: int = 86400) -> dict:
    if not settings.telegram_bot_token:
        raise HTTPException(503, "TELEGRAM_BOT_TOKEN is not configured")
    pairs = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = pairs.pop("hash", None)
    if not received_hash:
        raise HTTPException(401, "Missing Telegram hash")
    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret_key = hmac.new(b"WebAppData", settings.telegram_bot_token.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret_key, data_check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated, received_hash):
        raise HTTPException(401, "Invalid Telegram signature")
    auth_date = int(pairs.get("auth_date", "0") or 0)
    if auth_date and time.time() - auth_date > max_age_seconds:
        raise HTTPException(401, "Expired Telegram init data")
    user_raw = pairs.get("user")
    return json.loads(user_raw) if user_raw else {}


def current_user_id(
    x_telegram_init_data: str | None = Header(default=None),
    x_dev_user_id: int | None = Header(default=None),
) -> int:
    if x_telegram_init_data:
        user = validate_telegram_init_data(x_telegram_init_data)
        if "id" not in user:
            raise HTTPException(401, "Telegram user missing")
        return int(user["id"])
    if settings.dev_allow_insecure_id and x_dev_user_id:
        return int(x_dev_user_id)
    raise HTTPException(401, "Open inside Telegram or enable local dev auth")
