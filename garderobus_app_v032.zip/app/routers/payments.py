from __future__ import annotations

import html
from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from .. import db
from ..config import settings
from ..services.yookassa import YooKassaError, create_payment, get_payment

router = APIRouter()


def _page(title: str, body: str) -> HTMLResponse:
    return HTMLResponse(f"""<!doctype html><html lang='ru'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{html.escape(title)}</title><style>
*{{box-sizing:border-box}}body{{font-family:system-ui,-apple-system,sans-serif;background:#f3ede3;color:#211d19;margin:0}}main{{max-width:620px;margin:auto;padding:26px 18px 50px}}.brand{{font-size:13px;letter-spacing:.16em;text-transform:uppercase;color:#7d6f62}}h1{{font-size:42px;line-height:1;margin:12px 0}}.card{{background:#fffdf8;border:1px solid #ded3c3;border-radius:26px;padding:22px;margin:18px 0;box-shadow:0 16px 45px rgba(73,56,41,.07)}}.price{{font-size:44px;font-weight:800;margin:14px 0}}.muted{{color:#73695f;line-height:1.55}}ul{{padding-left:20px;line-height:1.7}}button,a.btn{{display:block;width:100%;border:0;border-radius:999px;padding:15px 18px;margin:10px 0;font-size:16px;font-weight:800;text-align:center;text-decoration:none;background:#201c18;color:#fff}}button.secondary{{background:#ece3d6;color:#251f1a}}.tag{{display:inline-block;background:#eee4d7;border-radius:999px;padding:6px 10px;font-size:12px;margin-right:5px}}small{{color:#85796c}}
</style></head><body><main>{body}</main></body></html>""")


@router.get("/buy/{client_code}", response_class=HTMLResponse)
def buy_page(client_code: str):
    user = db.get_user_by_client_code(client_code)
    if not user:
        raise HTTPException(404, "Клиент не найден")
    paid = str(user.get("payment_status") or "unpaid") in {"paid", "active"}
    if paid:
        return _page("Гардеробус", f"<div class='brand'>ГАРДЕРОБУС · {html.escape(client_code)}</div><div class='card'><h1>Оплачено</h1><p class='muted'>Персональный Гардеробус уже активирован. Вернись в Telegram и начни консультацию.</p></div>")
    configured = settings.yookassa_configured
    actions = ""
    if configured:
        actions = f"""<form method='post' action='/buy/{html.escape(client_code)}/pay'><input type='hidden' name='method' value='smart'><button>Карта / ЮKassa — {settings.product_price_rub} ₽</button></form>
<form method='post' action='/buy/{html.escape(client_code)}/pay'><input type='hidden' name='method' value='sbp'><button class='secondary'>СБП — {settings.product_price_rub} ₽</button></form>"""
    else:
        actions = "<p class='muted'><b>Платёжный модуль пока в тестовом режиме.</b><br>Чтобы включить реальные платежи, в Railway добавляются YOOKASSA_SHOP_ID и YOOKASSA_SECRET_KEY. Интерфейс уже готов.</p>"
    body=f"""<div class='brand'>ГАРДЕРОБУС · {html.escape(client_code)}</div><h1>Твой шкаф.<br>Твои правила.</h1><p class='muted'>Разовая подготовка персонального цифрового гардероба. После публикации механический стилист работает без оплаты за каждое действие.</p><div class='card'><span class='tag'>beta</span><div class='price'>{settings.product_price_rub} ₽</div><ul><li>типирование внешности</li><li>оцифровка твоего гардероба</li><li>личные правила сочетаний</li><li>стилист и капсулы из реальных вещей</li><li>стирка и доступность вещей</li></ul>{actions}<small>Цена beta задаётся одной переменной и меняется без перепрошивки приложения.</small></div>"""
    return _page(settings.product_title, body)


@router.post("/buy/{client_code}/pay")
async def buy_pay(client_code: str, method: str = Form("smart")):
    user = db.get_user_by_client_code(client_code)
    if not user:
        raise HTTPException(404, "Клиент не найден")
    if method not in {"smart", "sbp"}:
        raise HTTPException(400, "Неизвестный способ оплаты")
    if not settings.yookassa_configured:
        raise HTTPException(503, "YooKassa пока не подключена")
    try:
        payment = await create_payment(
            amount_rub=settings.product_price_rub,
            description=settings.product_title,
            client_code=client_code,
            user_id=int(user["telegram_user_id"]),
            method=method,
        )
    except YooKassaError as exc:
        raise HTTPException(502, str(exc)) from exc
    confirmation_url = ((payment.get("confirmation") or {}).get("confirmation_url") or "")
    db.create_payment(int(user["telegram_user_id"]), "yookassa:" + method, settings.product_price_rub, str(payment.get("id") or ""), confirmation_url, str(payment.get("status") or "pending"))
    if not confirmation_url:
        raise HTTPException(502, "YooKassa не вернула ссылку оплаты")
    return RedirectResponse(confirmation_url, status_code=303)


@router.post("/payments/yookassa/webhook")
async def yookassa_webhook(request: Request):
    if not settings.yookassa_configured:
        raise HTTPException(503, "YooKassa is not configured")
    payload = await request.json()
    obj = payload.get("object") or {}
    payment_id = str(obj.get("id") or "")
    if not payment_id:
        return {"ok": True}
    # Never trust the incoming body alone: re-read the payment from YooKassa.
    try:
        verified = await get_payment(payment_id)
    except YooKassaError as exc:
        raise HTTPException(502, str(exc)) from exc
    status = str(verified.get("status") or "")
    if status:
        db.update_payment_by_provider_id(payment_id, status)
    return {"ok": True}


@router.get("/pay/return", response_class=HTMLResponse)
def pay_return():
    return _page("Оплата Гардеробуса", "<div class='brand'>ГАРДЕРОБУС</div><div class='card'><h1>Проверяем оплату</h1><p class='muted'>Если платёж прошёл успешно, доступ будет отмечен автоматически. Вернись в Telegram — бот увидит статус.</p></div>")
