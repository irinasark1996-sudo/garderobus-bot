from __future__ import annotations

import hashlib
import html
import json
from pathlib import Path

from fastapi import APIRouter, Cookie, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, RedirectResponse, FileResponse

from .. import db
from ..config import settings
from ..models import CropRequest
from ..services.garment_processing import crop_manual, make_contact_sheet
from ..services.bulk_import import ImportErrorDetail, import_wardrobe_zip
from ..services.telegram import TelegramAPI

router = APIRouter()


def _token() -> str:
    return hashlib.sha256((settings.admin_password + "|garderobus-admin-v1").encode()).hexdigest()


def _auth(cookie: str | None) -> None:
    if not settings.admin_password:
        raise HTTPException(503, "ADMIN_PASSWORD is not configured")
    if cookie != _token():
        raise HTTPException(401, "Admin login required")


def _page(title: str, body: str) -> str:
    return f"""<!doctype html><html lang='ru'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>{html.escape(title)}</title><style>
body{{font-family:system-ui;background:#f6f0e6;color:#241f1a;margin:0;padding:18px}}a{{color:#5e4b3f}}.wrap{{max-width:1050px;margin:auto}}.card{{background:#fffdf8;border:1px solid #ded4c5;border-radius:18px;padding:16px;margin:12px 0}}button,.btn{{border:0;border-radius:999px;background:#241f1a;color:white;padding:10px 14px;font-weight:700;text-decoration:none;display:inline-block}}input,textarea,select{{width:100%;padding:10px;border:1px solid #d8cdbc;border-radius:10px;background:white;margin:5px 0 12px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px}}img{{max-width:100%;border-radius:12px}}small{{color:#786f65}}.chips{{display:flex;gap:6px;flex-wrap:wrap}}.chip{{background:#eee4d7;padding:5px 8px;border-radius:999px;font-size:12px}}.ok{{color:#176b45}}.warn{{color:#9a5a00}}.danger{{background:#8e342e!important}}.row{{display:flex;gap:8px;flex-wrap:wrap;align-items:center}}label{{font-size:12px;font-weight:700;color:#6e6257}}#stage{{position:relative;display:inline-block;touch-action:none;max-width:100%}}#stage img{{display:block;max-height:70vh}}#sel{{position:absolute;border:2px solid #000;background:rgba(255,255,255,.18);display:none;pointer-events:none}}
</style></head><body><div class='wrap'><p><a href='/admin'>← Админка</a></p><h1>{html.escape(title)}</h1>{body}</div></body></html>"""


@router.get("/admin/login", response_class=HTMLResponse)
def login_page():
    return _page("Вход стилиста", "<form method='post'><label>Пароль</label><input type='password' name='password'><button>Войти</button></form>")


@router.post("/admin/login")
def login(password: str = Form(...)):
    if not settings.admin_password or password != settings.admin_password:
        return HTMLResponse(_page("Вход стилиста", "<p>Неверный пароль.</p><a class='btn' href='/admin/login'>Повторить</a>"), status_code=401)
    r = RedirectResponse("/admin", status_code=303)
    r.set_cookie("garderobus_admin", _token(), httponly=True, secure=settings.resolved_public_base_url.startswith("https://"), samesite="lax", max_age=60*60*24*30)
    return r


@router.get("/admin", response_class=HTMLResponse)
def dashboard(garderobus_admin: str | None = Cookie(default=None)):
    _auth(garderobus_admin)
    users = db.list_users()
    batches = db.list_batches()
    u_html = "".join(
        f"<div class='card'><div class='row'><b>{html.escape(u.get('client_code') or 'без ID')}</b><span class='chip'>{html.escape(u.get('payment_status') or 'unpaid')}</span></div><b>{html.escape(u.get('first_name') or '')}</b> · @{html.escape(u.get('username') or '—')}<br><small>этап: {html.escape(u.get('onboarding_state') or '')}</small><br><br><a class='btn' href='/admin/user/{u['telegram_user_id']}'>Открыть клиента</a></div>"
        for u in users[:100]
    ) or "<p>Пока нет клиентов.</p>"
    b_html = "".join(
        f"<div class='card'><b>Пакет #{b['id']}</b> · {html.escape(b.get('first_name') or '')} · {b['photo_count']} фото<br><small>{html.escape(b['status'])}</small><br><br><a class='btn' href='/admin/batch/{b['id']}'>Открыть пакет</a></div>"
        for b in batches[:50]
    ) or "<p>Пока нет пакетов.</p>"
    return _page("Гардеробус — кабинет стилиста", f"<div class='card'><b>Рабочая схема</b><p>Оплата → 5 фото внешности → типирование JSON → весь гардероб → ZIP с manifest + прозрачными коллажами → автоматический импорт → проверка → публикация.</p></div><h2>Клиенты</h2><div class='grid'>{u_html}</div><h2>Пакеты гардероба</h2><div class='grid'>{b_html}</div>")


@router.get("/admin/user/{user_id}", response_class=HTMLResponse)
def user_page(user_id: int, garderobus_admin: str | None = Cookie(default=None)):
    _auth(garderobus_admin)
    user = db.get_user(user_id) or {}
    c = db.get_consultation(user_id) or {"answers":{}}
    p = db.get_profile(user_id) or {}
    photos = db.list_profile_photos(user_id)
    imgs = "".join(f"<div><img src='{x['image_url']}'><small>{html.escape(x['kind'])}</small></div>" for x in photos)
    a=c.get('answers') or {}
    profile_json=html.escape(json.dumps(p,ensure_ascii=False,indent=2)) if p else ""
    status=html.escape(user.get('payment_status') or 'unpaid')
    code=html.escape(user.get('client_code') or '—')
    body=f"""
<div class='card'><div class='row'><h2 style='margin:0'>{code}</h2><span class='chip'>{status}</span></div><b>{html.escape(user.get('first_name') or '')}</b> · @{html.escape(user.get('username') or '—')}<p><b>Цель:</b> {html.escape(a.get('goal','—'))}<br><b>Образ жизни:</b> {html.escape(a.get('lifestyle','—'))}<br><b>Предпочтения:</b> {html.escape(a.get('preferences','—'))}</p><div class='row'><form method='post' action='/admin/user/{user_id}/payment'><input type='hidden' name='status' value='paid'><button>Отметить оплаченным</button></form><form method='post' action='/admin/user/{user_id}/payment'><input type='hidden' name='status' value='unpaid'><button class='danger'>Снять оплату</button></form><a class='btn' href='/buy/{code}'>Открыть web-checkout</a></div></div>
<h2>Фото внешности</h2><div class='grid'>{imgs or '<p>Фото ещё не загружены.</p>'}</div>
<div class='card'><h2>Типирование</h2><p><small>Сюда загружается результат неизменного промпта <b>garderobus.appearance.v1</b>. После импорта пользователь автоматически получает доступ к этапу гардероба.</small></p><form method='post' action='/admin/user/{user_id}/profile-json' enctype='multipart/form-data'><label>appearance.json</label><input type='file' name='profile_file' accept='.json,application/json' required><button>Загрузить типирование</button></form>{('<details><summary>Текущий JSON</summary><pre style="white-space:pre-wrap">'+profile_json+'</pre></details>') if profile_json else ''}</div>
<div class='card'><h2>Ручное резервное заполнение</h2><form method='post' action='/admin/user/{user_id}'><label>Краткое описание</label><textarea name='summary'>{html.escape(str(p.get('summary') or ''))}</textarea><label>Цветовое направление</label><input name='color_direction' value='{html.escape(str(p.get('color_direction') or ''))}'><label>Контраст</label><input name='contrast' value='{html.escape(str(p.get('contrast') or ''))}'><label>Линии</label><input name='line_direction' value='{html.escape(str(p.get('line_direction') or ''))}'><label>Стилевые направления</label><input name='style_directions'><label>Подходящие цвета</label><input name='flattering_colors'><label>Нежелательные цвета</label><input name='avoid_colors'><label>Причёски</label><input name='hairstyles'><label>Макияж</label><input name='makeup_sets'><label>Персональные правила</label><textarea name='personal_rules'></textarea><button>Сохранить вручную</button></form></div>"""
    return _page(f"Клиент {code}", body)


@router.post("/admin/user/{user_id}/payment")
async def admin_payment_status(user_id: int, status: str = Form(...), garderobus_admin: str | None = Cookie(default=None)):
    _auth(garderobus_admin)
    if status not in {"unpaid","paid","active","refunded"}:
        raise HTTPException(400,"Bad payment status")
    db.set_payment_status(user_id,status)
    if status in {"paid","active"} and settings.telegram_bot_token:
        try:
            await TelegramAPI().send_message(user_id,"Оплата отмечена. Персональный Гардеробус активирован — можно начинать консультацию.",{"inline_keyboard":[[{"text":"Начать консультацию","callback_data":"consult:start"}]]})
        except Exception as e:
            print(f"Payment notify failed: {e}",flush=True)
    return RedirectResponse(f"/admin/user/{user_id}",status_code=303)


@router.post("/admin/user/{user_id}/profile-json")
async def upload_profile_json(user_id: int, profile_file: UploadFile = File(...), garderobus_admin: str | None = Cookie(default=None)):
    _auth(garderobus_admin)
    try:
        payload=json.loads((await profile_file.read()).decode('utf-8-sig'))
    except Exception as exc:
        raise HTTPException(400,"Не удалось прочитать JSON") from exc
    if payload.get('schema') != 'garderobus.appearance.v1':
        raise HTTPException(400,"Нужна схема garderobus.appearance.v1")
    payload['status']='ready'
    db.save_profile(user_id,payload); db.update_consultation_status(user_id,'typed'); db.set_state(user_id,'profile_ready',{})
    if settings.telegram_bot_token:
        try:
            await TelegramAPI().send_message(user_id,"Типирование готово. Следующий этап — фотографии всего гардероба.",{"inline_keyboard":[[{"text":"Загрузить гардероб","callback_data":"batch:start"}]]})
        except Exception as e:
            print(f"Profile notify failed: {e}",flush=True)
    return RedirectResponse(f"/admin/user/{user_id}",status_code=303)


def _csv(v: str) -> list[str]:
    return [x.strip() for x in v.split(",") if x.strip()]


@router.post("/admin/user/{user_id}")
async def save_user_profile(
    user_id:int,
    summary:str=Form(""),color_direction:str=Form(""),contrast:str=Form(""),line_direction:str=Form(""),
    style_directions:str=Form(""),flattering_colors:str=Form(""),avoid_colors:str=Form(""),hairstyles:str=Form(""),makeup_sets:str=Form(""),personal_rules:str=Form(""),
    garderobus_admin: str | None = Cookie(default=None),
):
    _auth(garderobus_admin)
    payload={"summary":summary,"color_direction":color_direction,"contrast":contrast,"line_direction":line_direction,"style_directions":_csv(style_directions),"flattering_colors":_csv(flattering_colors),"avoid_colors":_csv(avoid_colors),"hairstyles":_csv(hairstyles),"makeup_sets":_csv(makeup_sets),"personal_rules":[x.strip() for x in personal_rules.splitlines() if x.strip()],"status":"ready"}
    db.save_profile(user_id,payload); db.update_consultation_status(user_id,"typed"); db.set_state(user_id,"profile_ready",{})
    if settings.telegram_bot_token:
        try: await TelegramAPI().send_message(user_id,"Типирование готово. Теперь можно загружать фотографии всего гардероба. Ограничения по количеству фото нет.",{"inline_keyboard":[[{"text":"Загрузить гардероб","callback_data":"batch:start"}]]})
        except Exception as e: print(f"Profile notify failed: {e}",flush=True)
    return RedirectResponse(f"/admin/user/{user_id}",status_code=303)


@router.get("/admin/batch/{batch_id}", response_class=HTMLResponse)
def batch_page(batch_id:int,garderobus_admin: str | None = Cookie(default=None)):
    _auth(garderobus_admin)
    b=db.get_batch(batch_id)
    if not b: raise HTTPException(404,"Batch not found")
    photos=b['photos']; opts="".join(f"<option value='{p['id']}' data-url='{p['image_url']}'>Фото {i+1}</option>" for i,p in enumerate(photos))
    body=f"""
<div class='card'><b>Пакет #{batch_id}</b> · пользователь {b['telegram_user_id']} · {len(photos)} фото · статус {html.escape(b['status'])}<p><a class='btn' href='/admin/batch/{batch_id}/collage.png'>Собрать коллаж готовых вещей</a></p><form method='post' action='/admin/batch/{batch_id}/ready' style='margin-top:12px'><button>Готово — открыть гардероб клиенту</button></form></div><div class='card'><h2>Быстрый импорт после внешней обработки</h2><p><small>Загрузи один ZIP: garderobus_wardrobe_manifest.json + collage_map.json + collage_001.png, collage_002.png… Приложение само разрежет прозрачные сетки 3×3, привяжет G-ID и создаст карточки.</small></p><form method='post' action='/admin/batch/{batch_id}/import-zip' enctype='multipart/form-data'><input type='file' name='archive' accept='.zip,application/zip' required><button>Импортировать весь гардероб</button></form></div>
<div class='card'><label>Исходное фото</label><select id='photo'>{opts}</select><div id='stage'><img id='source'><div id='sel'></div></div><p><small>Проведи пальцем/мышью прямоугольник вокруг одной вещи. Один исходный снимок можно разрезать на несколько вещей.</small></p></div>
<div class='card'>
<label>Название</label><input id='title' value='Вещь'><label>Категория</label><select id='category'><option>top</option><option>shirt</option><option>blouse</option><option>sweater</option><option>cardigan</option><option>bottom</option><option>trousers</option><option>jeans</option><option>skirt</option><option>shorts</option><option>dress</option><option>outerwear</option><option>jacket</option><option>blazer</option><option>shoes</option><option>boots</option><option>flats</option></select>
<label>Подтип</label><input id='subtype'><label>Цветовая семья</label><input id='color_family' placeholder='olive / black / cream / blue'><label>Название оттенка</label><input id='color_name'><label>Температура</label><select id='temperature'><option>unknown</option><option>warm</option><option>cool</option><option>neutral</option></select>
<label>Светлота</label><select id='value'><option>unknown</option><option>light</option><option>medium</option><option>dark</option></select><label>Принт</label><input id='print' value='solid'><label>Цвета принта</label><input id='print_colors'><label>Посадка</label><input id='fit'><label>Ткань/фактура</label><input id='fabric_family' placeholder='knit / woven / denim / leather / satin / lace'><label>Роли слоёв</label><input id='layer_roles' placeholder='top, outer, bottom, shoes'><label>Стилевые теги</label><input id='style_tags' placeholder='casual, romantic, classic'><label>Ситуации</label><input id='occasion_tags' value='everyday'><label>Сезоны</label><input id='seasons' value='all'><label>Стирка</label><select id='laundry_group'><option>unknown</option><option>white</option><option>light</option><option>dark</option><option>color</option><option>delicate</option><option>handwash</option><option>dry_clean</option></select>
<label><input type='checkbox' id='cleanup' style='width:auto'> попробовать убрать простой однотонный фон (механический алгоритм)</label><br><br><button id='saveCrop'>Создать вещь</button> <span id='result'></span>
</div>
<script>
const q=id=>document.getElementById(id);let rect={{x:.05,y:.05,w:.9,h:.9}},start=null;const photo=q('photo'),img=q('source'),stage=q('stage'),sel=q('sel');
function load(){{img.src=photo.selectedOptions[0]?.dataset.url||'';sel.style.display='none'}} photo.onchange=load;load();
function pos(e){{const r=img.getBoundingClientRect();const p=e.touches?e.touches[0]:e;return {{x:Math.max(0,Math.min(1,(p.clientX-r.left)/r.width)),y:Math.max(0,Math.min(1,(p.clientY-r.top)/r.height))}}}}
function down(e){{e.preventDefault();start=pos(e)}}function move(e){{if(!start)return;e.preventDefault();const p=pos(e);rect={{x:Math.min(start.x,p.x),y:Math.min(start.y,p.y),w:Math.abs(p.x-start.x),h:Math.abs(p.y-start.y)}};sel.style.display='block';sel.style.left=(rect.x*100)+'%';sel.style.top=(rect.y*100)+'%';sel.style.width=(rect.w*100)+'%';sel.style.height=(rect.h*100)+'%'}}function up(e){{if(start)move(e);start=null}}
stage.addEventListener('pointerdown',down);stage.addEventListener('pointermove',move);stage.addEventListener('pointerup',up);stage.addEventListener('touchstart',down,{{passive:false}});stage.addEventListener('touchmove',move,{{passive:false}});stage.addEventListener('touchend',up,{{passive:false}});
const arr=id=>q(id).value.split(',').map(x=>x.trim()).filter(Boolean);
q('saveCrop').onclick=async()=>{{if(rect.w<.02||rect.h<.02){{q('result').textContent='Сначала выдели вещь';return}};const garment={{title:q('title').value,category:q('category').value,subtype:q('subtype').value,color_family:q('color_family').value||'neutral',color_name:q('color_name').value,temperature:q('temperature').value,value:q('value').value,chroma:'unknown',print:q('print').value||'solid',print_colors:arr('print_colors'),silhouette:'',length:'',fit:q('fit').value,fabric_family:q('fabric_family').value||'unknown',texture:[],warmth:'unknown',layer_roles:arr('layer_roles'),can_layer_over:[],cannot_layer_over:[],style_tags:arr('style_tags'),occasion_tags:arr('occasion_tags'),seasons:arr('seasons'),laundry_group:q('laundry_group').value,notes:''}};const r=await fetch('/admin/api/batches/{batch_id}/crop',{{method:'POST',headers:{{'Content-Type':'application/json'}},body:JSON.stringify({{photo_id:Number(photo.value),...rect,garment,simple_background_cleanup:q('cleanup').checked}})}});const d=await r.json();q('result').innerHTML=r.ok?'✓ вещь #'+d.garment_id+' создана':'Ошибка: '+(d.detail||r.status)}};
</script>"""
    return _page(f"Пакет #{batch_id}",body)


@router.post("/admin/api/batches/{batch_id}/crop")
def create_crop(batch_id:int,req:CropRequest,garderobus_admin: str | None = Cookie(default=None)):
    _auth(garderobus_admin)
    b=db.get_batch(batch_id)
    if not b: raise HTTPException(404,"Batch not found")
    photo=next((p for p in b['photos'] if int(p['id'])==req.photo_id),None)
    if not photo: raise HTTPException(404,"Photo not found")
    path=crop_manual(photo['path'],req.x,req.y,req.w,req.h,req.simple_background_cleanup)
    payload=req.garment.model_dump(); payload['source_batch_id']=batch_id; payload['source_photo_id']=req.photo_id
    gid=db.add_garment(int(b['telegram_user_id']),str(path),photo['path'],payload,confirmed=True)
    db.set_batch_status(batch_id,"processing")
    return {"ok":True,"garment_id":gid,"image_url":f"/media/{path.name}"}




@router.post("/admin/batch/{batch_id}/import-zip")
async def batch_import_zip(batch_id:int, archive:UploadFile=File(...), garderobus_admin: str | None = Cookie(default=None)):
    _auth(garderobus_admin)
    b=db.get_batch(batch_id)
    if not b: raise HTTPException(404,"Batch not found")
    try:
        result=import_wardrobe_zip(int(b['telegram_user_id']),batch_id,await archive.read())
    except ImportErrorDetail as exc:
        raise HTTPException(400,str(exc)) from exc
    body=f"<div class='card'><h2>Импорт завершён</h2><p>Создано: <b>{result['imported']}</b><br>Обновлено: <b>{result['updated']}</b><br>В manifest: <b>{result['manifest_items']}</b></p><p>Без изображения: {html.escape(', '.join(result['not_visualized']) or 'нет')}<br>Нет в manifest: {html.escape(', '.join(result['missing_manifest_ids']) or 'нет')}</p><a class='btn' href='/admin/batch/{batch_id}'>Вернуться к пакету</a></div>"
    return _page("Импорт гардероба",body)


@router.get("/admin/batch/{batch_id}/collage.png")
def batch_collage(batch_id:int,garderobus_admin: str | None = Cookie(default=None)):
    _auth(garderobus_admin)
    b=db.get_batch(batch_id)
    if not b: raise HTTPException(404,"Batch not found")
    garments=[g for g in db.list_garments(int(b["telegram_user_id"])) if int(g.get("source_batch_id") or 0)==batch_id]
    if not garments: raise HTTPException(409,"Сначала вырежи хотя бы одну вещь")
    pairs=[]
    for g in garments:
        rec=db.get_garment_record(int(b["telegram_user_id"]),int(g["id"]))
        if rec: pairs.append((rec["image_path"],g.get("title") or "Вещь"))
    path=make_contact_sheet(pairs,title=f"Пакет #{batch_id}")
    return FileResponse(path,media_type="image/jpeg",filename=f"garderobus_batch_{batch_id}.jpg")

@router.post("/admin/batch/{batch_id}/ready")
async def mark_ready(batch_id:int,garderobus_admin: str | None = Cookie(default=None)):
    _auth(garderobus_admin)
    b=db.get_batch(batch_id)
    if not b: raise HTTPException(404,"Batch not found")
    db.set_batch_status(batch_id,"ready")
    if settings.telegram_bot_token:
        try: await TelegramAPI().send_message(int(b['telegram_user_id']),"Гардероб обработан и уже появился в Капсуле.")
        except Exception: pass
    return RedirectResponse(f"/admin/batch/{batch_id}",status_code=303)
