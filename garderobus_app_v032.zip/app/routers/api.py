from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile

from .. import db
from ..models import OutfitRequest
from ..security import current_user_id
from ..services.garment_processing import public_media_copy, remove_background, save_original
from ..services.laundry import BUCKET_LABELS, group_laundry
from ..services.openai_vision import AIUnavailable, analyze_garment
from ..services.stylist import generate_outfit

router = APIRouter(prefix="/api")


@router.get("/me")
def me(user_id: int = Depends(current_user_id)):
    return {
        "user_id": user_id,
        "profile": db.get_profile(user_id),
        "garment_count": len(db.list_garments(user_id)),
    }


@router.get("/profile")
def profile(user_id: int = Depends(current_user_id)):
    return {"profile": db.get_profile(user_id)}


@router.get("/garments")
def garments(user_id: int = Depends(current_user_id)):
    return {"items": db.list_garments(user_id)}


@router.post("/garments/analyze")
async def analyze_uploaded_garment(
    image: UploadFile = File(...),
    user_id: int = Depends(current_user_id),
):
    data = await image.read()
    suffix = Path(image.filename or "garment.jpg").suffix or ".jpg"
    original = save_original(data, suffix)
    cutout = remove_background(original)
    public_media_copy(cutout)
    try:
        analysis = analyze_garment(cutout)
    except AIUnavailable as exc:
        raise HTTPException(503, str(exc)) from exc
    garment_id = db.add_garment(user_id, str(cutout), str(original), analysis.model_dump())
    return {"id": garment_id, "analysis": analysis, "confirmed": False, "image_url": f"/media/{cutout.name}"}


@router.post("/garments/{garment_id}/confirm")
def confirm_garment(garment_id: int, user_id: int = Depends(current_user_id)):
    if not db.get_garment(user_id, garment_id):
        raise HTTPException(404, "Garment not found")
    db.confirm_garment(user_id, garment_id)
    return {"ok": True}


@router.post("/garments/{garment_id}/status/{status}")
def garment_status(garment_id: int, status: str, user_id: int = Depends(current_user_id)):
    allowed = {"clean", "worn", "laundry", "washing", "drying", "repair", "seasonal", "loaned"}
    if status not in allowed:
        raise HTTPException(400, "Unknown status")
    if not db.get_garment(user_id, garment_id):
        raise HTTPException(404, "Garment not found")
    db.set_garment_status(user_id, garment_id, status)
    return {"ok": True, "status": status}


@router.get("/laundry")
def laundry(user_id: int = Depends(current_user_id)):
    buckets = group_laundry(db.list_garments(user_id))
    return {
        "buckets": [
            {"key": key, "label": BUCKET_LABELS[key], "items": items}
            for key, items in buckets.items()
        ]
    }


@router.post("/stylist/generate")
def stylist(request: OutfitRequest, user_id: int = Depends(current_user_id)):
    wardrobe = db.list_garments(user_id)
    try:
        result = generate_outfit(wardrobe, db.get_profile(user_id), request)
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from exc
    selected = [g for g in wardrobe if g["id"] in result.garment_ids]
    db.save_outfit(user_id, result.garment_ids, request.model_dump(), result.explanation)
    return {"outfit": result, "garments": selected}
