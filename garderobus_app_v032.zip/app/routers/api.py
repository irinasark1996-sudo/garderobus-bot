from fastapi import APIRouter, Depends, HTTPException

from .. import db
from ..config import settings
from ..models import OutfitRequest, ReplaceOutfitRequest
from ..security import current_user_id
from ..services.laundry import BUCKET_LABELS, group_laundry
from ..services.stylist import generate_capsule, generate_outfit, replace_garment_in_outfit

router = APIRouter(prefix='/api')


def _paid(user_id: int) -> bool:
    return settings.beta_free_access or (bool(settings.admin_telegram_id) and user_id == settings.admin_telegram_id) or db.is_paid(user_id)


def _require_paid(user_id: int) -> None:
    if not _paid(user_id):
        raise HTTPException(402, 'Персональный Гардеробус ещё не активирован')


@router.get('/me')
def me(user_id: int = Depends(current_user_id)):
    if not db.get_user(user_id):
        db.upsert_user(user_id)
    user = db.get_user(user_id) or {}
    c = db.get_consultation(user_id)
    p = db.get_profile(user_id)
    batches = [b for b in db.list_batches() if int(b['telegram_user_id']) == user_id]
    return {
        'user_id': user_id,
        'client_code': user.get('client_code'),
        'payment_status': user.get('payment_status') or 'unpaid',
        'paid': _paid(user_id),
        'is_admin': bool(settings.admin_telegram_id) and user_id == settings.admin_telegram_id,
        'admin_url': '/admin' if (bool(settings.admin_telegram_id) and user_id == settings.admin_telegram_id) else None,
        'price_rub': settings.product_price_rub,
        'product_title': settings.product_title,
        'buy_url': f"/buy/{user.get('client_code')}" if user.get('client_code') else None,
        'profile': p,
        'consultation_status': (c or {}).get('status'),
        'garment_count': len(db.list_garments(user_id)),
        'latest_batch': batches[0] if batches else None,
    }


@router.get('/profile')
def profile(user_id: int = Depends(current_user_id)):
    _require_paid(user_id)
    return {'profile': db.get_profile(user_id), 'consultation': db.get_consultation(user_id)}


@router.get('/garments')
def garments(user_id: int = Depends(current_user_id)):
    _require_paid(user_id)
    return {'items': db.list_garments(user_id)}


@router.post('/garments/{garment_id}/status/{status}')
def garment_status(garment_id: int, status: str, user_id: int = Depends(current_user_id)):
    _require_paid(user_id)
    allowed = {'clean','worn','laundry','washing','drying','repair','seasonal','loaned'}
    if status not in allowed:
        raise HTTPException(400, 'Unknown status')
    if not db.get_garment(user_id, garment_id):
        raise HTTPException(404, 'Garment not found')
    db.set_garment_status(user_id, garment_id, status)
    return {'ok': True, 'status': status}


@router.get('/laundry')
def laundry(user_id: int = Depends(current_user_id)):
    _require_paid(user_id)
    buckets = group_laundry(db.list_garments(user_id))
    return {'buckets': [{'key': k, 'label': BUCKET_LABELS[k], 'items': v} for k, v in buckets.items()]}


@router.post('/stylist/generate')
def stylist(request: OutfitRequest, user_id: int = Depends(current_user_id)):
    _require_paid(user_id)
    wardrobe = db.list_garments(user_id)
    try:
        result = generate_outfit(wardrobe, db.get_profile(user_id), request, db.recent_outfit_garment_ids(user_id, 12))
    except ValueError as e:
        raise HTTPException(409, str(e)) from e
    selected = [g for g in wardrobe if g['id'] in result.garment_ids]
    db.save_outfit(user_id, result.garment_ids, request.model_dump(), result.explanation)
    return {'outfit': result, 'garments': selected}


@router.post('/stylist/replace')
def stylist_replace(request: ReplaceOutfitRequest, user_id: int = Depends(current_user_id)):
    _require_paid(user_id)
    wardrobe = db.list_garments(user_id)
    params = OutfitRequest(occasion=request.occasion, mood=request.mood, novelty=request.novelty)
    try:
        result = replace_garment_in_outfit(
            wardrobe,
            db.get_profile(user_id),
            request.garment_ids,
            request.replace_id,
            params,
            db.recent_outfit_garment_ids(user_id, 12),
        )
    except ValueError as e:
        raise HTTPException(409, str(e)) from e
    selected = [g for g in wardrobe if g['id'] in result.garment_ids]
    db.save_outfit(user_id, result.garment_ids, {'replace_id': request.replace_id, **params.model_dump()}, result.explanation)
    return {'outfit': result, 'garments': selected}


@router.get('/capsules/{style}')
def capsule(style: str, user_id: int = Depends(current_user_id)):
    _require_paid(user_id)
    wardrobe = db.list_garments(user_id)
    ids = generate_capsule(wardrobe, style)
    return {'style': style, 'garment_ids': ids, 'garments': [g for g in wardrobe if g['id'] in ids]}
