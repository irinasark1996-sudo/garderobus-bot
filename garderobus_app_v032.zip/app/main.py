from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from . import db
from .config import settings
from .routers.api import router as api_router
from .routers.admin import router as admin_router
from .routers.telegram import router as telegram_router
from .routers.payments import router as payments_router

async def _configure_telegram():
    if not settings.auto_configure_webhook or not settings.telegram_bot_token:return
    base=settings.resolved_public_base_url.rstrip('/')
    if not base.startswith('https://'):return
    try:
        from .services.telegram import TelegramAPI
        tg=TelegramAPI(); canonical=base+'/telegram/webhook'; legacy=base+'/app/telegram/webhook'; info=await tg.get_webhook_info(); current=(info.get('url') or '').rstrip('/')
        if current not in {canonical,legacy}:
            payload={'url':canonical,'allowed_updates':['message','callback_query'],'drop_pending_updates':False}
            if settings.explicit_webhook_secret:payload['secret_token']=settings.explicit_webhook_secret
            await tg.call('setWebhook',payload)
        try: await tg.set_my_commands()
        except Exception as e: print(f'Telegram command setup skipped: {type(e).__name__}: {e}',flush=True)
    except Exception as e: print(f'Telegram webhook setup failed: {type(e).__name__}: {e}',flush=True)

@asynccontextmanager
async def lifespan(app:FastAPI):
    for x in ('media','garments','profiles'): (settings.storage_path/x).mkdir(parents=True,exist_ok=True)
    db.ensure_db(); await _configure_telegram(); yield

app=FastAPI(title='Garderobus / Kapsula',version='0.5.0-service',lifespan=lifespan)
app.include_router(api_router); app.include_router(admin_router); app.include_router(telegram_router); app.include_router(payments_router)
app.mount('/media',StaticFiles(directory=str(settings.storage_path/'media')),name='media')
app.mount('/static',StaticFiles(directory='miniapp'),name='static')

@app.get('/health')
def health(): return {'ok':True,'version':'0.5.0-service','ai_inside':False,'telegram_configured':bool(settings.telegram_bot_token),'admin_forwarding':bool(settings.admin_telegram_id),'admin_panel_configured':bool(settings.admin_password),'public_url':settings.resolved_public_base_url,'mini_app_url':settings.resolved_mini_app_url}
@app.get('/healthz')
def healthz(): return {'ok':True,'version':'0.5.0-service'}
@app.get('/app')
def mini_app(): return FileResponse('miniapp/index.html')
@app.get('/')
def root(): return RedirectResponse('/app')
