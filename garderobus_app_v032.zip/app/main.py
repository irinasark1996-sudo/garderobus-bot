from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from . import db
from .config import settings
from .routers.api import router as api_router
from .routers.telegram import router as telegram_router


async def _configure_telegram() -> None:
    if not settings.auto_configure_webhook or not settings.telegram_bot_token:
        return
    base = settings.resolved_public_base_url.rstrip("/")
    if not base.startswith("https://"):
        return

    try:
        from .services.telegram import TelegramAPI
        tg = TelegramAPI()

        canonical = base + "/telegram/webhook"
        legacy_app = base + "/app/telegram/webhook"
        info = await tg.get_webhook_info()
        current = (info.get("url") or "").rstrip("/")

        # Avoid hammering setWebhook on every Railway restart. Telegram may rate
        # limit repeated configuration requests. The legacy URL is accepted by
        # our compatibility route, so it is safe to keep temporarily.
        if current in {canonical, legacy_app}:
            label = "canonical" if current == canonical else "legacy-compatible"
            print(
                "Telegram webhook already usable: "
                f"mode={label} url={current} "
                f"pending={info.get('pending_update_count', 0)} "
                f"last_error={info.get('last_error_message')}",
                flush=True,
            )
        else:
            payload = {
                "url": canonical,
                "allowed_updates": ["message", "callback_query"],
                "drop_pending_updates": False,
            }
            if settings.explicit_webhook_secret:
                payload["secret_token"] = settings.explicit_webhook_secret

            await tg.call("setWebhook", payload)
            info = await tg.get_webhook_info()
            print(
                "Telegram webhook ready: "
                f"url={info.get('url')} "
                f"pending={info.get('pending_update_count', 0)} "
                f"last_error={info.get('last_error_message')}",
                flush=True,
            )

        # Commands are useful but not required for message delivery. Do not let
        # a transient Telegram rate limit make the deployment look broken.
        try:
            await tg.set_my_commands()
        except Exception as exc:
            print(f"Telegram command setup skipped: {type(exc).__name__}: {exc}", flush=True)

    except Exception as exc:
        # The web service should still become healthy so deployment logs and the
        # /telegram/status endpoint remain available.
        print(f"Telegram webhook setup failed: {type(exc).__name__}: {exc}", flush=True)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings.storage_path.mkdir(parents=True, exist_ok=True)
    (settings.storage_path / "media").mkdir(parents=True, exist_ok=True)
    (settings.storage_path / "garments").mkdir(parents=True, exist_ok=True)
    (settings.storage_path / "profiles").mkdir(parents=True, exist_ok=True)
    db.ensure_db()
    await _configure_telegram()
    yield


app = FastAPI(title="Garderobus / Kapsula AI", version="0.3.3", lifespan=lifespan)
app.include_router(api_router)
app.include_router(telegram_router)
app.mount("/media", StaticFiles(directory=str(settings.storage_path / "media")), name="media")
app.mount("/static", StaticFiles(directory="miniapp"), name="static")


@app.get("/health")
def health():
    return {
        "ok": True,
        "version": "0.3.3",
        "openai_configured": bool(settings.openai_api_key),
        "telegram_configured": bool(settings.telegram_bot_token),
        "public_url": settings.resolved_public_base_url,
        "mini_app_url": settings.resolved_mini_app_url,
        "webhook_auto": settings.auto_configure_webhook,
    }


@app.get("/healthz")
def healthz():
    return {"ok": True, "version": "0.3.3"}


@app.get("/app")
def mini_app():
    return FileResponse("miniapp/index.html")


@app.get("/")
def root():
    return RedirectResponse("/app")
