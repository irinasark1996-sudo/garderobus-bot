import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import settings


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def ensure_db() -> None:
    settings.db_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(settings.db_path) as conn:
        conn.executescript(
            """
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS users (
                telegram_user_id INTEGER PRIMARY KEY,
                first_name TEXT,
                username TEXT,
                client_code TEXT,
                payment_status TEXT NOT NULL DEFAULT 'unpaid',
                onboarding_state TEXT NOT NULL DEFAULT 'new',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE UNIQUE INDEX IF NOT EXISTS idx_users_client_code ON users(client_code);
            CREATE TABLE IF NOT EXISTS app_meta (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            INSERT OR IGNORE INTO app_meta(key,value) VALUES('next_client_no','1');
            CREATE TABLE IF NOT EXISTS payments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id INTEGER NOT NULL,
                provider TEXT NOT NULL,
                provider_payment_id TEXT,
                amount_rub INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                confirmation_url TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_payments_user ON payments(telegram_user_id);
            CREATE TABLE IF NOT EXISTS bot_sessions (
                telegram_user_id INTEGER PRIMARY KEY,
                context_json TEXT NOT NULL DEFAULT '{}',
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS profile_photos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id INTEGER NOT NULL,
                kind TEXT NOT NULL DEFAULT '',
                path TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS appearance_profiles (
                telegram_user_id INTEGER PRIMARY KEY,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS consultations (
                telegram_user_id INTEGER PRIMARY KEY,
                status TEXT NOT NULL DEFAULT 'draft',
                answers_json TEXT NOT NULL DEFAULT '{}',
                note TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS wardrobe_batches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id INTEGER NOT NULL,
                status TEXT NOT NULL DEFAULT 'collecting',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_batches_user ON wardrobe_batches(telegram_user_id);
            CREATE TABLE IF NOT EXISTS wardrobe_batch_photos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                batch_id INTEGER NOT NULL,
                telegram_user_id INTEGER NOT NULL,
                path TEXT NOT NULL,
                telegram_message_id INTEGER,
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_batch_photos_batch ON wardrobe_batch_photos(batch_id);
            CREATE TABLE IF NOT EXISTS garments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id INTEGER NOT NULL,
                image_path TEXT NOT NULL,
                original_image_path TEXT,
                payload_json TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'clean',
                confirmed INTEGER NOT NULL DEFAULT 0,
                wear_count INTEGER NOT NULL DEFAULT 0,
                last_worn_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_garments_user ON garments(telegram_user_id);
            CREATE TABLE IF NOT EXISTS outfits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id INTEGER NOT NULL,
                garment_ids_json TEXT NOT NULL,
                request_json TEXT NOT NULL,
                explanation_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            """
        )
        columns = {row[1] for row in conn.execute("PRAGMA table_info(profile_photos)").fetchall()}
        if "kind" not in columns:
            conn.execute("ALTER TABLE profile_photos ADD COLUMN kind TEXT NOT NULL DEFAULT ''")
        user_columns = {row[1] for row in conn.execute("PRAGMA table_info(users)").fetchall()}
        if "client_code" not in user_columns:
            conn.execute("ALTER TABLE users ADD COLUMN client_code TEXT")
        if "payment_status" not in user_columns:
            conn.execute("ALTER TABLE users ADD COLUMN payment_status TEXT NOT NULL DEFAULT 'unpaid'")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_client_code ON users(client_code)")
        conn.execute("CREATE TABLE IF NOT EXISTS app_meta (key TEXT PRIMARY KEY,value TEXT NOT NULL)")
        conn.execute("INSERT OR IGNORE INTO app_meta(key,value) VALUES('next_client_no','1')")
        conn.execute("""CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,telegram_user_id INTEGER NOT NULL,provider TEXT NOT NULL,
            provider_payment_id TEXT,amount_rub INTEGER NOT NULL,status TEXT NOT NULL DEFAULT 'pending',
            confirmation_url TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)""")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_payments_user ON payments(telegram_user_id)")


@contextmanager
def connection():
    ensure_db()
    conn = sqlite3.connect(settings.db_path)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def upsert_user(user_id: int, first_name: str = "", username: str = "") -> None:
    with connection() as conn:
        ts = now_iso()
        conn.execute(
            """
            INSERT INTO users(telegram_user_id, first_name, username, onboarding_state, created_at, updated_at)
            VALUES(?,?,?,?,?,?)
            ON CONFLICT(telegram_user_id) DO UPDATE SET
              first_name=excluded.first_name,
              username=excluded.username,
              updated_at=excluded.updated_at
            """,
            (user_id, first_name, username, "new", ts, ts),
        )
        row = conn.execute("SELECT client_code FROM users WHERE telegram_user_id=?", (user_id,)).fetchone()
        if not row or not row[0]:
            meta = conn.execute("SELECT value FROM app_meta WHERE key='next_client_no'").fetchone()
            n = int((meta[0] if meta else '1') or '1')
            code = f"GB-{n:06d}"
            conn.execute("UPDATE users SET client_code=? WHERE telegram_user_id=?", (code, user_id))
            conn.execute("INSERT INTO app_meta(key,value) VALUES('next_client_no',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (str(n+1),))
        conn.execute(
            "INSERT OR IGNORE INTO bot_sessions(telegram_user_id,context_json,updated_at) VALUES(?,?,?)",
            (user_id, "{}", ts),
        )


def get_user(user_id: int) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute("SELECT * FROM users WHERE telegram_user_id=?", (user_id,)).fetchone()
        return dict(row) if row else None


def list_users() -> list[dict[str, Any]]:
    with connection() as conn:
        return [dict(r) for r in conn.execute("SELECT * FROM users ORDER BY updated_at DESC").fetchall()]


def set_state(user_id: int, state: str, context: dict[str, Any] | None = None) -> None:
    with connection() as conn:
        ts = now_iso()
        conn.execute("UPDATE users SET onboarding_state=?, updated_at=? WHERE telegram_user_id=?", (state, ts, user_id))
        if context is not None:
            conn.execute(
                """
                INSERT INTO bot_sessions(telegram_user_id,context_json,updated_at) VALUES(?,?,?)
                ON CONFLICT(telegram_user_id) DO UPDATE SET context_json=excluded.context_json,updated_at=excluded.updated_at
                """,
                (user_id, json.dumps(context, ensure_ascii=False), ts),
            )


def get_state(user_id: int) -> str:
    with connection() as conn:
        row = conn.execute("SELECT onboarding_state FROM users WHERE telegram_user_id=?", (user_id,)).fetchone()
        return row[0] if row else "new"


def get_context(user_id: int) -> dict[str, Any]:
    with connection() as conn:
        row = conn.execute("SELECT context_json FROM bot_sessions WHERE telegram_user_id=?", (user_id,)).fetchone()
        if not row:
            return {}
        try:
            return json.loads(row[0])
        except json.JSONDecodeError:
            return {}


def set_context(user_id: int, context: dict[str, Any]) -> None:
    with connection() as conn:
        conn.execute(
            """
            INSERT INTO bot_sessions(telegram_user_id,context_json,updated_at) VALUES(?,?,?)
            ON CONFLICT(telegram_user_id) DO UPDATE SET context_json=excluded.context_json,updated_at=excluded.updated_at
            """,
            (user_id, json.dumps(context, ensure_ascii=False), now_iso()),
        )


# Consultation / manual typing -------------------------------------------------
def save_consultation(user_id: int, answers: dict[str, Any], status: str = "draft", note: str = "") -> None:
    with connection() as conn:
        ts = now_iso()
        conn.execute(
            """
            INSERT INTO consultations(telegram_user_id,status,answers_json,note,created_at,updated_at)
            VALUES(?,?,?,?,?,?)
            ON CONFLICT(telegram_user_id) DO UPDATE SET
              status=excluded.status, answers_json=excluded.answers_json, note=excluded.note, updated_at=excluded.updated_at
            """,
            (user_id, status, json.dumps(answers, ensure_ascii=False), note, ts, ts),
        )


def update_consultation_status(user_id: int, status: str, note: str | None = None) -> None:
    with connection() as conn:
        if note is None:
            conn.execute("UPDATE consultations SET status=?,updated_at=? WHERE telegram_user_id=?", (status, now_iso(), user_id))
        else:
            conn.execute("UPDATE consultations SET status=?,note=?,updated_at=? WHERE telegram_user_id=?", (status, note, now_iso(), user_id))


def get_consultation(user_id: int) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute("SELECT * FROM consultations WHERE telegram_user_id=?", (user_id,)).fetchone()
        if not row:
            return None
        return {**dict(row), "answers": json.loads(row["answers_json"] or "{}")}


def list_consultations() -> list[dict[str, Any]]:
    with connection() as conn:
        rows = conn.execute(
            """SELECT c.*,u.first_name,u.username FROM consultations c
               LEFT JOIN users u ON u.telegram_user_id=c.telegram_user_id
               ORDER BY c.updated_at DESC"""
        ).fetchall()
        return [{**dict(r), "answers": json.loads(r["answers_json"] or "{}") } for r in rows]


def add_profile_photo(user_id: int, path: str, kind: str = "") -> int:
    with connection() as conn:
        cur = conn.execute(
            "INSERT INTO profile_photos(telegram_user_id,kind,path,created_at) VALUES(?,?,?,?)",
            (user_id, kind, path, now_iso()),
        )
        return int(cur.lastrowid)


def list_profile_photos(user_id: int) -> list[dict[str, Any]]:
    with connection() as conn:
        rows = conn.execute("SELECT * FROM profile_photos WHERE telegram_user_id=? ORDER BY id", (user_id,)).fetchall()
        return [{**dict(r), "image_url": f"/media/{Path(r['path']).name}"} for r in rows]


def profile_photo_paths(user_id: int) -> list[str]:
    return [x["path"] for x in list_profile_photos(user_id)]


def clear_profile_photos(user_id: int) -> None:
    with connection() as conn:
        rows = conn.execute("SELECT path FROM profile_photos WHERE telegram_user_id=?", (user_id,)).fetchall()
        conn.execute("DELETE FROM profile_photos WHERE telegram_user_id=?", (user_id,))
    for row in rows:
        try:
            Path(row[0]).unlink(missing_ok=True)
        except OSError:
            pass


def save_profile(user_id: int, payload: dict[str, Any]) -> None:
    with connection() as conn:
        ts = now_iso()
        conn.execute(
            """
            INSERT INTO appearance_profiles(telegram_user_id,payload_json,created_at,updated_at)
            VALUES(?,?,?,?)
            ON CONFLICT(telegram_user_id) DO UPDATE SET payload_json=excluded.payload_json,updated_at=excluded.updated_at
            """,
            (user_id, json.dumps(payload, ensure_ascii=False), ts, ts),
        )


def get_profile(user_id: int) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute("SELECT payload_json FROM appearance_profiles WHERE telegram_user_id=?", (user_id,)).fetchone()
        return json.loads(row[0]) if row else None


# Wardrobe photo batches -------------------------------------------------------
def create_batch(user_id: int) -> int:
    with connection() as conn:
        ts = now_iso()
        cur = conn.execute(
            "INSERT INTO wardrobe_batches(telegram_user_id,status,created_at,updated_at) VALUES(?,?,?,?)",
            (user_id, "collecting", ts, ts),
        )
        return int(cur.lastrowid)


def get_active_batch(user_id: int) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute(
            "SELECT * FROM wardrobe_batches WHERE telegram_user_id=? AND status='collecting' ORDER BY id DESC LIMIT 1",
            (user_id,),
        ).fetchone()
        return dict(row) if row else None


def add_batch_photo(batch_id: int, user_id: int, path: str, message_id: int | None = None) -> int:
    with connection() as conn:
        cur = conn.execute(
            "INSERT INTO wardrobe_batch_photos(batch_id,telegram_user_id,path,telegram_message_id,created_at) VALUES(?,?,?,?,?)",
            (batch_id, user_id, path, message_id, now_iso()),
        )
        conn.execute("UPDATE wardrobe_batches SET updated_at=? WHERE id=?", (now_iso(), batch_id))
        return int(cur.lastrowid)


def list_batch_photos(batch_id: int) -> list[dict[str, Any]]:
    with connection() as conn:
        rows = conn.execute("SELECT * FROM wardrobe_batch_photos WHERE batch_id=? ORDER BY id", (batch_id,)).fetchall()
        return [{**dict(r), "image_url": f"/media/{Path(r['path']).name}"} for r in rows]


def set_batch_status(batch_id: int, status: str) -> None:
    with connection() as conn:
        conn.execute("UPDATE wardrobe_batches SET status=?,updated_at=? WHERE id=?", (status, now_iso(), batch_id))


def get_batch(batch_id: int) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute(
            """SELECT b.*,u.first_name,u.username FROM wardrobe_batches b
               LEFT JOIN users u ON u.telegram_user_id=b.telegram_user_id WHERE b.id=?""",
            (batch_id,),
        ).fetchone()
        if not row:
            return None
        d = dict(row)
        d["photos"] = list_batch_photos(batch_id)
        return d


def list_batches() -> list[dict[str, Any]]:
    with connection() as conn:
        rows = conn.execute(
            """SELECT b.*,u.first_name,u.username,
                      (SELECT COUNT(*) FROM wardrobe_batch_photos p WHERE p.batch_id=b.id) AS photo_count
               FROM wardrobe_batches b LEFT JOIN users u ON u.telegram_user_id=b.telegram_user_id
               ORDER BY b.updated_at DESC"""
        ).fetchall()
        return [dict(r) for r in rows]


# Garments / wardrobe ----------------------------------------------------------
def add_garment(user_id: int, image_path: str, original_image_path: str, payload: dict[str, Any], confirmed: bool = True) -> int:
    with connection() as conn:
        ts = now_iso()
        cur = conn.execute(
            """
            INSERT INTO garments(telegram_user_id,image_path,original_image_path,payload_json,status,confirmed,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?)
            """,
            (user_id, image_path, original_image_path, json.dumps(payload, ensure_ascii=False), "clean", int(confirmed), ts, ts),
        )
        return int(cur.lastrowid)


def update_garment_payload(user_id: int, garment_id: int, payload: dict[str, Any]) -> None:
    with connection() as conn:
        conn.execute(
            "UPDATE garments SET payload_json=?,updated_at=? WHERE id=? AND telegram_user_id=?",
            (json.dumps(payload, ensure_ascii=False), now_iso(), garment_id, user_id),
        )


def confirm_garment(user_id: int, garment_id: int) -> None:
    with connection() as conn:
        conn.execute("UPDATE garments SET confirmed=1,updated_at=? WHERE id=? AND telegram_user_id=?", (now_iso(), garment_id, user_id))


def list_garments(user_id: int) -> list[dict[str, Any]]:
    with connection() as conn:
        rows = conn.execute("SELECT * FROM garments WHERE telegram_user_id=? ORDER BY id DESC", (user_id,)).fetchall()
        result = []
        for row in rows:
            payload = json.loads(row["payload_json"] or "{}")
            payload.update({
                "id": row["id"], "status": row["status"], "confirmed": bool(row["confirmed"]),
                "wear_count": row["wear_count"], "image_url": f"/media/{Path(row['image_path']).name}",
            })
            result.append(payload)
        return result


def get_garment(user_id: int, garment_id: int) -> dict[str, Any] | None:
    record = get_garment_record(user_id, garment_id)
    if not record:
        return None
    return record["payload"] | {"id": record["id"], "status": record["status"], "confirmed": record["confirmed"]}


def get_garment_record(user_id: int, garment_id: int) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute("SELECT * FROM garments WHERE id=? AND telegram_user_id=?", (garment_id, user_id)).fetchone()
        if not row:
            return None
        return {
            "id": int(row["id"]), "image_path": row["image_path"], "original_image_path": row["original_image_path"],
            "payload": json.loads(row["payload_json"] or "{}"), "status": row["status"],
            "confirmed": bool(row["confirmed"]), "wear_count": int(row["wear_count"]),
        }


def delete_garment(user_id: int, garment_id: int) -> None:
    with connection() as conn:
        row = conn.execute("SELECT image_path,original_image_path FROM garments WHERE id=? AND telegram_user_id=?", (garment_id, user_id)).fetchone()
        conn.execute("DELETE FROM garments WHERE id=? AND telegram_user_id=?", (garment_id, user_id))
    if row:
        for value in row:
            if value:
                try: Path(value).unlink(missing_ok=True)
                except OSError: pass


def set_garment_status(user_id: int, garment_id: int, status: str) -> None:
    with connection() as conn:
        conn.execute("UPDATE garments SET status=?,updated_at=? WHERE id=? AND telegram_user_id=?", (status, now_iso(), garment_id, user_id))


def increment_wear_counts(user_id: int, garment_ids: list[int]) -> None:
    if not garment_ids: return
    with connection() as conn:
        for gid in garment_ids:
            conn.execute("UPDATE garments SET wear_count=wear_count+1,last_worn_at=?,updated_at=? WHERE id=? AND telegram_user_id=?", (now_iso(), now_iso(), gid, user_id))


def recent_outfit_garment_ids(user_id: int, limit: int = 10) -> list[int]:
    with connection() as conn:
        rows = conn.execute("SELECT garment_ids_json FROM outfits WHERE telegram_user_id=? ORDER BY id DESC LIMIT ?", (user_id, limit)).fetchall()
    result: list[int] = []
    for r in rows:
        try: result.extend(int(x) for x in json.loads(r[0]))
        except Exception: pass
    return result


def save_outfit(user_id: int, garment_ids: list[int], request_payload: dict[str, Any], explanation: list[str]) -> int:
    with connection() as conn:
        cur = conn.execute(
            "INSERT INTO outfits(telegram_user_id,garment_ids_json,request_json,explanation_json,created_at) VALUES(?,?,?,?,?)",
            (user_id, json.dumps(garment_ids), json.dumps(request_payload, ensure_ascii=False), json.dumps(explanation, ensure_ascii=False), now_iso()),
        )
        return int(cur.lastrowid)


# Commercial access -----------------------------------------------------------
def set_payment_status(user_id: int, status: str) -> None:
    with connection() as conn:
        conn.execute("UPDATE users SET payment_status=?,updated_at=? WHERE telegram_user_id=?", (status, now_iso(), user_id))


def is_paid(user_id: int) -> bool:
    user = get_user(user_id) or {}
    return str(user.get("payment_status") or "unpaid") in {"paid", "active"}


def create_payment(user_id: int, provider: str, amount_rub: int, provider_payment_id: str = "", confirmation_url: str = "", status: str = "pending") -> int:
    with connection() as conn:
        ts = now_iso()
        cur = conn.execute(
            "INSERT INTO payments(telegram_user_id,provider,provider_payment_id,amount_rub,status,confirmation_url,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
            (user_id, provider, provider_payment_id, amount_rub, status, confirmation_url, ts, ts),
        )
        return int(cur.lastrowid)


def update_payment_by_provider_id(provider_payment_id: str, status: str) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute("SELECT * FROM payments WHERE provider_payment_id=? ORDER BY id DESC LIMIT 1", (provider_payment_id,)).fetchone()
        if not row:
            return None
        conn.execute("UPDATE payments SET status=?,updated_at=? WHERE id=?", (status, now_iso(), row["id"]))
        if status == "succeeded":
            conn.execute("UPDATE users SET payment_status='paid',updated_at=? WHERE telegram_user_id=?", (now_iso(), row["telegram_user_id"]))
        return dict(row) | {"status": status}


def latest_payment(user_id: int) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute("SELECT * FROM payments WHERE telegram_user_id=? ORDER BY id DESC LIMIT 1", (user_id,)).fetchone()
        return dict(row) if row else None


def get_user_by_client_code(client_code: str) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute("SELECT * FROM users WHERE client_code=?", (client_code,)).fetchone()
        return dict(row) if row else None

def update_garment_image(user_id: int, garment_id: int, image_path: str, original_image_path: str | None = None) -> None:
    with connection() as conn:
        if original_image_path is None:
            conn.execute("UPDATE garments SET image_path=?,updated_at=? WHERE id=? AND telegram_user_id=?", (image_path, now_iso(), garment_id, user_id))
        else:
            conn.execute("UPDATE garments SET image_path=?,original_image_path=?,updated_at=? WHERE id=? AND telegram_user_id=?", (image_path, original_image_path, now_iso(), garment_id, user_id))


def find_garment_by_external_id(user_id: int, external_id: str) -> dict[str, Any] | None:
    for g in list_garments(user_id):
        if str(g.get("external_id") or "") == external_id:
            return g
    return None
