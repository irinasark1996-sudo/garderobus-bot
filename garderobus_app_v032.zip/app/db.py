import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import settings


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def ensure_db() -> None:
    settings.db_path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(settings.db_path) as conn:
        conn.executescript(
            """
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS users (
                telegram_user_id INTEGER PRIMARY KEY,
                first_name TEXT,
                username TEXT,
                onboarding_state TEXT NOT NULL DEFAULT 'new',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS bot_sessions (
                telegram_user_id INTEGER PRIMARY KEY,
                context_json TEXT NOT NULL DEFAULT '{}',
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS profile_photos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id INTEGER NOT NULL,
                kind TEXT NOT NULL DEFAULT '',
                path TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS appearance_profiles (
                telegram_user_id INTEGER PRIMARY KEY,
                payload_json TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS garments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id INTEGER NOT NULL,
                image_path TEXT NOT NULL,
                original_image_path TEXT,
                payload_json TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'clean',
                confirmed INTEGER NOT NULL DEFAULT 0,
                wear_count INTEGER NOT NULL DEFAULT 0,
                last_worn_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_garments_user ON garments(telegram_user_id);
            CREATE TABLE IF NOT EXISTS outfits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_user_id INTEGER NOT NULL,
                garment_ids_json TEXT NOT NULL,
                request_json TEXT NOT NULL,
                explanation_json TEXT NOT NULL,
                created_at TEXT NOT NULL
            );
            """
        )
        # Safe migration from the previous MVP database.
        columns = {row[1] for row in conn.execute("PRAGMA table_info(profile_photos)").fetchall()}
        if "kind" not in columns:
            conn.execute("ALTER TABLE profile_photos ADD COLUMN kind TEXT NOT NULL DEFAULT ''")


@contextmanager
def connection():
    ensure_db()
    conn = sqlite3.connect(settings.db_path)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def upsert_user(user_id: int, first_name: str = "", username: str = "") -> None:
    with connection() as conn:
        ts = now_iso()
        conn.execute(
            """
            INSERT INTO users(telegram_user_id, first_name, username, onboarding_state, created_at, updated_at)
            VALUES(?,?,?,?,?,?)
            ON CONFLICT(telegram_user_id) DO UPDATE SET
              first_name=excluded.first_name,
              username=excluded.username,
              updated_at=excluded.updated_at
            """,
            (user_id, first_name, username, "new", ts, ts),
        )
        conn.execute(
            "INSERT OR IGNORE INTO bot_sessions(telegram_user_id,context_json,updated_at) VALUES(?,?,?)",
            (user_id, "{}", ts),
        )


def set_state(user_id: int, state: str, context: dict[str, Any] | None = None) -> None:
    with connection() as conn:
        ts = now_iso()
        conn.execute(
            "UPDATE users SET onboarding_state=?, updated_at=? WHERE telegram_user_id=?",
            (state, ts, user_id),
        )
        if context is not None:
            conn.execute(
                """
                INSERT INTO bot_sessions(telegram_user_id,context_json,updated_at) VALUES(?,?,?)
                ON CONFLICT(telegram_user_id) DO UPDATE SET context_json=excluded.context_json,updated_at=excluded.updated_at
                """,
                (user_id, json.dumps(context, ensure_ascii=False), ts),
            )


def get_state(user_id: int) -> str:
    with connection() as conn:
        row = conn.execute("SELECT onboarding_state FROM users WHERE telegram_user_id=?", (user_id,)).fetchone()
        return row[0] if row else "new"


def get_context(user_id: int) -> dict[str, Any]:
    with connection() as conn:
        row = conn.execute("SELECT context_json FROM bot_sessions WHERE telegram_user_id=?", (user_id,)).fetchone()
        if not row:
            return {}
        try:
            return json.loads(row[0])
        except json.JSONDecodeError:
            return {}


def set_context(user_id: int, context: dict[str, Any]) -> None:
    with connection() as conn:
        ts = now_iso()
        conn.execute(
            """
            INSERT INTO bot_sessions(telegram_user_id,context_json,updated_at) VALUES(?,?,?)
            ON CONFLICT(telegram_user_id) DO UPDATE SET context_json=excluded.context_json,updated_at=excluded.updated_at
            """,
            (user_id, json.dumps(context, ensure_ascii=False), ts),
        )


def add_profile_photo(user_id: int, path: str, kind: str = "") -> int:
    with connection() as conn:
        cur = conn.execute(
            "INSERT INTO profile_photos(telegram_user_id,kind,path,created_at) VALUES(?,?,?,?)",
            (user_id, kind, path, now_iso()),
        )
        return int(cur.lastrowid)


def profile_photo_paths(user_id: int) -> list[str]:
    with connection() as conn:
        rows = conn.execute(
            "SELECT path FROM profile_photos WHERE telegram_user_id=? ORDER BY id", (user_id,)
        ).fetchall()
        return [r[0] for r in rows]


def clear_profile_photos(user_id: int) -> None:
    with connection() as conn:
        rows = conn.execute("SELECT path FROM profile_photos WHERE telegram_user_id=?", (user_id,)).fetchall()
        conn.execute("DELETE FROM profile_photos WHERE telegram_user_id=?", (user_id,))
    for row in rows:
        try:
            Path(row[0]).unlink(missing_ok=True)
        except OSError:
            pass


def save_profile(user_id: int, payload: dict[str, Any]) -> None:
    with connection() as conn:
        ts = now_iso()
        conn.execute(
            """
            INSERT INTO appearance_profiles(telegram_user_id,payload_json,created_at,updated_at)
            VALUES(?,?,?,?)
            ON CONFLICT(telegram_user_id) DO UPDATE SET payload_json=excluded.payload_json,updated_at=excluded.updated_at
            """,
            (user_id, json.dumps(payload, ensure_ascii=False), ts, ts),
        )


def get_profile(user_id: int) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute("SELECT payload_json FROM appearance_profiles WHERE telegram_user_id=?", (user_id,)).fetchone()
        return json.loads(row[0]) if row else None


def delete_profile(user_id: int) -> None:
    clear_profile_photos(user_id)
    with connection() as conn:
        conn.execute("DELETE FROM appearance_profiles WHERE telegram_user_id=?", (user_id,))


def add_garment(user_id: int, image_path: str, original_image_path: str, payload: dict[str, Any]) -> int:
    with connection() as conn:
        ts = now_iso()
        cur = conn.execute(
            """
            INSERT INTO garments(telegram_user_id,image_path,original_image_path,payload_json,status,confirmed,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?)
            """,
            (user_id, image_path, original_image_path, json.dumps(payload, ensure_ascii=False), "clean", 0, ts, ts),
        )
        return int(cur.lastrowid)


def update_garment_payload(user_id: int, garment_id: int, payload: dict[str, Any]) -> None:
    with connection() as conn:
        conn.execute(
            "UPDATE garments SET payload_json=?,updated_at=? WHERE id=? AND telegram_user_id=?",
            (json.dumps(payload, ensure_ascii=False), now_iso(), garment_id, user_id),
        )


def confirm_garment(user_id: int, garment_id: int) -> None:
    with connection() as conn:
        conn.execute(
            "UPDATE garments SET confirmed=1,updated_at=? WHERE id=? AND telegram_user_id=?",
            (now_iso(), garment_id, user_id),
        )


def list_garments(user_id: int) -> list[dict[str, Any]]:
    with connection() as conn:
        rows = conn.execute("SELECT * FROM garments WHERE telegram_user_id=? ORDER BY id DESC", (user_id,)).fetchall()
        result = []
        for row in rows:
            payload = json.loads(row["payload_json"])
            payload.update(
                {
                    "id": row["id"],
                    "status": row["status"],
                    "confirmed": bool(row["confirmed"]),
                    "wear_count": row["wear_count"],
                    "image_url": f"/media/{Path(row['image_path']).name}",
                }
            )
            result.append(payload)
        return result


def get_garment(user_id: int, garment_id: int) -> dict[str, Any] | None:
    record = get_garment_record(user_id, garment_id)
    if not record:
        return None
    return record["payload"] | {
        "id": record["id"],
        "status": record["status"],
        "confirmed": record["confirmed"],
    }


def get_garment_record(user_id: int, garment_id: int) -> dict[str, Any] | None:
    with connection() as conn:
        row = conn.execute(
            "SELECT * FROM garments WHERE id=? AND telegram_user_id=?", (garment_id, user_id)
        ).fetchone()
        if not row:
            return None
        return {
            "id": int(row["id"]),
            "image_path": row["image_path"],
            "original_image_path": row["original_image_path"],
            "payload": json.loads(row["payload_json"]),
            "status": row["status"],
            "confirmed": bool(row["confirmed"]),
            "wear_count": int(row["wear_count"]),
        }


def delete_garment(user_id: int, garment_id: int) -> None:
    with connection() as conn:
        row = conn.execute(
            "SELECT image_path, original_image_path FROM garments WHERE id=? AND telegram_user_id=?",
            (garment_id, user_id),
        ).fetchone()
        conn.execute("DELETE FROM garments WHERE id=? AND telegram_user_id=?", (garment_id, user_id))
    if row:
        for value in row:
            if value:
                try:
                    Path(value).unlink(missing_ok=True)
                except OSError:
                    pass


def set_garment_status(user_id: int, garment_id: int, status: str) -> None:
    with connection() as conn:
        conn.execute(
            "UPDATE garments SET status=?,updated_at=? WHERE id=? AND telegram_user_id=?",
            (status, now_iso(), garment_id, user_id),
        )


def save_outfit(user_id: int, garment_ids: list[int], request_payload: dict[str, Any], explanation: list[str]) -> int:
    with connection() as conn:
        cur = conn.execute(
            "INSERT INTO outfits(telegram_user_id,garment_ids_json,request_json,explanation_json,created_at) VALUES(?,?,?,?,?)",
            (
                user_id,
                json.dumps(garment_ids),
                json.dumps(request_payload, ensure_ascii=False),
                json.dumps(explanation, ensure_ascii=False),
                now_iso(),
            ),
        )
        return int(cur.lastrowid)
