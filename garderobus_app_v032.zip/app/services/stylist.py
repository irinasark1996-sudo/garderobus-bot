import random
from itertools import product

from ..models import OutfitRequest, OutfitResult
from .openai_vision import explain_outfit


TOP_CATS = {"top", "shirt", "blouse", "t-shirt", "tee", "sweater", "cardigan", "tank", "bodysuit", "hoodie"}
BOTTOM_CATS = {"bottom", "trousers", "pants", "jeans", "skirt", "shorts", "leggings"}
SHOE_CATS = {"shoes", "sneakers", "boots", "loafers", "flats", "heels", "sandals"}
OUTER_CATS = {"outerwear", "jacket", "blazer", "coat", "trench", "parka", "biker_jacket"}


def _cat(g: dict) -> str:
    return (g.get("category") or "").strip().lower()


def _is_available(g: dict) -> bool:
    return g.get("confirmed") and g.get("status") == "clean"


def _role(g: dict, role: str) -> bool:
    return role in (g.get("layer_roles") or [])


def _compatible_layer(base: dict, outer: dict) -> bool:
    base_words = {(_cat(base)), (base.get("subtype") or "").lower()}
    forbidden = {str(x).lower() for x in outer.get("cannot_layer_over", [])}
    return not any(any(token and token in word for word in forbidden) for token in base_words)


def generate_outfit(garments: list[dict], profile: dict | None, request: OutfitRequest) -> OutfitResult:
    available = [g for g in garments if _is_available(g)]
    tops = [g for g in available if _cat(g) in TOP_CATS or _role(g, "top")]
    bottoms = [g for g in available if _cat(g) in BOTTOM_CATS or _role(g, "bottom")]
    shoes = [g for g in available if _cat(g) in SHOE_CATS or _role(g, "shoes")]
    outers = [g for g in available if _cat(g) in OUTER_CATS or _role(g, "outer") or _role(g, "light_outer")]

    if not tops or not bottoms or not shoes:
        missing = []
        if not tops: missing.append("верх")
        if not bottoms: missing.append("низ")
        if not shoes: missing.append("обувь")
        raise ValueError("Для образа пока не хватает категорий: " + ", ".join(missing))

    candidates = []
    for top, bottom, shoe in product(tops, bottoms, shoes):
        score = random.random() * (0.15 + request.novelty)
        score -= 0.025 * (top.get("wear_count", 0) + bottom.get("wear_count", 0) + shoe.get("wear_count", 0)) * request.novelty
        # Prefer balanced print load.
        prints = sum(1 for g in (top, bottom, shoe) if (g.get("print") or "plain").lower() not in {"plain", "solid", "none", "однотонный"})
        if prints > 1:
            score -= 1.0
        chosen = [top, bottom, shoe]
        compatible_outers = [o for o in outers if o["id"] not in {top["id"], bottom["id"], shoe["id"]} and _compatible_layer(top, o)]
        if compatible_outers and random.random() < 0.55:
            chosen.append(max(compatible_outers, key=lambda x: random.random() - 0.03 * x.get("wear_count", 0)))
            score += 0.15
        candidates.append((score, chosen))

    candidates.sort(key=lambda x: x[0], reverse=True)
    chosen = candidates[0][1]
    reasons = explain_outfit(profile, chosen, request.occasion, request.mood)
    return OutfitResult(
        garment_ids=[g["id"] for g in chosen],
        explanation=reasons,
        hairstyle="Подбирается beauty-модулем по профилю и настроению образа",
        makeup="Подбирается beauty-модулем по палитре комплекта и профилю",
    )
