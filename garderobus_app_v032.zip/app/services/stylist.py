from __future__ import annotations

import random
from collections import Counter
from itertools import product

from ..models import OutfitRequest, OutfitResult

TOP_CATS = {"top", "shirt", "blouse", "t-shirt", "tee", "sweater", "cardigan", "tank", "bodysuit", "hoodie", "knit_top"}
BOTTOM_CATS = {"bottom", "trousers", "pants", "jeans", "skirt", "shorts", "leggings"}
SHOE_CATS = {"shoes", "sneakers", "boots", "loafers", "flats", "heels", "sandals", "mary_jane"}
OUTER_CATS = {"outerwear", "jacket", "blazer", "coat", "trench", "parka", "biker_jacket", "overshirt"}
DRESS_CATS = {"dress", "jumpsuit", "overall"}

NEUTRALS = {"black", "white", "cream", "beige", "taupe", "grey", "gray", "brown", "navy", "denim", "neutral"}
ANALOG = {
    frozenset(("red", "orange")), frozenset(("orange", "yellow")), frozenset(("yellow", "green")),
    frozenset(("green", "blue")), frozenset(("blue", "purple")), frozenset(("purple", "red")),
    frozenset(("pink", "red")), frozenset(("olive", "brown")), frozenset(("olive", "green")),
    frozenset(("burgundy", "brown")), frozenset(("burgundy", "pink")),
}
COMPLEMENTS = {
    frozenset(("blue", "orange")), frozenset(("red", "green")), frozenset(("yellow", "purple")),
    frozenset(("pink", "green")), frozenset(("burgundy", "olive")),
}
FABRIC_PAIRS = {
    frozenset(("knit", "woven")): (0.35, "мягкий трикотаж и более собранная ткань дают разную плотность фактур"),
    frozenset(("knit", "denim")): (0.35, "трикотаж смягчает плотный деним"),
    frozenset(("knit", "leather")): (0.45, "мягкая вязка балансирует гладкую кожу"),
    frozenset(("satin", "knit")): (0.45, "матовая мягкость трикотажа уравновешивает блеск сатина"),
    frozenset(("satin", "suiting")): (0.4, "сатин и костюмная ткань дают аккуратный контраст блеска и матовости"),
    frozenset(("lace", "leather")): (0.35, "кружево и кожа дают намеренный контраст нежной и плотной фактуры"),
    frozenset(("lace", "knit")): (0.3, "мягкий трикотаж поддерживает деликатную фактуру кружева"),
    frozenset(("denim", "woven")): (0.25, "деним хорошо держит более лёгкую ткань рядом"),
}


def _cat(g: dict) -> str:
    return str(g.get("category") or "").strip().lower()


def _role(g: dict, role: str) -> bool:
    return role in [str(x).lower() for x in (g.get("layer_roles") or [])]


def _is_available(g: dict) -> bool:
    return bool(g.get("confirmed")) and g.get("status") == "clean"


def _color(g: dict) -> str:
    return str(g.get("color_family") or g.get("color_name") or "neutral").lower()


def _print(g: dict) -> str:
    return str(g.get("print") or "solid").lower()


def _fabric(g: dict) -> str:
    raw = str(g.get("fabric_family") or "unknown").lower()
    mapping = {
        "fine_knit":"knit","chunky_knit":"knit","jersey":"knit",
        "fluid_woven":"woven","crisp_woven":"woven","cotton":"woven","linen":"woven",
        "silk_like":"satin","leather":"leather","suede":"leather",
    }
    return mapping.get(raw, raw)


def _styles(g: dict) -> set[str]:
    return {str(x).lower() for x in (g.get("style_tags") or [])}


def _occasions(g: dict) -> set[str]:
    return {str(x).lower() for x in (g.get("occasion_tags") or [])}


def _seasons(g: dict) -> set[str]:
    return {str(x).lower() for x in (g.get("seasons") or [])}


def _color_score(a: dict, b: dict) -> tuple[float, str]:
    ca, cb = _color(a), _color(b)
    if ca == cb:
        return 0.55, f"цвета работают тонально: обе вещи держатся в семье «{ca}»"
    if ca in NEUTRALS and cb in NEUTRALS:
        return 0.4, "две спокойные базовые цветовые семьи не спорят друг с другом"
    if ca in NEUTRALS or cb in NEUTRALS:
        accent = cb if ca in NEUTRALS else ca
        return 0.5, f"нейтральная вещь служит фоном, поэтому оттенок «{accent}» остаётся главным акцентом"
    pair = frozenset((ca, cb))
    if pair in ANALOG:
        return 0.45, "оттенки близки по цветовому кругу, поэтому переход между ними выглядит мягко"
    if pair in COMPLEMENTS:
        return 0.1, "цвета контрастные; сочетание работает только как осознанный акцент"
    # Prints can explicitly carry the partner colour.
    a_print_colors = {str(x).lower() for x in (a.get("print_colors") or [])}
    b_print_colors = {str(x).lower() for x in (b.get("print_colors") or [])}
    if cb in a_print_colors or ca in b_print_colors:
        return 0.65, "один из оттенков повторяется внутри принта, поэтому вещи связаны по цвету"
    return -0.15, "между основными оттенками нет явной механической цветовой связи"


def _temperature_score(a: dict, b: dict) -> tuple[float, str | None]:
    ta, tb = str(a.get("temperature") or "unknown"), str(b.get("temperature") or "unknown")
    family=lambda x: "warm" if x in {"warm","warm_neutral"} else "cool" if x in {"cool","cool_neutral"} else x
    ta,tb=family(ta),family(tb)
    if "unknown" in {ta, tb} or "neutral" in {ta, tb}:
        return 0.0, None
    if ta == tb:
        return 0.2, "температура оттенков совпадает"
    return -0.22, "температура оттенков расходится: один холоднее, другой теплее"


def _print_score(items: list[dict]) -> tuple[float, str]:
    statement = [g for g in items if _print(g) not in {"solid", "plain", "none", "однотонный", ""}]
    if len(statement) == 0:
        return 0.1, "в образе нет конкурирующих принтов"
    if len(statement) == 1:
        return 0.35, "принт только один, поэтому он остаётся читаемым акцентом"
    return -1.0, "в комплекте сразу несколько активных принтов — механический стилист считает это перегрузом"


def _fabric_score(a: dict, b: dict) -> tuple[float, str | None]:
    fa, fb = _fabric(a), _fabric(b)
    if "unknown" in {fa, fb}:
        return 0.0, None
    pair = FABRIC_PAIRS.get(frozenset((fa, fb)))
    if pair:
        return pair
    if fa == fb:
        return 0.08, "фактуры близки и не конфликтуют"
    return 0.0, None


def _fit_score(top: dict, bottom: dict) -> tuple[float, str]:
    ft = str(top.get("fit") or "").lower()
    fb = str(bottom.get("fit") or "").lower()
    loose = {"oversize", "loose", "relaxed", "wide", "свободный", "оверсайз"}
    fitted = {"fitted", "slim", "body", "облегающий", "приталенный"}
    if ft in loose and fb in loose:
        return -0.35, "и верх, и низ объёмные; без дополнительной структуры силуэт может потеряться"
    if (ft in loose and fb in fitted) or (ft in fitted and fb in loose):
        return 0.35, "объём распределён между верхом и низом, поэтому силуэт остаётся собранным"
    return 0.12, "пропорции верха и низа не создают явного конфликта"


def _layer_ok(base: dict, outer: dict) -> tuple[bool, str]:
    forbidden = {str(x).lower() for x in (outer.get("cannot_layer_over") or [])}
    base_tokens = {_cat(base), str(base.get("subtype") or "").lower(), _fabric(base)}
    for f in forbidden:
        if any(f and (f in token or token in f) for token in base_tokens):
            return False, f"верхний слой помечен как несовместимый с «{f}»"
    # A lightweight cardigan over a sweater is blocked mechanically unless explicitly allowed.
    if _cat(outer) == "cardigan" and str(outer.get("warmth")) in {"very_light", "light"} and _cat(base) == "sweater":
        if "sweater" not in {str(x).lower() for x in (outer.get("can_layer_over") or [])}:
            return False, "лёгкий кардиган не ставится поверх свитера"
    return True, "верхний слой разрешён для выбранной базы"


def _occasion_score(g: dict, occasion: str) -> float:
    tags = _occasions(g)
    return 0.2 if not tags or occasion in tags or "all" in tags else -0.35


def _style_score(items: list[dict], mood: str, profile: dict | None) -> tuple[float, str | None]:
    sets = [_styles(g) for g in items if _styles(g)]
    common = set.intersection(*sets) if sets else set()
    score = 0.12 * len(common)
    note = None
    if common:
        note = "вещи связаны общими стилевыми тегами: " + ", ".join(sorted(common)[:3])
    if mood != "random":
        score += 0.18 * sum(1 for g in items if mood in _styles(g))
    if profile:
        directions = {str(x).lower() for x in (profile.get("style_directions") or [])}
        if not directions and isinstance(profile.get("style_axes"), dict):
            directions = {str(k).lower() for k,v in profile["style_axes"].items() if isinstance(v,(int,float)) and v >= 60}
        score += 0.08 * sum(len(_styles(g) & directions) for g in items)
    return score, note


def _pair_reasons(items: list[dict]) -> tuple[float, list[str]]:
    score = 0.0
    reasons: list[str] = []
    for i in range(len(items)):
        for j in range(i + 1, len(items)):
            c, text = _color_score(items[i], items[j]); score += c
            if c >= 0.35 or c < 0: reasons.append(text)
            t, text2 = _temperature_score(items[i], items[j]); score += t
            if text2 and t != 0: reasons.append(text2)
            f, text3 = _fabric_score(items[i], items[j]); score += f
            if text3 and f > 0: reasons.append(text3)
    return score, reasons


def _choose_beauty(profile: dict | None, mood: str, seed: int) -> tuple[str, str]:
    if not profile:
        return "По ручному профилю стилиста", "По ручному профилю стилиста"
    hairs = profile.get("hairstyles") or []
    if not hairs and isinstance(profile.get("hair"), dict):
        raw = profile["hair"].get("styles") or profile["hair"].get("recommendations") or []
        hairs = [x.get("name") if isinstance(x,dict) else x for x in raw]
    makeups = profile.get("makeup_sets") or []
    if not makeups and isinstance(profile.get("makeup"), dict):
        raw = profile["makeup"].get("recipes") or []
        makeups = [x.get("name") if isinstance(x,dict) else x for x in raw]
    hairs = [x for x in hairs if x] or ["По персональному профилю"]
    makeups = [x for x in makeups if x] or ["По персональному профилю"]
    rnd = random.Random(seed)
    return str(rnd.choice(hairs)), str(rnd.choice(makeups))


def generate_outfit(
    garments: list[dict],
    profile: dict | None,
    request: OutfitRequest,
    recent_ids: list[int] | None = None,
) -> OutfitResult:
    available = [g for g in garments if _is_available(g)]
    tops = [g for g in available if _cat(g) in TOP_CATS or _role(g, "top")]
    bottoms = [g for g in available if _cat(g) in BOTTOM_CATS or _role(g, "bottom")]
    shoes = [g for g in available if _cat(g) in SHOE_CATS or _role(g, "shoes")]
    dresses = [g for g in available if _cat(g) in DRESS_CATS or _role(g, "dress")]
    outers = [g for g in available if _cat(g) in OUTER_CATS or _role(g, "outer") or _role(g, "light_outer")]

    if not shoes:
        raise ValueError("Для образа пока не хватает обуви")
    if not ((tops and bottoms) or dresses):
        raise ValueError("Для образа нужен либо верх + низ, либо платье/комбинезон")

    recent = Counter(recent_ids or [])
    candidates: list[tuple[float, list[dict], list[str]]] = []

    bases: list[list[dict]] = [[t, b, s] for t, b, s in product(tops, bottoms, shoes)]
    bases += [[d, s] for d, s in product(dresses, shoes)]

    for base in bases:
        score = 0.0
        reasons: list[str] = []
        # occasion
        score += sum(_occasion_score(g, request.occasion) for g in base)
        # novelty / diversity: penalize repeated and often-worn items.
        score -= request.novelty * sum(0.12 * recent[g["id"]] + 0.015 * g.get("wear_count", 0) for g in base)
        # controlled random tie-breaker only; not AI.
        score += random.random() * (0.08 + request.novelty * 0.08)

        pair_score, pair_reasons = _pair_reasons(base)
        score += pair_score; reasons.extend(pair_reasons)
        pscore, ptext = _print_score(base); score += pscore; reasons.append(ptext)
        if len(base) >= 3 and base[0] in tops and base[1] in bottoms:
            fs, ftext = _fit_score(base[0], base[1]); score += fs; reasons.append(ftext)
        ss, stext = _style_score(base, request.mood, profile); score += ss
        if stext: reasons.append(stext)

        chosen = list(base)
        # Optional outer layer. Only add if it doesn't make the score worse.
        best_outer: tuple[float, dict, list[str]] | None = None
        anchor = base[0]
        for outer in outers:
            if outer["id"] in {g["id"] for g in chosen}: continue
            ok, layer_reason = _layer_ok(anchor, outer)
            if not ok: continue
            local = _occasion_score(outer, request.occasion)
            prs, pr = _pair_reasons([anchor, outer]); local += prs
            local -= request.novelty * (0.1 * recent[outer["id"]] + 0.015 * outer.get("wear_count", 0))
            if best_outer is None or local > best_outer[0]:
                best_outer = (local, outer, [layer_reason] + pr)
        if best_outer and best_outer[0] > -0.05 and random.random() < 0.65:
            score += best_outer[0]
            chosen.append(best_outer[1])
            reasons.extend(best_outer[2])

        # Deduplicate repeated mechanical reasons while preserving order.
        unique: list[str] = []
        for r in reasons:
            if r and r not in unique: unique.append(r)
        candidates.append((score, chosen, unique[:8]))

    candidates.sort(key=lambda x: x[0], reverse=True)
    _, chosen, reasons = candidates[0]
    seed = sum(int(g["id"]) for g in chosen) + len(request.mood)
    hair, makeup = _choose_beauty(profile, request.mood, seed)
    return OutfitResult(garment_ids=[int(g["id"]) for g in chosen], explanation=reasons, hairstyle=hair, makeup=makeup)


def generate_capsule(garments: list[dict], style: str, max_items: int = 12) -> list[int]:
    """Mechanical style capsule: enough tops/bottoms/shoes/outerwear, ranked by style tags and availability."""
    available = [g for g in garments if _is_available(g)]
    style_l = style.lower()

    def score(g: dict) -> float:
        s = 1.0 if style_l in _styles(g) else 0.0
        s += 0.15 if "basic" in _styles(g) or "classic" in _styles(g) else 0.0
        s -= 0.02 * g.get("wear_count", 0)
        return s

    groups = [
        [g for g in available if _cat(g) in TOP_CATS or _role(g, "top")],
        [g for g in available if _cat(g) in BOTTOM_CATS or _role(g, "bottom")],
        [g for g in available if _cat(g) in SHOE_CATS or _role(g, "shoes")],
        [g for g in available if _cat(g) in OUTER_CATS or _role(g, "outer")],
    ]
    picks: list[dict] = []
    quotas = [4, 3, 2, 2]
    for group, q in zip(groups, quotas):
        picks.extend(sorted(group, key=score, reverse=True)[:q])
    remaining = [g for g in sorted(available, key=score, reverse=True) if g["id"] not in {p["id"] for p in picks}]
    picks.extend(remaining[: max(0, max_items - len(picks))])
    return [int(g["id"]) for g in picks[:max_items]]


def _slot(g: dict) -> str:
    c = _cat(g)
    if c in SHOE_CATS or _role(g, "shoes"):
        return "shoes"
    if c in BOTTOM_CATS or _role(g, "bottom"):
        return "bottom"
    if c in DRESS_CATS or _role(g, "dress"):
        return "dress"
    if c in OUTER_CATS or _role(g, "outer") or _role(g, "light_outer"):
        return "outer"
    return "top"


def replace_garment_in_outfit(
    garments: list[dict],
    profile: dict | None,
    current_ids: list[int],
    replace_id: int,
    request: OutfitRequest,
    recent_ids: list[int] | None = None,
) -> OutfitResult:
    available = [g for g in garments if _is_available(g)]
    by_id = {int(g["id"]): g for g in available}
    current = [by_id[i] for i in current_ids if i in by_id]
    target = by_id.get(int(replace_id))
    if not target or int(replace_id) not in {int(x["id"]) for x in current}:
        raise ValueError("Вещь для замены не найдена в текущем образе")
    slot = _slot(target)
    candidates = [g for g in available if _slot(g) == slot and int(g["id"]) not in set(current_ids)]
    if not candidates:
        raise ValueError("В гардеробе пока нет другой вещи для этой позиции")
    recent = Counter(recent_ids or [])
    ranked: list[tuple[float, dict, list[str]]] = []
    others = [g for g in current if int(g["id"]) != int(replace_id)]
    for alt in candidates:
        chosen = others + [alt]
        # Hard layering rule when replacing top/outer.
        if slot == "outer":
            base = next((g for g in chosen if _slot(g) in {"top", "dress"}), None)
            if base:
                ok, reason = _layer_ok(base, alt)
                if not ok:
                    continue
        score = _occasion_score(alt, request.occasion)
        score -= request.novelty * (0.13 * recent[int(alt["id"])] + 0.02 * alt.get("wear_count", 0))
        prs, reasons = _pair_reasons(chosen)
        score += prs
        ps, ptext = _print_score(chosen)
        score += ps
        reasons.append(ptext)
        top = next((g for g in chosen if _slot(g) == "top"), None)
        bottom = next((g for g in chosen if _slot(g) == "bottom"), None)
        if top and bottom:
            fs, ftext = _fit_score(top, bottom)
            score += fs
            reasons.append(ftext)
        ss, stext = _style_score(chosen, request.mood, profile)
        score += ss
        if stext:
            reasons.append(stext)
        unique = []
        for r in reasons:
            if r and r not in unique:
                unique.append(r)
        ranked.append((score, alt, unique[:7]))
    if not ranked:
        raise ValueError("Не нашлось физически допустимой замены")
    ranked.sort(key=lambda x: x[0], reverse=True)
    # Diversity: choose from top few when novelty is high, not always the same winner.
    top_n = min(len(ranked), 1 + round(request.novelty * 3))
    _, alt, reasons = random.choice(ranked[:top_n])
    new_ids = [int(alt["id"]) if int(i) == int(replace_id) else int(i) for i in current_ids]
    seed = sum(new_ids) + len(request.mood)
    hair, makeup = _choose_beauty(profile, request.mood, seed)
    return OutfitResult(garment_ids=new_ids, explanation=reasons, hairstyle=hair, makeup=makeup)
