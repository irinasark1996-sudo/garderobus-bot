BUCKET_LABELS = {
    "white": "Белое",
    "light": "Светлое",
    "dark": "Тёмное",
    "color": "Цветное",
    "delicate": "Деликатное",
    "handwash": "Ручная стирка",
    "dry_clean": "Химчистка",
    "unknown": "Нужно уточнить",
}


def group_laundry(garments: list[dict]) -> dict[str, list[dict]]:
    buckets = {key: [] for key in BUCKET_LABELS}
    for garment in garments:
        if garment.get("status") != "laundry":
            continue
        key = garment.get("laundry_group") or "unknown"
        if key not in buckets:
            key = "unknown"
        buckets[key].append(garment)
    return buckets
