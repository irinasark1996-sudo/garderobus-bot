from pathlib import Path
from typing import Any

from .. import db
from ..config import settings
from .garment_processing import save_original
from .laundry import BUCKET_LABELS, group_laundry
from .telegram import TelegramAPI, main_menu_keyboard

PROFILE_STEPS = [
    ("profile_face_front", "face_front", "1/5. Фото лица анфас. Без фильтра, камера примерно на уровне глаз, нейтральный дневной свет."),
    ("profile_face_34", "face_34", "2/5. Фото лица в ракурсе ¾. Волосы желательно убрать так, чтобы были видны контуры лица."),
    ("profile_face_profile", "face_profile", "3/5. Фото лица строго в профиль. Камера на уровне лица, без сильной перспективы."),
    ("profile_body_front", "body_front", "4/5. Фото в полный рост спереди. Стоять прямо, камера примерно на уровне середины корпуса. Одежда не должна сильно скрывать линии фигуры."),
    ("profile_body_side", "body_side", "5/5. Фото в полный рост сбоку. Та же одежда и по возможности то же расстояние до камеры."),
]
STATUS_LABELS = {"clean":"чистая","worn":"надета","laundry":"в стирке","washing":"стирается","drying":"сушится","repair":"в ремонте","seasonal":"убрана на сезон","loaned":"одолжена"}


def _has_ready_profile(user_id: int) -> bool:
    p = db.get_profile(user_id) or {}
    return p.get("status") == "ready" or p.get("schema") == "garderobus.appearance.v1"


def _is_paid(user_id: int) -> bool:
    return settings.beta_free_access or db.is_paid(user_id)


def _menu(user_id: int):
    user = db.get_user(user_id) or {}
    return main_menu_keyboard(_has_ready_profile(user_id), _is_paid(user_id), str(user.get("client_code") or ""))


async def _admin_text(tg: TelegramAPI, text: str):
    if settings.admin_telegram_id:
        try:
            await tg.send_message(settings.admin_telegram_id, text)
        except Exception as e:
            print(f"Admin notify failed: {type(e).__name__}: {e}", flush=True)


async def _admin_forward(tg: TelegramAPI, chat_id: int, message_id: int):
    if settings.admin_telegram_id:
        try:
            await tg.forward_message(settings.admin_telegram_id, chat_id, message_id)
        except Exception as e:
            print(f"Admin forward failed: {type(e).__name__}: {e}", flush=True)


def _profile_text(p: dict) -> str:
    if p.get("schema") == "garderobus.appearance.v1":
        color = p.get("color") or {}
        body = p.get("body") or {}
        lines = p.get("clothing_lines") or {}
        return (
            "Твой персональный профиль:\n\n"
            f"Температура: {color.get('temperature','—')}\n"
            f"Глубина: {color.get('depth','—')}\n"
            f"Контраст: {color.get('contrast','—')}\n"
            f"Вертикаль: {body.get('vertical_line','—')}\n"
            f"Линии: {lines.get('preferred_line','—')}\n"
            f"Посадка: {lines.get('preferred_fit','—')}"
        )
    return (
        "Твой профиль после личного типирования:\n\n"
        f"{p.get('summary') or '—'}\n\n"
        f"Цвет: {p.get('color_direction') or '—'}\n"
        f"Контраст: {p.get('contrast') or '—'}\n"
        f"Линии: {p.get('line_direction') or '—'}\n"
        f"Стилевые направления: {', '.join(p.get('style_directions') or []) or '—'}\n"
        f"Подходящие цвета: {', '.join(p.get('flattering_colors') or []) or '—'}"
    )


def _help() -> str:
    return (
        "Как работает Гардеробус:\n\n"
        "1. Сначала можно бесплатно посмотреть демо-Капсулу.\n"
        "2. После оформления персонального Гардеробуса открывается консультация.\n"
        "3. Ты отвечаешь на вопросы и присылаешь 5 фотографий внешности.\n"
        "4. Затем присылаешь фотографии всего гардероба — ограничение по 10 фото убрано.\n"
        "5. Стилист подготавливает профиль и цифровые карточки вещей.\n"
        "6. После публикации Капсула работает механически: без AI-вызовов внутри приложения."
    )


async def _begin_consultation(user_id: int, chat_id: int, tg: TelegramAPI):
    if not _is_paid(user_id):
        user = db.get_user(user_id) or {}
        code = user.get("client_code") or "—"
        await tg.send_message(
            chat_id,
            f"Персональная консультация открывается после оформления Гардеробуса.\n\nТвой номер: {code}\nBeta-цена: {settings.product_price_rub} ₽.\n\nПока можно открыть демо и посмотреть, как работает готовая Капсула.",
            _menu(user_id),
        )
        return
    db.clear_profile_photos(user_id)
    db.save_consultation(user_id, {}, status="draft")
    db.set_state(user_id, "consult_goal", {"answers": {}})
    await tg.send_message(chat_id, "Сначала короткая консультация. Что ты хочешь получить от гардероба: быстрее собираться, использовать больше вещей, обновить стиль, понять цвета, собрать капсулы или что-то другое?")


async def _handle_consult_text(user_id: int, chat_id: int, text: str, state: str, tg: TelegramAPI):
    ctx = db.get_context(user_id)
    answers = ctx.get("answers") or {}
    if state == "consult_goal":
        answers["goal"] = text
        db.set_state(user_id, "consult_lifestyle", {"answers": answers})
        await tg.send_message(chat_id, "Где проходит большая часть твоей недели и для каких ситуаций чаще всего нужна одежда?")
    elif state == "consult_lifestyle":
        answers["lifestyle"] = text
        db.set_state(user_id, "consult_preferences", {"answers": answers})
        await tg.send_message(chat_id, "Что ты любишь и категорически не любишь носить? Напиши про длины, обувь, посадку, цвета, открытость тела и любые ограничения.")
    else:
        answers["preferences"] = text
        db.save_consultation(user_id, answers, status="draft")
        db.set_state(user_id, PROFILE_STEPS[0][0], {"answers": answers, "profile_index": 0})
        await tg.send_message(chat_id, "Анкета сохранена. Теперь 5 фотографий для типирования. Я буду просить их по одной, чтобы ничего не перепуталось.")
        await tg.send_message(chat_id, PROFILE_STEPS[0][2])


async def _save_profile_photo(user_id: int, chat_id: int, message: dict, idx: int, tg: TelegramAPI):
    photos = message.get("photo") or []
    if not photos:
        return
    data, remote = await tg.download_file(photos[-1]["file_id"])
    p = save_original(data, Path(remote).suffix or ".jpg", folder="media")
    db.add_profile_photo(user_id, str(p), PROFILE_STEPS[idx][1])
    await _admin_forward(tg, chat_id, int(message.get("message_id", 0)))
    if idx < len(PROFILE_STEPS) - 1:
        ni = idx + 1
        ctx = db.get_context(user_id)
        ctx["profile_index"] = ni
        db.set_state(user_id, PROFILE_STEPS[ni][0], ctx)
        await tg.send_message(chat_id, PROFILE_STEPS[ni][2])
        return
    answers = (db.get_consultation(user_id) or {}).get("answers") or db.get_context(user_id).get("answers") or {}
    db.save_consultation(user_id, answers, status="submitted")
    db.set_state(user_id, "awaiting_typing", {})
    u = db.get_user(user_id) or {}
    uname = ("@" + u.get("username")) if u.get("username") else "без username"
    code = u.get("client_code") or str(user_id)
    await _admin_text(
        tg,
        f"Новая консультация {code}\n{u.get('first_name','')} · {uname}\nЦель: {answers.get('goal','—')}\nОбраз жизни: {answers.get('lifestyle','—')}\nПредпочтения: {answers.get('preferences','—')}\n\nАдминка: {settings.resolved_public_base_url}/admin/user/{user_id}",
    )
    await tg.send_message(chat_id, "Все 5 фотографий получены. Материалы отправлены на типирование. Когда профиль будет загружен, бот сам откроет следующий этап — фотографии гардероба.", _menu(user_id))


WARDROBE_INSTRUCTION = (
    "Теперь пришли фотографии ВСЕГО гардероба. Ограничения по количеству фото нет.\n\n"
    "Как снимать:\n"
    "• на одном кадре может быть несколько вещей;\n"
    "• каждая вещь должна быть видна целиком;\n"
    "• вещи лучше не накладывать друг на друга;\n"
    "• между предметами оставляй небольшой промежуток;\n"
    "• лучше однотонный контрастный фон и ровный свет;\n"
    "• верх расправь вместе с рукавами, брюки — от пояса до низа, обувь снимай парой;\n"
    "• если важная деталь не видна спереди, можно прислать дополнительный кадр.\n\n"
    "Присылай фотографии несколькими сообщениями. Когда закончишь, нажми «Все вещи отправлены»."
)


def _done_keyboard():
    return {"inline_keyboard": [[{"text": "Все вещи отправлены", "callback_data": "batch:done"}]]}


async def _start_batch(user_id: int, chat_id: int, tg: TelegramAPI):
    if not _is_paid(user_id):
        await tg.send_message(chat_id, "Загрузка личного гардероба открывается после оформления персонального Гардеробуса.", _menu(user_id))
        return
    if not _has_ready_profile(user_id):
        await tg.send_message(chat_id, "Сначала нужно закончить консультацию и типирование.", _menu(user_id))
        return
    active = db.get_active_batch(user_id)
    batch_id = active["id"] if active else db.create_batch(user_id)
    db.set_state(user_id, "batch_collect", {"batch_id": batch_id})
    await tg.send_message(chat_id, WARDROBE_INSTRUCTION, _done_keyboard())


async def _save_batch_photo(user_id: int, chat_id: int, message: dict, tg: TelegramAPI):
    ctx = db.get_context(user_id)
    batch_id = int(ctx.get("batch_id") or 0)
    if not batch_id:
        await _start_batch(user_id, chat_id, tg)
        return
    photos = message.get("photo") or []
    if not photos:
        return
    data, remote = await tg.download_file(photos[-1]["file_id"])
    path = save_original(data, Path(remote).suffix or ".jpg", folder="media")
    db.add_batch_photo(batch_id, user_id, str(path), int(message.get("message_id", 0)))
    await _admin_forward(tg, chat_id, int(message.get("message_id", 0)))
    count = len(db.list_batch_photos(batch_id))
    await tg.send_message(chat_id, f"Сохранено фотографий: {count}. Продолжай или нажми «Все вещи отправлены».", _done_keyboard())


async def _finish_batch(user_id: int, chat_id: int, tg: TelegramAPI):
    ctx = db.get_context(user_id)
    batch_id = int(ctx.get("batch_id") or 0)
    if not batch_id:
        active = db.get_active_batch(user_id)
        batch_id = int(active["id"]) if active else 0
    if not batch_id:
        await tg.send_message(chat_id, "Сейчас нет активной загрузки гардероба.")
        return
    photos = db.list_batch_photos(batch_id)
    if not photos:
        await tg.send_message(chat_id, "Пока не получено ни одной фотографии.", _done_keyboard())
        return
    db.set_batch_status(batch_id, "submitted")
    db.set_state(user_id, "batch_submitted", {})
    u = db.get_user(user_id) or {}
    code = u.get("client_code") or str(user_id)
    await _admin_text(tg, f"Гардероб {code}: пакет #{batch_id}, фотографий {len(photos)}. Обработать: {settings.resolved_public_base_url}/admin/batch/{batch_id}")
    await tg.send_message(chat_id, f"Получено {len(photos)} фотографий. Гардероб отправлен на оцифровку. После публикации все вещи появятся в твоей Капсуле.", _menu(user_id))


async def show_wardrobe(user_id: int, chat_id: int, tg: TelegramAPI):
    items = [g for g in db.list_garments(user_id) if g.get("confirmed")]
    if not items:
        await tg.send_message(chat_id, "Персональный гардероб пока обрабатывается или ещё не загружен.", _menu(user_id))
        return
    await tg.send_message(chat_id, f"В твоём цифровом гардеробе {len(items)} вещей. Открой Капсулу для просмотра и стилиста.", _menu(user_id))


async def show_laundry(user_id: int, chat_id: int, tg: TelegramAPI):
    buckets = group_laundry(db.list_garments(user_id))
    lines = ["Корзины для стирки:"]
    for k, label in BUCKET_LABELS.items():
        lines.append(f"• {label}: {len(buckets.get(k, []))}")
    await tg.send_message(chat_id, "\n".join(lines), _menu(user_id))


async def handle_update(update: dict[str, Any]):
    tg = TelegramAPI()
    cb = update.get("callback_query")
    if cb:
        user = cb.get("from") or {}
        uid = int(user.get("id", 0))
        chat = int((cb.get("message") or {}).get("chat", {}).get("id", uid))
        db.upsert_user(uid, user.get("first_name", ""), user.get("username", ""))
        data = cb.get("data", "")
        await tg.answer_callback(cb.get("id", ""))
        if data == "consult:start":
            await _begin_consultation(uid, chat, tg)
        elif data == "batch:start":
            await _start_batch(uid, chat, tg)
        elif data == "batch:done":
            await _finish_batch(uid, chat, tg)
        elif data == "menu:profile":
            p = db.get_profile(uid)
            await tg.send_message(chat, _profile_text(p) if p else "Профиль ещё готовится.", _menu(uid))
        elif data == "menu:status":
            c = db.get_consultation(uid)
            b = db.get_active_batch(uid)
            u = db.get_user(uid) or {}
            await tg.send_message(
                chat,
                f"Номер: {u.get('client_code') or '—'}\nОплата: {'активна' if _is_paid(uid) else 'не оформлена'}\nКонсультация: {(c or {}).get('status','не начата')}\nТипирование: {'готово' if _has_ready_profile(uid) else 'ожидается'}\nАктивная загрузка гардероба: {b['id'] if b else 'нет'}",
                _menu(uid),
            )
        elif data == "menu:wardrobe":
            await show_wardrobe(uid, chat, tg)
        elif data == "menu:laundry":
            await show_laundry(uid, chat, tg)
        return

    msg = update.get("message")
    if not msg:
        return
    user = msg.get("from") or {}
    uid = int(user.get("id", 0))
    chat = int((msg.get("chat") or {}).get("id", uid))
    db.upsert_user(uid, user.get("first_name", ""), user.get("username", ""))
    text = (msg.get("text") or "").strip()
    state = db.get_state(uid)
    if text == "/start":
        u = db.get_user(uid) or {}
        code = u.get("client_code") or "—"
        if _is_paid(uid):
            text0 = f"Гардеробус · {code}\n\nПерсональный доступ активен. Продолжи с текущего этапа или открой Капсулу."
        else:
            text0 = f"Гардеробус · {code}\n\nСначала можно бесплатно посмотреть демо готовой Капсулы. Персональная beta-версия сейчас стоит {settings.product_price_rub} ₽."
        await tg.send_message(chat, text0, _menu(uid))
        return
    if text == "/myid":
        u = db.get_user(uid) or {}
        await tg.send_message(chat, f"Твой номер Гардеробуса: {u.get('client_code') or '—'}")
        return
    if text == "/consultation":
        await _begin_consultation(uid, chat, tg)
        return
    if text in {"/wardrobe", "/add"}:
        await _start_batch(uid, chat, tg)
        return
    if text == "/done":
        await _finish_batch(uid, chat, tg)
        return
    if text == "/profile":
        p = db.get_profile(uid)
        await tg.send_message(chat, _profile_text(p) if p else "Профиль ещё не готов.", _menu(uid))
        return
    if text == "/laundry":
        await show_laundry(uid, chat, tg)
        return
    if text == "/help":
        await tg.send_message(chat, _help(), _menu(uid))
        return
    if state in {"consult_goal", "consult_lifestyle", "consult_preferences"} and text:
        await _handle_consult_text(uid, chat, text, state, tg)
        return
    if state.startswith("profile_") and msg.get("photo"):
        idx = next((i for i, x in enumerate(PROFILE_STEPS) if x[0] == state), 0)
        await _save_profile_photo(uid, chat, msg, idx, tg)
        return
    if state == "batch_collect" and msg.get("photo"):
        await _save_batch_photo(uid, chat, msg, tg)
        return
    await tg.send_message(chat, "Выбери действие в меню.", _menu(uid))
