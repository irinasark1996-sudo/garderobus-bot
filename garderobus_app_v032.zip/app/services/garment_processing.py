import shutil
import uuid
from pathlib import Path

from PIL import Image

from ..config import settings


def save_original(data: bytes, suffix: str = ".jpg") -> Path:
    folder = settings.storage_path / "garments"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"original_{uuid.uuid4().hex}{suffix}"
    path.write_bytes(data)
    return path


def remove_background(source: Path) -> Path:
    """Use rembg when installed; otherwise preserve the image so the rest of the pipeline remains runnable."""
    destination = source.with_name(source.stem.replace("original_", "cutout_") + ".png")
    try:
        from rembg import remove  # optional dependency
        destination.write_bytes(remove(source.read_bytes()))
    except Exception:
        # Non-destructive fallback for environments where the segmentation extra is not installed.
        with Image.open(source) as image:
            image.convert("RGBA").save(destination)
    return destination


def public_media_copy(source: Path) -> Path:
    media = settings.storage_path / "media"
    media.mkdir(parents=True, exist_ok=True)
    dest = media / source.name
    if source.resolve() != dest.resolve():
        shutil.copy2(source, dest)
    return dest
