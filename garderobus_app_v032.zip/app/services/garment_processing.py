from __future__ import annotations

from pathlib import Path
from uuid import uuid4

from PIL import Image

from ..config import settings


def _folder(name: str) -> Path:
    p = settings.storage_path / name
    p.mkdir(parents=True, exist_ok=True)
    return p


def save_original(data: bytes, suffix: str = ".jpg", folder: str = "media") -> Path:
    suffix = suffix.lower() if suffix else ".jpg"
    if suffix not in {".jpg", ".jpeg", ".png", ".webp"}:
        suffix = ".jpg"
    path = _folder(folder) / f"{uuid4().hex}{suffix}"
    path.write_bytes(data)
    return path


def public_media_copy(path: str | Path) -> Path:
    # Files already live under /storage/media in the no-AI architecture.
    p = Path(path)
    media = _folder("media")
    if p.parent == media:
        return p
    target = media / f"{uuid4().hex}{p.suffix.lower() or '.png'}"
    target.write_bytes(p.read_bytes())
    return target


def _corner_background_cleanup(image: Image.Image, tolerance: int = 34) -> Image.Image:
    """Mechanical corner-color keying for simple studio backgrounds.

    This is intentionally not ML/AI. It works only when the photo background is
    fairly uniform. For complex scenes the admin should leave cleanup disabled.
    """
    rgba = image.convert("RGBA")
    px = rgba.load()
    w, h = rgba.size
    samples = [px[0, 0], px[w - 1, 0], px[0, h - 1], px[w - 1, h - 1]]
    bg = tuple(sum(c[i] for c in samples) / len(samples) for i in range(3))

    out = Image.new("RGBA", rgba.size)
    opx = out.load()
    tol2 = tolerance * tolerance * 3
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            d2 = (r - bg[0]) ** 2 + (g - bg[1]) ** 2 + (b - bg[2]) ** 2
            if d2 <= tol2:
                opx[x, y] = (r, g, b, 0)
            else:
                opx[x, y] = (r, g, b, a)
    return out


def crop_manual(
    source_path: str | Path,
    x: float,
    y: float,
    w: float,
    h: float,
    cleanup_background: bool = False,
) -> Path:
    src = Path(source_path)
    with Image.open(src) as im:
        im = im.convert("RGBA")
        iw, ih = im.size
        left = max(0, min(iw - 1, round(x * iw)))
        top = max(0, min(ih - 1, round(y * ih)))
        right = max(left + 1, min(iw, round((x + w) * iw)))
        bottom = max(top + 1, min(ih, round((y + h) * ih)))
        cropped = im.crop((left, top, right, bottom))
        if cleanup_background:
            cropped = _corner_background_cleanup(cropped)
        # Give the paper-collage some breathing room without distorting the item.
        pad = max(12, round(max(cropped.size) * 0.05))
        canvas = Image.new("RGBA", (cropped.width + pad * 2, cropped.height + pad * 2), (0, 0, 0, 0))
        canvas.alpha_composite(cropped, (pad, pad))
        target = _folder("media") / f"garment_{uuid4().hex}.png"
        canvas.save(target, "PNG", optimize=True)
        return target


def make_contact_sheet(items: list[tuple[str | Path, str]], title: str = "Гардероб") -> Path:
    """Create a simple mechanical contact sheet from already cropped garment images."""
    from PIL import ImageDraw, ImageFont
    cols = 3
    cell_w, cell_h = 420, 520
    head_h = 90
    rows = max(1, (len(items) + cols - 1) // cols)
    sheet = Image.new("RGB", (cols * cell_w, head_h + rows * cell_h), (246, 240, 230))
    draw = ImageDraw.Draw(sheet)
    draw.text((28, 25), title, fill=(36, 31, 26))
    for i, (path, label) in enumerate(items):
        r, c = divmod(i, cols)
        x0, y0 = c * cell_w, head_h + r * cell_h
        draw.rounded_rectangle((x0 + 12, y0 + 12, x0 + cell_w - 12, y0 + cell_h - 12), 22, fill=(255, 253, 248), outline=(222, 212, 197))
        with Image.open(path) as im:
            im = im.convert("RGBA")
            max_w, max_h = cell_w - 60, cell_h - 120
            scale = min(max_w / im.width, max_h / im.height, 1.0)
            size = (max(1, int(im.width * scale)), max(1, int(im.height * scale)))
            im = im.resize(size, Image.Resampling.LANCZOS)
            px = x0 + (cell_w - size[0]) // 2
            py = y0 + 28 + (max_h - size[1]) // 2
            base = Image.new("RGBA", sheet.size, (0, 0, 0, 0)); base.alpha_composite(im, (px, py))
            sheet.paste(base.convert("RGB"), (0, 0), base)
        draw.text((x0 + 28, y0 + cell_h - 65), f"{i+1}. {label[:34]}", fill=(36, 31, 26))
    target = _folder("media") / f"contact_{uuid4().hex}.jpg"
    sheet.save(target, "JPEG", quality=90, optimize=True)
    return target
