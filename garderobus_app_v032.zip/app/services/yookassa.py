from __future__ import annotations

import uuid
import httpx

from ..config import settings

API_BASE = "https://api.yookassa.ru/v3"


class YooKassaError(RuntimeError):
    pass


def _auth() -> tuple[str, str]:
    if not settings.yookassa_configured:
        raise YooKassaError("YooKassa is not configured")
    return settings.yookassa_shop_id.strip(), settings.yookassa_secret_key.strip()


async def create_payment(*, amount_rub: int, description: str, client_code: str, user_id: int, method: str = "smart") -> dict:
    payload: dict = {
        "amount": {"value": f"{amount_rub:.2f}", "currency": "RUB"},
        "capture": True,
        "confirmation": {"type": "redirect", "return_url": settings.resolved_yookassa_return_url},
        "description": description[:128],
        "metadata": {"telegram_user_id": str(user_id), "client_code": client_code},
    }
    if method == "sbp":
        payload["payment_method_data"] = {"type": "sbp"}
    headers = {"Idempotence-Key": str(uuid.uuid4())}
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post(f"{API_BASE}/payments", auth=_auth(), headers=headers, json=payload)
    if response.status_code >= 300:
        try:
            detail = response.json()
        except Exception:
            detail = response.text
        raise YooKassaError(f"YooKassa create payment failed: {response.status_code}: {detail}")
    return response.json()


async def get_payment(payment_id: str) -> dict:
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.get(f"{API_BASE}/payments/{payment_id}", auth=_auth())
    if response.status_code >= 300:
        raise YooKassaError(f"YooKassa get payment failed: {response.status_code}")
    return response.json()
