import base64
import json
import mimetypes
from pathlib import Path

from ..config import settings
from ..models import AppearanceProfile, GarmentAnalysis


class AIUnavailable(RuntimeError):
    pass


def _client():
    if not settings.openai_api_key:
        raise AIUnavailable("OPENAI_API_KEY is not configured on the server")
    from openai import OpenAI
    return OpenAI(api_key=settings.openai_api_key)


def _data_url(path: str | Path) -> str:
    p = Path(path)
    mime = mimetypes.guess_type(p.name)[0] or "image/jpeg"
    return f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode('ascii')}"


# Structured Outputs supports a deliberately limited JSON Schema subset.
# Pydantic emits validation-only keywords such as minimum/maximum that are
# useful locally but can make the API reject the response schema with HTTP 400.
_UNSUPPORTED_STRICT_SCHEMA_KEYS = {
    "minimum", "maximum", "exclusiveMinimum", "exclusiveMaximum", "multipleOf",
    "minLength", "maxLength", "pattern", "format",
    "minItems", "maxItems", "uniqueItems",
    "minProperties", "maxProperties",
}


def _openai_strict_schema(value):
    if isinstance(value, list):
        return [_openai_strict_schema(item) for item in value]
    if not isinstance(value, dict):
        return value

    cleaned = {}
    for key, item in value.items():
        if key in _UNSUPPORTED_STRICT_SCHEMA_KEYS:
            continue
        cleaned[key] = _openai_strict_schema(item)

    # Strict Structured Outputs requires closed objects. Pydantic's normal
    # model_json_schema() does not add this unless extra='forbid' is configured.
    if cleaned.get("type") == "object" or "properties" in cleaned:
        cleaned["additionalProperties"] = False
        props = cleaned.get("properties") or {}
        if props:
            # All fields in a strict object must be listed in required.
            cleaned["required"] = list(props.keys())
    return cleaned


def _structured_response(name: str, schema: dict, content) -> dict:
    response = _client().responses.create(
        model=settings.openai_model,
        input=content,
        text={
            "format": {
                "type": "json_schema",
                "name": name,
                "schema": _openai_strict_schema(schema),
                "strict": True,
            }
        },
    )
    return json.loads(response.output_text)


def analyze_garment(path: str | Path) -> GarmentAnalysis:
    payload = _structured_response(
        "garment_analysis",
        GarmentAnalysis.model_json_schema(),
        [{
            "role": "user",
            "content": [
                {
                    "type": "input_text",
                    "text": (
                        "Analyze exactly one clothing item in the image for a digital wardrobe. "
                        "Do not invent care-label facts. Infer fabric only as a guess. "
                        "Layer roles must reflect physical wearability. A thin cardigan must not be marked as suitable over chunky knit. "
                        "If the item is sheer, include useful base-layer roles and a short uncertainty question when needed. "
                        "Laundry group is a preliminary visual guess only; dry-clean/handwash should be used only when strongly suggested. "
                        "Use concise Russian names for title, colors and free-text fields."
                    ),
                },
                {"type": "input_image", "image_url": _data_url(path), "detail": "high"},
            ],
        }],
    )
    return GarmentAnalysis.model_validate(payload)


def revise_garment(path: str | Path, current: dict, correction: str) -> GarmentAnalysis:
    payload = _structured_response(
        "garment_revision",
        GarmentAnalysis.model_json_schema(),
        [{
            "role": "user",
            "content": [
                {
                    "type": "input_text",
                    "text": (
                        "Revise this digital wardrobe garment card using the user's correction as authoritative. "
                        "Keep properties that are still supported by the image/current card. Never invent care-label facts. "
                        "Fabric remains a visual guess. Layer roles must reflect physical wearability. "
                        f"Current card: {json.dumps(current, ensure_ascii=False)}\n"
                        f"User correction: {correction}"
                    ),
                },
                {"type": "input_image", "image_url": _data_url(path), "detail": "high"},
            ],
        }],
    )
    return GarmentAnalysis.model_validate(payload)


def analyze_appearance(paths: list[str | Path]) -> AppearanceProfile:
    if not paths:
        raise ValueError("At least one profile image is required")
    content = [{
        "type": "input_text",
        "text": (
            "Build a cautious styling profile from these photos. Do not identify the person. "
            "Do not present Kibbe, seasonal color analysis, or other typologies as objective facts. "
            "Describe continuous visual attributes useful for clothing, hair and makeup recommendations. "
            "Account for possible lighting/white-balance distortion and put uncertainties in caveats. "
            "Use concise Russian wording in all free-text fields."
        ),
    }]
    for path in paths[:5]:
        content.append({"type": "input_image", "image_url": _data_url(path), "detail": "high"})
    payload = _structured_response(
        "appearance_profile",
        AppearanceProfile.model_json_schema(),
        [{"role": "user", "content": content}],
    )
    return AppearanceProfile.model_validate(payload)


def explain_outfit(profile: dict | None, garments: list[dict], occasion: str, mood: str) -> list[str]:
    if not settings.openai_api_key:
        return _rule_explanation(garments)
    compact = [
        {
            "id": g.get("id"),
            "title": g.get("title"),
            "category": g.get("category"),
            "colors": g.get("colors"),
            "print": g.get("print"),
            "silhouette": g.get("silhouette"),
            "texture": g.get("texture"),
            "layer_roles": g.get("layer_roles"),
        }
        for g in garments
    ]
    schema = {
        "type": "object",
        "properties": {
            "reasons": {
                "type": "array",
                "items": {"type": "string"},
                "minItems": 3,
                "maxItems": 6,
            }
        },
        "required": ["reasons"],
        "additionalProperties": False,
    }
    payload = _structured_response(
        "outfit_reasons",
        schema,
        (
            "Explain why this outfit works using only the supplied garment/profile facts. "
            "Mention color, silhouette/proportion, texture/layering and occasion when supported. "
            "Never invent a color relationship that is not visible in the metadata. "
            f"Occasion: {occasion}. Mood: {mood}. Profile: {json.dumps(profile or {}, ensure_ascii=False)}. "
            f"Garments: {json.dumps(compact, ensure_ascii=False)}"
        ),
    )
    return payload["reasons"]


def _rule_explanation(garments: list[dict]) -> list[str]:
    names = ", ".join(g.get("title", "вещь") for g in garments)
    return [
        f"Комплект собран из физически совместимых слоёв: {names}.",
        "Вещи в стирке, сушке, ремонте и сезонном хранении исключены из подбора.",
        "После подключения OPENAI_API_KEY здесь появится подробное объяснение цвета, фактур и пропорций.",
    ]
