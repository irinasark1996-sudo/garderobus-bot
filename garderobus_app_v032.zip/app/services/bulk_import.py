from __future__ import annotations

import io
import json
import math
import zipfile
from pathlib import Path
from typing import Any
from uuid import uuid4

from PIL import Image

from .. import db
from ..config import settings


class ImportErrorDetail(ValueError):
    pass


def _safe_json(zf: zipfile.ZipFile, names: list[str]) -> dict:
    for name in names:
        if name in zf.namelist():
            return json.loads(zf.read(name).decode("utf-8-sig"))
    raise ImportErrorDetail(f"Не найден {' или '.join(names)}")


def _mapping_for(map_payload: dict, stem: str, filename: str) -> list[str | None]:
    raw = map_payload.get(filename)
    if raw is None:
        raw = map_payload.get(stem)
    if raw is None and "collages" in map_payload:
        raw = (map_payload.get("collages") or {}).get(filename) or (map_payload.get("collages") or {}).get(stem)
    if raw is None:
        return []
    if isinstance(raw, list):
        return [str(x) if x else None for x in raw][:9]
    if isinstance(raw, dict):
        out: list[str | None] = []
        for r in range(1, 4):
            for c in range(1, 4):
                value = raw.get(f"row{r}_col{c}") or raw.get(f"r{r}c{c}")
                out.append(str(value) if value else None)
        return out
    return []


def _crop_cell(image: Image.Image, index: int) -> Image.Image:
    image = image.convert("RGBA")
    w, h = image.size
    col = index % 3
    row = index // 3
    x0 = round(col * w / 3)
    x1 = round((col + 1) * w / 3)
    y0 = round(row * h / 3)
    y1 = round((row + 1) * h / 3)
    cell = image.crop((x0, y0, x1, y1))
    alpha = cell.getchannel("A")
    bbox = alpha.getbbox()
    if not bbox:
        return cell
    content = cell.crop(bbox)
    pad = max(10, round(max(content.size) * 0.07))
    canvas = Image.new("RGBA", (content.width + 2 * pad, content.height + 2 * pad), (0, 0, 0, 0))
    canvas.alpha_composite(content, (pad, pad))
    return canvas


def _garment_payload(item: dict[str, Any], batch_id: int) -> dict[str, Any]:
    color = item.get("color") or {}
    pattern = item.get("pattern") or {}
    if isinstance(pattern, str):
        pattern = {"pattern": pattern}
    depth = str(color.get("depth") or "unknown")
    value = {"deep": "dark", "light": "light", "medium": "medium"}.get(depth, "unknown")
    wear_modes = [str(x) for x in (item.get("wear_modes") or [])]
    roles: list[str] = []
    cat = str(item.get("category") or "")
    if cat == "top" or "base" in wear_modes or "base_over_underlayer" in wear_modes:
        roles.append("top")
    if cat == "bottom":
        roles.append("bottom")
    if cat in {"dress", "jumpsuit"}:
        roles.append("dress")
    if cat == "shoes":
        roles.append("shoes")
    if cat in {"mid_layer", "outerwear"} or any(x in wear_modes for x in ["open_layer", "mid_layer", "outer_layer", "outerwear"]):
        roles.append("outer")
    dominant = list(color.get("dominant_colors") or [])
    secondary = list(color.get("secondary_colors") or [])
    external_id = str(item.get("id") or "")
    return {
        "external_id": external_id,
        "title": str(item.get("name") or external_id or "Вещь"),
        "category": cat,
        "subtype": str(item.get("sub_category") or ""),
        "color_family": str(color.get("color_family") or (dominant[0] if dominant else "neutral")),
        "color_name": str(color.get("color_name") or ""),
        "temperature": str(color.get("temperature") or "unknown"),
        "value": value,
        "chroma": str(color.get("chroma") or "unknown"),
        "print": str(pattern.get("pattern") or item.get("pattern") or "solid"),
        "print_colors": [str(x) for x in dominant + secondary],
        "silhouette": str(item.get("shape") or ""),
        "length": str(item.get("length") or ""),
        "fit": str(item.get("fit") or ""),
        "fabric_family": str(item.get("visual_material_family") or "unknown"),
        "texture": [str(item.get("texture"))] if isinstance(item.get("texture"), str) and item.get("texture") else list(item.get("texture") or []),
        "warmth": str(item.get("weight") or "unknown"),
        "layer_roles": list(dict.fromkeys(roles)),
        "wear_modes": wear_modes,
        "requires_underlayer": bool(item.get("requires_underlayer")),
        "can_layer_over": [str(x) for x in (item.get("can_layer_over") or [])],
        "cannot_layer_over": [str(x) for x in (item.get("cannot_layer_over") or [])],
        "style_tags": [str(x) for x in (item.get("style_tags") or [])],
        "occasion_tags": [str(x) for x in (item.get("occasions") or ["everyday"])],
        "seasons": [str(x) for x in (item.get("seasons") or ["all"])],
        "laundry_group": "unknown",
        "notes": "",
        "source_batch_id": batch_id,
        "import_confidence": item.get("confidence"),
    }


def import_wardrobe_zip(user_id: int, batch_id: int, data: bytes) -> dict[str, Any]:
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as exc:
        raise ImportErrorDetail("Файл должен быть ZIP") from exc
    with zf:
        manifest = _safe_json(zf, ["garderobus_wardrobe_manifest.json", "wardrobe_manifest.json", "manifest.json"])
        if manifest.get("schema") not in {"garderobus.wardrobe.v2", "garderobus.wardrobe.v1"}:
            raise ImportErrorDetail("Неизвестная схема manifest")
        items = manifest.get("items") or []
        by_id = {str(x.get("id")): x for x in items if x.get("id")}
        cmap = _safe_json(zf, ["collage_map.json"])
        collage_names = sorted([n for n in zf.namelist() if Path(n).name.lower().startswith("collage_") and Path(n).suffix.lower() == ".png"])
        if not collage_names:
            raise ImportErrorDetail("В ZIP нет collage_*.png")
        outdir = settings.storage_path / "garments"
        outdir.mkdir(parents=True, exist_ok=True)
        imported = 0
        updated = 0
        missing: list[str] = []
        seen: set[str] = set()
        for name in collage_names:
            stem = Path(name).stem
            mapping = _mapping_for(cmap, stem, Path(name).name)
            if not mapping:
                raise ImportErrorDetail(f"В collage_map нет раскладки для {Path(name).name}")
            image = Image.open(io.BytesIO(zf.read(name))).convert("RGBA")
            for idx, external_id in enumerate(mapping[:9]):
                if not external_id:
                    continue
                item = by_id.get(external_id)
                if not item:
                    missing.append(external_id)
                    continue
                cell = _crop_cell(image, idx)
                target = outdir / f"{external_id.lower()}_{uuid4().hex[:10]}.png"
                cell.save(target, "PNG")
                payload = _garment_payload(item, batch_id)
                old = db.find_garment_by_external_id(user_id, external_id)
                if old:
                    db.update_garment_payload(user_id, int(old["id"]), payload)
                    db.update_garment_image(user_id, int(old["id"]), str(target))
                    updated += 1
                else:
                    db.add_garment(user_id, str(target), "", payload, confirmed=True)
                    imported += 1
                seen.add(external_id)
        not_visualized = sorted(set(by_id) - seen)
        db.set_batch_status(batch_id, "processing")
        return {
            "imported": imported,
            "updated": updated,
            "manifest_items": len(by_id),
            "not_visualized": not_visualized,
            "missing_manifest_ids": sorted(set(missing)),
        }
