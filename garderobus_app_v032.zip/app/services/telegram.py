from pathlib import Path
from typing import Any
import httpx
from ..config import settings

class TelegramAPIError(RuntimeError):
    def __init__(self, method:str,status_code:int,description:str="",retry_after:int|None=None):
        self.method=method; self.status_code=status_code; self.description=description; self.retry_after=retry_after
        super().__init__(f"Telegram API {method} failed: HTTP {status_code}: {description}")

class TelegramAPI:
    def __init__(self):
        if not settings.telegram_bot_token: raise RuntimeError("TELEGRAM_BOT_TOKEN is not configured")
        self.base=f"https://api.telegram.org/bot{settings.telegram_bot_token}"; self.file_base=f"https://api.telegram.org/file/bot{settings.telegram_bot_token}"
    async def call(self,method,payload=None):
        async with httpx.AsyncClient(timeout=45) as c:
            r=await c.post(f"{self.base}/{method}",json=payload or {})
            data={}
            try:data=r.json()
            except:pass
            if r.status_code>=300 or not data.get("ok"):
                raise TelegramAPIError(method,r.status_code,str(data.get("description") or r.reason_phrase))
            return data["result"]
    async def call_multipart(self,method,data,files):
        async with httpx.AsyncClient(timeout=60) as c:
            r=await c.post(f"{self.base}/{method}",data=data,files=files); p=r.json()
            if r.status_code>=300 or not p.get("ok"): raise TelegramAPIError(method,r.status_code,str(p.get("description") or r.reason_phrase))
            return p["result"]
    async def send_message(self,chat_id:int,text:str,reply_markup:dict|None=None,parse_mode:str|None=None):
        p={"chat_id":chat_id,"text":text};
        if reply_markup:p["reply_markup"]=reply_markup
        if parse_mode:p["parse_mode"]=parse_mode
        return await self.call("sendMessage",p)
    async def send_photo(self,chat_id:int,path:str|Path,caption:str="",reply_markup:dict|None=None):
        import json
        p=Path(path); data={"chat_id":str(chat_id),"caption":caption}
        if reply_markup:data["reply_markup"]=json.dumps(reply_markup,ensure_ascii=False)
        return await self.call_multipart("sendPhoto",data,{"photo":(p.name,p.read_bytes(),"image/png" if p.suffix.lower()==".png" else "image/jpeg")})
    async def send_document(self,chat_id:int,path:str|Path,caption:str=""):
        p=Path(path); data={"chat_id":str(chat_id),"caption":caption}
        return await self.call_multipart("sendDocument",data,{"document":(p.name,p.read_bytes(),"application/zip" if p.suffix.lower()==".zip" else "application/octet-stream")})
    async def forward_message(self,to_chat_id:int,from_chat_id:int,message_id:int):
        return await self.call("forwardMessage",{"chat_id":to_chat_id,"from_chat_id":from_chat_id,"message_id":message_id})
    async def download_file(self,file_id:str):
        f=await self.call("getFile",{"file_id":file_id}); fp=f["file_path"]
        async with httpx.AsyncClient(timeout=45) as c:
            r=await c.get(f"{self.file_base}/{fp}")
            if r.status_code>=300: raise TelegramAPIError("downloadFile",r.status_code,r.reason_phrase)
            return r.content,fp
    async def answer_callback(self,callback_query_id:str,text:str=""):
        p={"callback_query_id":callback_query_id};
        if text:p["text"]=text
        return await self.call("answerCallbackQuery",p)
    async def get_webhook_info(self): return await self.call("getWebhookInfo")
    async def get_me(self): return await self.call("getMe")
    async def get_updates(self,offset=None,timeout=25):
        p={"timeout":timeout,"allowed_updates":["message","callback_query"]};
        if offset is not None:p["offset"]=offset
        return await self.call("getUpdates",p)
    async def delete_webhook(self,drop_pending_updates=False): return await self.call("deleteWebhook",{"drop_pending_updates":drop_pending_updates})
    async def set_my_commands(self):
        cmds=[{"command":"start","description":"Главное меню"},{"command":"consultation","description":"Начать консультацию"},{"command":"wardrobe","description":"Загрузить гардероб"},{"command":"profile","description":"Мой профиль"},{"command":"laundry","description":"Стирка"},{"command":"myid","description":"Мой номер Гардеробуса"},{"command":"help","description":"Как это работает"},{"command":"visiontest","description":"Тест вырезки вещей"}]
        return await self.call("setMyCommands",{"commands":cmds})

def web_app_button(text="Открыть Капсулу"):
    return {"text":text,"web_app":{"url":settings.resolved_mini_app_url}} if settings.mini_app_is_public else None

def main_menu_keyboard(has_profile=False, paid=False, client_code=""):
    rows=[]
    demo=web_app_button("Попробовать демо")
    if not paid:
        if demo: rows.append([demo])
        rows.append([{"text":"Статус","callback_data":"menu:status"}])
        return {"inline_keyboard":rows}
    if not has_profile:
        rows.append([{"text":"Начать консультацию","callback_data":"consult:start"}])
    else:
        rows.append([{"text":"Загрузить гардероб","callback_data":"batch:start"}])
    rows += [[{"text":"Мой профиль","callback_data":"menu:profile"},{"text":"Статус","callback_data":"menu:status"}],[{"text":"Гардероб","callback_data":"menu:wardrobe"},{"text":"Стирка","callback_data":"menu:laundry"}]]
    b=web_app_button("Открыть Капсулу")
    if b: rows.append([b])
    return {"inline_keyboard":rows}
