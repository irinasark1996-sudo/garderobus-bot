from pathlib import Path
import os

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    openai_api_key: str = ""
    openai_model: str = "gpt-5-mini"

    telegram_bot_token: str = ""
    telegram_webhook_secret: str = ""
    telegram_polling_timeout: int = 25

    # Leave these empty in Railway. They can be derived from RAILWAY_PUBLIC_DOMAIN.
    public_base_url: str = ""
    mini_app_url: str = ""
    railway_public_domain: str = ""
    auto_configure_webhook: bool = True

    database_path: str = "./storage/kapsula.sqlite3"
    storage_dir: str = "./storage"
    dev_allow_insecure_id: bool = False

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def db_path(self) -> Path:
        return Path(self.database_path)

    @property
    def storage_path(self) -> Path:
        return Path(self.storage_dir)

    @staticmethod
    def _normalize_base_url(value: str) -> str:
        """Protect against pasting the Mini App URL into PUBLIC_BASE_URL.

        Railway serves both the Mini App and webhook from the same origin. During
        beta setup it is very easy to copy https://host/app instead of
        https://host. Treat a trailing /app as the Mini App path, not as part of
        the public base URL.
        """
        value = (value or "").strip().rstrip("/")
        if value.endswith("/app"):
            value = value[:-4].rstrip("/")
        return value

    @property
    def resolved_public_base_url(self) -> str:
        explicit = self._normalize_base_url(self.public_base_url)
        if explicit:
            return explicit
        domain = (self.railway_public_domain or os.getenv("RAILWAY_PUBLIC_DOMAIN", "")).strip()
        if domain:
            return f"https://{domain.strip('/')}"
        return "http://localhost:8000"

    @property
    def resolved_mini_app_url(self) -> str:
        explicit = self.mini_app_url.strip()
        if explicit:
            return explicit
        return self.resolved_public_base_url.rstrip("/") + "/app"

    @property
    def mini_app_is_public(self) -> bool:
        return self.resolved_mini_app_url.startswith("https://")

    @property
    def explicit_webhook_secret(self) -> str:
        """Only enforce a webhook secret when the owner explicitly configured it.

        Older beta builds generated a random secret inside ephemeral storage.
        After a Railway redeploy that could change while Telegram still sent the
        previous secret. Omitting the secret is safer for this beta than locking
        the owner out. Production can set TELEGRAM_WEBHOOK_SECRET explicitly.
        """
        return self.telegram_webhook_secret.strip()


settings = Settings()
