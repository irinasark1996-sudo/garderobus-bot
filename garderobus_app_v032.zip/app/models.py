from typing import Literal
from pydantic import BaseModel, Field


LaundryGroup = Literal["white", "light", "dark", "color", "delicate", "handwash", "dry_clean", "unknown"]
GarmentStatus = Literal["clean", "worn", "laundry", "washing", "drying", "repair", "seasonal", "loaned"]


class ColorToken(BaseModel):
    name: str
    hex: str
    share: float = Field(ge=0, le=1)


class GarmentAnalysis(BaseModel):
    title: str
    category: str
    subtype: str
    colors: list[ColorToken]
    print: str
    silhouette: str
    length: str
    fit: str
    transparency: Literal["opaque", "slightly_sheer", "sheer", "unknown"]
    fabric_guess: list[str]
    texture: list[str]
    warmth: Literal["very_light", "light", "medium", "warm", "very_warm", "unknown"]
    layer_roles: list[str]
    can_layer_over: list[str]
    cannot_layer_over: list[str]
    style_tags: list[str]
    seasons: list[str]
    laundry_group: LaundryGroup
    confidence: float = Field(ge=0, le=1)
    uncertainty_questions: list[str]


class AppearanceProfile(BaseModel):
    temperature: str
    depth: str
    contrast: str
    chroma: str
    line_softness: str
    feature_scale: str
    face_shape_notes: list[str]
    body_line_notes: list[str]
    flattering_color_families: list[str]
    styling_hypotheses: list[str]
    confidence: float = Field(ge=0, le=1)
    caveats: list[str]


class OutfitRequest(BaseModel):
    occasion: str = "everyday"
    mood: str = "random"
    novelty: float = Field(default=0.55, ge=0, le=1)


class OutfitResult(BaseModel):
    garment_ids: list[int]
    explanation: list[str]
    hairstyle: str
    makeup: str
