const tg = window.Telegram?.WebApp;
if (tg) { try { tg.ready(); tg.expand(); } catch (_) {} }
const initData = tg?.initData || "";
const devUser = new URLSearchParams(location.search).get("devUser") || "1";
const authHeaders = () => initData ? {"X-Telegram-Init-Data": initData} : {"X-Dev-User-Id": devUser};
let wardrobe = [];

async function api(path, opts={}) {
  const headers = {...authHeaders(), ...(opts.headers||{})};
  const res = await fetch(path, {...opts, headers});
  if (!res.ok) {
    let detail = `${res.status}`;
    try { const j=await res.json(); detail=j.detail || detail; } catch(_){}
    throw new Error(detail);
  }
  return res.json();
}

function showScreen(name){
  document.querySelectorAll('.screen').forEach(x=>x.classList.toggle('active',x.dataset.screen===name));
  document.querySelectorAll('.navBtn').forEach(x=>x.classList.toggle('active',x.dataset.target===name));
  if(name==='laundry') loadLaundry();
  if(name==='profile') loadProfile();
}
document.querySelectorAll('.navBtn').forEach(b=>b.onclick=()=>showScreen(b.dataset.target));
document.getElementById('refreshBtn').onclick=()=>refreshAll();

function imgUrl(url){ return url?.startsWith('http') ? url : location.origin + url; }

function garmentCard(g){
  const tags=[g.subtype,g.print,g.laundry_group].filter(Boolean).slice(0,3);
  return `<article class="garmentCard" data-id="${g.id}">
    <div class="garmentImage"><img src="${imgUrl(g.image_url)}" alt="${escapeHtml(g.title||'Вещь')}"></div>
    <div class="garmentMeta"><b>${escapeHtml(g.title||'Вещь')}</b><div class="tagRow">${tags.map(t=>`<span class="tag">${escapeHtml(t)}</span>`).join('')}</div></div>
  </article>`;
}
function escapeHtml(s=''){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}

async function loadWardrobe(){
  try{
    const data=await api('/api/garments'); wardrobe=data.items||[];
    const grid=document.getElementById('wardrobeGrid');
    grid.innerHTML=wardrobe.map(garmentCard).join('');
    document.getElementById('wardrobeEmpty').classList.toggle('hidden',wardrobe.length>0);
    document.getElementById('wardrobeSubtitle').textContent=wardrobe.length ? `${wardrobe.length} вещей · ${wardrobe.filter(x=>x.status==='clean').length} доступны стилисту` : 'Пока гардероб пуст. Добавляй вещи через бота или прямо здесь.';
    grid.querySelectorAll('.garmentCard').forEach(el=>el.onclick=()=>openGarment(Number(el.dataset.id)));
  }catch(err){
    document.getElementById('wardrobeSubtitle').textContent=initData ? `Ошибка: ${err.message}` : 'Открой Mini App из Telegram. Для локальной разработки включи DEV_ALLOW_INSECURE_ID=true.';
  }
}

async function uploadFiles(files){
  const status=document.getElementById('uploadStatus'); status.classList.remove('hidden','error');
  let done=0;
  for(const file of files){
    status.textContent=`Анализирую ${done+1} из ${files.length}: ${file.name}`;
    const fd=new FormData();fd.append('image',file);
    try{
      const data=await api('/api/garments/analyze',{method:'POST',body:fd});
      await api(`/api/garments/${data.id}/confirm`,{method:'POST'});
      done++;
    }catch(err){ status.textContent=`Не удалось обработать ${file.name}: ${err.message}`;status.classList.add('error');break; }
  }
  if(done===files.length){status.textContent=`Готово: добавлено ${done}`;status.classList.add('success');}
  await loadWardrobe();
}
const mainInput=document.getElementById('garmentInput');mainInput.onchange=e=>uploadFiles([...e.target.files]);
document.querySelectorAll('.mirrorInput').forEach(i=>i.onchange=e=>uploadFiles([...e.target.files]));

function openGarment(id){
  const g=wardrobe.find(x=>x.id===id);if(!g)return;
  const colors=(g.colors||[]).map(c=>`${c.name} ${c.hex}`).join(', ');
  document.getElementById('garmentDialogBody').innerHTML=`
    <div class="eyebrow">КАРТОЧКА ВЕЩИ</div><h2>${escapeHtml(g.title)}</h2>
    <div class="detailImage"><img src="${imgUrl(g.image_url)}" alt=""></div>
    <div class="detailList">
      <b>${escapeHtml(g.category)} · ${escapeHtml(g.subtype)}</b><br>
      Цвета: ${escapeHtml(colors||'—')}<br>
      Силуэт: ${escapeHtml(g.silhouette||'—')} · посадка: ${escapeHtml(g.fit||'—')}<br>
      Ткань (предположение): ${escapeHtml((g.fabric_guess||[]).join(', ')||'—')}<br>
      Слои: ${escapeHtml((g.layer_roles||[]).join(', ')||'—')}<br>
      Не надевать поверх: ${escapeHtml((g.cannot_layer_over||[]).join(', ')||'—')}<br>
      Предварительная стирка: ${escapeHtml(g.laundry_group||'unknown')}<br>
      Статус: ${escapeHtml(g.status)}
    </div>
    <div class="detailActions">
      <button class="primary" onclick="setStatus(${g.id},'laundry')">В стирку</button>
      <button class="secondary" onclick="setStatus(${g.id},'clean')">Чистая</button>
      <button class="secondary" onclick="setStatus(${g.id},'repair')">В ремонт</button>
      <button class="secondary" onclick="setStatus(${g.id},'seasonal')">Убрана на сезон</button>
    </div>`;
  document.getElementById('garmentDialog').showModal();
}
window.setStatus=async(id,status)=>{await api(`/api/garments/${id}/status/${status}`,{method:'POST'});document.getElementById('garmentDialog').close();await refreshAll();};
document.getElementById('dialogClose').onclick=()=>document.getElementById('garmentDialog').close();

async function loadLaundry(){
  const grid=document.getElementById('laundryGrid');
  try{
    const data=await api('/api/laundry');
    grid.innerHTML=data.buckets.map(b=>`<article class="laundryBucket"><div><b>${escapeHtml(b.label)}</b><div class="tagRow">${b.items.slice(0,4).map(x=>`<span class="tag">${escapeHtml(x.title)}</span>`).join('')}</div></div><div class="bucketCount">${b.items.length}</div></article>`).join('');
  }catch(err){grid.innerHTML=`<div class="notice error">${escapeHtml(err.message)}</div>`}
}

async function loadProfile(){
  const card=document.getElementById('profileCard');
  try{
    const data=await api('/api/profile');const p=data.profile;
    if(!p){card.innerHTML='<div class="emptyState small"><h3>Профиль ещё не создан</h3><p>Начни типирование в Telegram-боте и пришли фотографии по инструкции.</p></div>';return;}
    const facts=[['Температура',p.temperature],['Глубина',p.depth],['Контраст',p.contrast],['Насыщенность',p.chroma],['Линии',p.line_softness],['Масштаб черт',p.feature_scale]];
    card.innerHTML=`<div class="profileGrid">${facts.map(([a,b])=>`<div class="profileFact"><small>${escapeHtml(a)}</small><b>${escapeHtml(b||'—')}</b></div>`).join('')}</div>
      <div class="detailList" style="margin-top:12px">Подходящие цветовые семьи: ${escapeHtml((p.flattering_color_families||[]).join(', ')||'—')}<br>Уверенность: ${Math.round((p.confidence||0)*100)}%</div>`;
  }catch(err){card.innerHTML=`<div class="notice error">${escapeHtml(err.message)}</div>`}
}

function boardClass(g){
  const c=(g.category||'').toLowerCase();const roles=g.layer_roles||[];
  if(roles.includes('outer')||roles.includes('light_outer')||['outerwear','jacket','blazer','coat','trench','parka'].includes(c))return 'outer';
  if(roles.includes('shoes')||['shoes','sneakers','boots','loafers','flats','heels','sandals'].includes(c))return 'shoes';
  if(roles.includes('bottom')||['bottom','trousers','pants','jeans','skirt','shorts','leggings'].includes(c))return 'bottom';
  return 'top';
}

document.getElementById('generateLook').onclick=async()=>{
  const btn=document.getElementById('generateLook');btn.disabled=true;btn.textContent='Собираю…';
  try{
    const payload={occasion:document.getElementById('occasion').value,mood:document.getElementById('mood').value,novelty:Number(document.getElementById('novelty').value)};
    const data=await api('/api/stylist/generate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const gs=data.garments||[];
    document.getElementById('paperBoard').innerHTML=gs.map(g=>`<div class="paperItem ${boardClass(g)}"><img src="${imgUrl(g.image_url)}" alt="${escapeHtml(g.title)}"></div>`).join('');
    document.getElementById('hairText').textContent=data.outfit.hairstyle;
    document.getElementById('makeupText').textContent=data.outfit.makeup;
    document.getElementById('explanations').innerHTML=(data.outfit.explanation||[]).map(x=>`<div class="reason">${escapeHtml(x)}</div>`).join('');
    document.getElementById('lookResult').classList.remove('hidden');document.getElementById('stylistEmpty').classList.add('hidden');
  }catch(err){document.getElementById('stylistEmpty').classList.remove('hidden');document.getElementById('stylistEmpty').innerHTML=`<div class="emptyIcon">✦</div><h3>Пока не собрать</h3><p>${escapeHtml(err.message)}</p>`;}
  finally{btn.disabled=false;btn.textContent='Собрать образ';}
};

async function refreshAll(){await loadWardrobe();await loadLaundry();}
refreshAll();
