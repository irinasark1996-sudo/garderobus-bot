from app.models import OutfitRequest
from app.services.stylist import generate_outfit


def item(i, category, roles):
    return {
        "id": i,
        "title": f"item-{i}",
        "category": category,
        "subtype": category,
        "layer_roles": roles,
        "cannot_layer_over": [],
        "confirmed": True,
        "status": "clean",
        "wear_count": 0,
        "print": "plain",
        "colors": [],
        "silhouette": "regular",
        "texture": [],
    }


def test_stylist_excludes_laundry():
    wardrobe = [item(1,"top",["top"]), item(2,"skirt",["bottom"]), item(3,"shoes",["shoes"]), item(4,"top",["top"])]
    wardrobe[3]["status"] = "laundry"
    result = generate_outfit(wardrobe, None, OutfitRequest())
    assert 4 not in result.garment_ids
    assert {1,2,3}.issubset(set(result.garment_ids))
