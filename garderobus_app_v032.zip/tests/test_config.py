from app.config import Settings


def test_public_base_url_strips_mini_app_suffix():
    s = Settings(public_base_url="https://example.up.railway.app/app")
    assert s.resolved_public_base_url == "https://example.up.railway.app"
    assert s.resolved_mini_app_url == "https://example.up.railway.app/app"
