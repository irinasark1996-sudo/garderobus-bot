from app.services.laundry import group_laundry


def test_only_laundry_status_enters_baskets():
    garments = [
        {"id": 1, "status": "laundry", "laundry_group": "white"},
        {"id": 2, "status": "clean", "laundry_group": "white"},
        {"id": 3, "status": "laundry", "laundry_group": "dark"},
    ]
    buckets = group_laundry(garments)
    assert [x["id"] for x in buckets["white"]] == [1]
    assert [x["id"] for x in buckets["dark"]] == [3]
