# Создание бота в Telegram

## 1. Создать самого бота

Откройте в Telegram официальный **@BotFather**.

Отправьте:

```text
/newbot
```

Дальше BotFather попросит:

1. отображаемое имя, например `Капсула AI`;
2. уникальный username, например `kapsula_ai_test_bot`.

BotFather выдаст токен. Токен является секретом: не отправляйте его в чат, не вставляйте в HTML и не коммитьте в Git.

## 2. Подключить токен локально

В корне проекта:

```bash
python scripts/configure.py
```

Скрипт попросит два секрета через скрытый ввод:

- Telegram bot token;
- OpenAI API key.

Они сохранятся только в локальный `.env`.

## 3. Первый запуск без сервера и домена

```bash
python scripts/run_polling.py
```

После строки `Kapsula bot started...` откройте созданного бота в Telegram и отправьте `/start`.

В polling-режиме уже работают:

- типирование внешности по 3 фото;
- AI-анализ вещи;
- отделение вещи от фона при установленном `requirements-full.txt`;
- подтверждение или исправление карточки обычным текстом;
- гардероб;
- бельевые корзины.

Mini App в локальном режиме не показывается кнопкой, потому что для реального Telegram Mini App нужен публичный URL.

## 4. Production / Mini App

После развёртывания FastAPI на публичном HTTPS-домене задайте в `.env`:

```text
PUBLIC_BASE_URL=https://example.com
MINI_APP_URL=https://example.com/app
```

И переключите Telegram на webhook:

```bash
python scripts/set_webhook.py
```

Webhook использует `TELEGRAM_WEBHOOK_SECRET`, а backend проверяет заголовок `X-Telegram-Bot-Api-Secret-Token`.
