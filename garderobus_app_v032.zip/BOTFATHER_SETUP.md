# BotFather setup

Бот больше не использует OpenAI API.

После создания Telegram-бота нужны только:
- `TELEGRAM_BOT_TOKEN`;
- `PUBLIC_BASE_URL` Railway;
- `ADMIN_TELEGRAM_ID` стилиста;
- `ADMIN_PASSWORD` для `/admin`.

Чтобы узнать свой `ADMIN_TELEGRAM_ID`, после запуска отправьте боту `/myid`.
