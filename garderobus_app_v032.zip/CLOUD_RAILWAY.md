# Garderobus — запуск в Railway

Проект уже подготовлен под Railway и работает в webhook-режиме.

## Что Railway должен хранить как секреты

В Variables добавить только:

- `TELEGRAM_BOT_TOKEN` — токен от BotFather
- `OPENAI_API_KEY` — OpenAI API key

Не вставляйте эти значения в GitHub-файлы.

Дополнительно можно оставить:

- `OPENAI_MODEL=gpt-5-mini`
- `AUTO_CONFIGURE_WEBHOOK=true`
- `DATABASE_PATH=./storage/kapsula.sqlite3`
- `STORAGE_DIR=./storage`

`PUBLIC_BASE_URL`, `MINI_APP_URL` и `TELEGRAM_WEBHOOK_SECRET` вручную задавать не обязательно.
После появления Railway-домена приложение использует `RAILWAY_PUBLIC_DOMAIN`, а webhook-secret создаёт в постоянном хранилище.

## Railway

1. Создать новый Project.
2. Добавить Service из GitHub-репозитория Garderobus.
3. Railway автоматически обнаружит `Dockerfile`.
4. В Variables добавить два секрета: `TELEGRAM_BOT_TOKEN` и `OPENAI_API_KEY`.
5. В Settings → Volumes добавить Volume с Mount Path: `/app/storage`.
6. В Settings → Networking → Public Networking нажать **Generate Domain**.
7. После появления домена нажать Redeploy/Restart один раз. При старте Garderobus сам зарегистрирует Telegram webhook и команды.
8. Открыть `https://<ваш-домен>/health`. Должно быть `"ok": true`, `"openai_configured": true`, `"telegram_configured": true`.
9. Открыть @garderobus_bot → `/start`.

## Почему нужен Volume

SQLite, фотографии вещей, обработанные PNG и профиль пользователя лежат в `/app/storage`. Без Volume данные исчезнут при следующем деплое.

## Как работает Mini App

После генерации публичного Railway-домена бот автоматически начинает показывать кнопку **«Открыть Капсулу»**. URL вычисляется как `https://$RAILWAY_PUBLIC_DOMAIN/app`.

## Если бот молчит

Посмотреть Deploy Logs. При нормальном запуске должна появиться строка:

`Telegram webhook ready at https://.../telegram/webhook`

Если домен был создан уже после первого запуска сервиса — просто Redeploy/Restart.
