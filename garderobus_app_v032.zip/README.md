# Гардеробус 0.5 — demo → payment → service pipeline

Внутри пользовательского приложения нет AI API.

## Что уже работает

- каждому Telegram-пользователю присваивается стабильный ID вида `GB-000001`;
- неоплаченный пользователь видит полноценный demo-гардероб в Mini App;
- demo позволяет собрать образ и **заменить только одну вещь**, не пересобирая остальные позиции;
- цена beta задаётся `PRODUCT_PRICE_RUB` (по умолчанию 1490 ₽);
- отдельный web-checkout `/buy/GB-XXXXXX` подготовлен для YooKassa;
- при наличии YooKassa credentials доступны обычная hosted-форма и отдельная кнопка СБП;
- подтверждение YooKassa перепроверяется через API перед выдачей доступа;
- администратор может вручную пометить клиента оплаченным;
- консультация открывается только после оплаты (или `BETA_FREE_ACCESS=true`);
- бот собирает 5 фотографий внешности: лицо анфас, 3/4, профиль, полный рост спереди, полный рост сбоку;
- после типирования принимается **весь гардероб без лимита 10 фото**;
- пользователь завершает загрузку кнопкой «Все вещи отправлены»;
- админ может загрузить `garderobus.appearance.v1` JSON;
- админ может загрузить один ZIP с `garderobus_wardrobe_manifest.json`, `collage_map.json` и прозрачными `collage_*.png`;
- сервер сам режет каждый коллаж 3×3, связывает ячейки с G-ID и создаёт карточки вещей;
- повторный импорт того же G-ID обновляет вещь вместо создания дубля;
- механический стилист поддерживает рабочую замену одной вещи в готовом образе.

## Railway variables

Обязательные:

- `TELEGRAM_BOT_TOKEN`
- `PUBLIC_BASE_URL`
- `ADMIN_TELEGRAM_ID`
- `ADMIN_PASSWORD`

Коммерческие:

- `PRODUCT_PRICE_RUB=1490`
- `PRODUCT_TITLE=Персональный Гардеробус`
- `BETA_FREE_ACCESS=false`

Опциональный standalone checkout YooKassa:

- `YOOKASSA_SHOP_ID`
- `YOOKASSA_SECRET_KEY`
- `YOOKASSA_RETURN_URL` (если пусто, используется `/pay/return`)

Секреты хранятся только в Railway Variables.

## Формат ZIP гардероба

```text
garderobus_wardrobe_manifest.json
collage_map.json
collage_001.png
collage_002.png
...
```

`collage_map.json` может содержать массив из 9 G-ID для каждого коллажа:

```json
{
  "collage_001": ["G0001", "G0002", "G0003", null, null, null, null, null, null]
}
```

или ключи `row1_col1` ... `row3_col3`.

## Проверка

`pytest -q` → 3 passed.

Дополнительно вручную проверены `/health`, `/api/me`, `/app`, `/buy/{client_code}` и импорт тестового ZIP с прозрачным коллажем.
